'use strict';
require('babel-register');
require('./config/lib/app');