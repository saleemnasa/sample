'use strict';

import config from '../config/config';
import request from "request";

const sendRegistrationOTP = (otp, mobile) => {

    let message = `Dear Customer,

Your OTP for registration on INSTAFIX App is ${otp}. Donot share this OTP with anyone.

Regards
Team INSTAFIX`;
    let url = "http://api.unicel.in/SendSMS/sendmsg.php?uname=" + config.default.sms.username + "&pass=" + config.default.sms.password + "&dest=" + mobile + "&msg=" + message + "&send=" + config.default.sms.senderid;

    // let url = "http://sms.smsjosh.com/api/mt/SendSMS?APIKey=" + config.default.sms.APIKey + "&senderid=" + config.default.sms.senderid + "&channel=" + config.default.sms.channel + "&DCS=0&flashsms=0&number=91" + mobile + "&text=" + message + "&route=" + config.default.sms.route

    request(url, function(err, res, body) {
        console.log(body);
    });
};

const sendResetOTP = (otp, mobile, countryCode) => {
    // let message = "" + otp + " is the OTP for resetting your password.";
    let message = `Dear Customer,

Your OTP for Change Password on INSTAFIX App is ${otp}. Donot share this OTP with anyone.

Regards
Team INSTAFIX`;

    // let url = "http://sms.smsjosh.com/api/mt/SendSMS?APIKey=" + config.default.sms.APIKey + "&senderid=" + config.default.sms.senderid + "&channel=" + config.default.sms.channel + "&DCS=0&flashsms=0&number=91" + mobile + "&text=" + message + "&route=" + config.default.sms.route
    let url = "http://api.unicel.in/SendSMS/sendmsg.php?uname=" + config.default.sms.username + "&pass=" + config.default.sms.password + "&dest=" + mobile + "&msg=" + message + "&send=" + config.default.sms.senderid;

    request(url, function(err, res, body) {
        console.log(body);
    });

};

const sendInstafixLink = (mobile) => {

    // let message = "Click below link to download Instafix App. " + config.default.appLink.android + ". ";

    let message = `Dear Customer,

Get your plumbing fixed instantly. Click Instafix URL to download now.
${config.default.appLink.android}

Regards
Team INSTAFIX`;

    // let url = "http://sms.smsjosh.com/api/mt/SendSMS?APIKey=" + config.default.sms.APIKey + "&senderid=" + config.default.sms.senderid + "&channel=" + config.default.sms.channel + "&DCS=0&flashsms=0&number=91" + mobile + "&text=" + message + "&route=" + config.default.sms.route
    let url = "http://api.unicel.in/SendSMS/sendmsg.php?uname=" + config.default.sms.username + "&pass=" + config.default.sms.password + "&dest=" + mobile + "&msg=" + message + "&send=" + config.default.sms.senderid;
    console.log('url:', url);
    request(url, function(err, res, body) {
        console.log('error:', err);
        console.log('body:', body);
    });
};

export {
    sendRegistrationOTP,
    sendInstafixLink,
    sendResetOTP
}