'use strict';

import config from "../config/config";
const sgMail = require('@sendgrid/mail');
sgMail.setApiKey(config.default.sendgrid.apiKey);

const sendOTPMail = (data) => {
    let { name, email, otp } = data;

    var data = {
        from: '"Admin - Sales Track" <info@sparity.com>',
        to: email,
        subject: 'SalesTrack : Registration OTP',
        html: "<html>Dear " + name + ", <br/><p>" + otp + " is your One Time Password for <a href='http://www.sparity.com'>SalesTrack</a>. Please enter OTP to complete your registration.</p>Thanks</html>"
    };

    transporter.sendMail(data, function(error, body) {
        console.log("check");
        console.log(body);
    });
}

const sendResetMail = (data) => {
    let { name, email, otp } = data;

    var data = {
        from: '"Admin - Sales Track" <admin@salestrack.com>',
        to: email,
        subject: 'SalesTrack : Reset OTP',
        html: "<html>Dear " + name + ", <br/><p>" + otp + " is the otp for resetting your password.</p>Thanks</html>"
    };

    transporter.sendMail(data, function(error, body) {
        console.log("check");
        console.log(body);
    });
}


const forgotPasswordMail = (data) => {
    let { name, email, token, host } = data;

    let link = "http://" + host + "/verify/" + token + "?e=" + email + "&forgot=true";

    var data = {
        from: '"Admin - Sales Track" <info@sparity.com>',
        to: email,
        subject: 'SalesTrack : Forgot password',
        html: "<html>Dear " + name + ", <br/><p>Use this <a href='" + link + "' target='_blank'>" + link + "</a> to reset your password.</p>Thanks</html>"
    };

    sgMail.send(data);
}

const sendVerificationMail = (data) => {
    let { name, email, token, host } = data;

    let link = "http://" + host + "/verify/" + token + "?e=" + email;

    var data = {
        from: '"Admin - Sales Track" <info@sparity.com>',
        to: email,
        subject: 'SalesTrack : Account Verification',
        html: "<html>Dear " + name + ", <br/><p>Please Click on the link to verify your email.<br><a href=" + link + ">Click here to verify</a></html>"
    };
    sgMail.send(data);
}

// enquiry mails from here

const sendEnqueryFormToAdmin = (data) => {
    let to = config.default.sendgrid.defaultToEmail;
    let { bcc, enquiry, subject } = data;
    let email = {
        from: enquiry.email,
        to,
        subject,
        html: `<html> Dear Admin,
        <p>You have a new enquiry from </p>
        Name &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <strong>${enquiry.name}</strong> <br/>
        Email &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <strong>${enquiry.email}</strong> <br/>
        Mobile &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <strong>${enquiry.number} </strong> <br/>
        Message&nbsp;&nbsp;&nbsp;: <br/>
        <p>${enquiry.message} </p>
        <br/>
        Thank you.
        </html>`
    }
    sgMail.send(email);
}

export {
    sendResetMail,
    forgotPasswordMail,
    sendOTPMail,
    sendVerificationMail,
    sendEnqueryFormToAdmin
};