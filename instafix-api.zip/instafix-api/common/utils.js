'use strict';

import config from '../config/config';
import jwt from 'jsonwebtoken';
import otpGenerator from "otp-generator";
import GoogleUrl from 'google-url';
import Promise from 'bluebird';
import AWS from "aws-sdk";
import request from 'request';

AWS.config.loadFromPath('./config/s3_credentials.json');

const BucketName = config.default.awsS3.bucketName;
const s3Bucket = new AWS.S3({ params: { Bucket: BucketName } });

let googleUrl = new GoogleUrl({ key: config.default.googleurl.api_key });

const generateJwtToken = (data, requestFrom) => {

    let secretCode = config.default.jwt.normal.secret;
    let expiresIn = config.default.jwt.normal.expiresIn;
    if (requestFrom == 'website')
        expiresIn = '1000d';

    return jwt.sign({ data }, secretCode, { expiresIn: expiresIn });

};

const decodeJwtToken = (jwtToken) => {
    let secretCode = config.default.jwt.normal.secret;

    return new Promise((resolve, reject) => {
        jwt.verify(jwtToken, secretCode, (error, decodedData) => {
            if (!error) resolve(decodedData);
            else reject({ status: 'unauthorised', message: 'jwt expired' });
        });
    });
};

const generateOTP = () => {
    return otpGenerator.generate(6, { alphabets: false, upperCase: false, specialChars: false });
}

const getShortURL = (url) => {
    return new Promise((resolve, reject) => {
        return googleUrl.shorten(url, function (err, shortUrl) {
            if (err) {
                console.log(err);
                resolve("");
            } else
                resolve(shortUrl)
        });
    });
}

const toTitleCase = (phrase) => {
    return phrase
        .toLowerCase()
        .split(' ')
        .map(word => word.charAt(0).toUpperCase() + word.slice(1))
        .join(' ');
}

const idGenerator = (phrase, count) => {
    let iter = 100000;
    return phrase + ((iter + count) + 1);
}

const getPreSignedURL = (awsFileKey) => {
    let s3 = new AWS.S3();
    let params = {
        Bucket: config.default.awsS3.bucketName,
        Key: awsFileKey
    };
    try {
        let url = s3.getSignedUrl('getObject', params);
        return url;
    } catch (err) {
        return "";
    }
}

const deleteS3Object = (awsFileKey) => {
    let s3 = new AWS.S3();
    var params = {
        Bucket: config.default.awsS3.bucketName,
        Key: awsFileKey
    };
    s3.deleteObject(params, function (err, data) {
        if (err) return null
        else return data;
    });

}

const googleMapsClient = require('@google/maps').createClient({
    key: config.default.googleurl.api_key,
    Promise: Promise
});

const getCoordsFromAddress = (address) => {
    return googleMapsClient.geocode({ address: address }).asPromise();
    //return request.get(`https://maps.googleapis.com/maps/api/geocode/json?address=${address}&key=${config.default.googleurl.api_key}`)
}

const getAddressFromCoords = (coords) => {
    // return request.get(`https://maps.googleapis.com/maps/api/geocode/json?address=${address}&key=${'key'}`)
}

export {
    generateJwtToken,
    decodeJwtToken,
    generateOTP,
    getShortURL,
    toTitleCase,
    idGenerator,
    getPreSignedURL,
    deleteS3Object,
    getCoordsFromAddress
};