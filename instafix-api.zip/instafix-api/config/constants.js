module.exports = {
    months: [
        { name: "January", value: 1 },
        { name: "February", value: 2 },
        { name: "March", value: 3 },
        { name: "April", value: 4 },
        { name: "May", value: 5 },
        { name: "June", value: 6 },
        { name: "July", value: 7 },
        { name: "August", value: 8 },
        { name: "September", value: 9 },
        { name: "October", value: 10 },
        { name: "November", value: 11 },
        { name: "December", value: 12 }
    ],
    times: [{ key: "00:00", value: '00:00 AM' }, { key: "01:00", value: '01:00 AM' }, { key: "02:00", value: '02:00 AM' }, { key: "03:00", value: '03:00 AM' }, { key: "04:00", value: '04:00 AM' }, { key: "05:00", value: '05:00 AM' }, { key: "06:00", value: '06:00 AM' }, { key: "07:00", value: '07:00 AM' }, { key: "08:00", value: '08:00 AM' }, { key: "09:00", value: '09:00 AM' }, { key: "10:00", value: '10:00 AM' }, { key: "11:00", value: '11:00 AM' }, { key: "12:00", value: '12:00 PM' }, { key: "13:00", value: '01:00 PM' }, { key: '14:00', value: '02:00 PM' }, { key: "15:00", value: '03:00 PM' }, { key: "16:00", value: '04:00 PM' }, { key: "17:00", value: '05:00 PM' }, { key: "18:00", value: '06:00 PM' }, { key: "19:00", value: '07:00 PM' }, { key: "20:00", value: '08:00 PM' }, { key: "21:00", value: '09:00 PM' }, { key: "22:00", value: '10:00 PM' }, { key: "23:00", value: '11:00 PM' }],
    years: ["2017", "2016", "2015", "2014", "2013", "2012", "2011", "2010", "2009", "2008", "2007", "2006", "2005", "2004", "2003", "2002", "2001", "2000", "1999", "1998", "1997", "1996", "1995", "1994", "1993", "1992", "1991", "1990", "1989", "1988", "1987", "1986", "1985", "1984", "1983", "1982"],
    version: 'v1.0'
};