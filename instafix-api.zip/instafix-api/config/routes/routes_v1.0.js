'use strict';

import express from 'express';

import technicians from '../../api/v1.0/technicians/routes/technicians.routes';
import customers from '../../api/v1.0/customers/routes/customers.routes';
import feedbacks from '../../api/v1.0/feedbacks/routes/feedbacks.routes';
import feedback_categories from '../../api/v1.0/feedback_categories/routes/feedback_categories.routes';
import pages from '../../api/v1.0/pages/routes/pages.routes';
import settings from '../../api/v1.0/settings/routes/settings.routes';
import enquires from '../../api/v1.0/enquires/routes/enquires.routes';
import otps from '../../api/v1.0/otps/routes/otps.routes';
import staticRoutes from "../../api/static.routes";

let app = express();

app.use(customers);
app.use(technicians);
app.use(feedbacks);
app.use(feedback_categories);
app.use(pages);
app.use(settings);
app.use(enquires);
app.use(otps);
app.use(staticRoutes);

export default app;