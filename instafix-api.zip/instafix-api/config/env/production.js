'use strict';

export default {
    app: {
        title: 'Instafix API',
        description: 'Instafix API'
    },
    db: {
        mysql: {
            uri: 'mysql://' + (process.env.DB_1_PORT_27017_TCP_ADDR || 'localhost') + '/instafix',
            options: {
                user: '',
                pass: ''
            },
            debug: process.env.MYSQLDB_DEBUG || false
        }
    },
    jwt: {
        normal: {
            secret: 'qCZe6np3uSELbnQDP4JBvFkRmbbFw4aA',
            expiresIn: '1d' //1 day(s)
        },
        password: {
            secret: 'gJdFGPq22rVZDJWP9XnhUwRjy3U5whDy',
            expiresIn: '1d'
        }
    },
    sendgrid: {
        apiKey: '<key>',
        defaultEmailFromName: 'no reply bot - Instafix',
        defaultEmailFrom: 'no-reply@ehil.com'
    },
    winston: {
        console: {
            colorize: true,
            timestamp: true,
            prettyPrint: true
        },
        file: {
            filename: 'logs/error.log',
            timestamp: true,
            maxsize: 2048,
            json: true,
            colorize: true,
            level: 'error'
        }
    },
    googleurl: {
        api_key: '<key>'
    },
    awsS3: {
        bucketName: 'instafix-dev',
    },
    version: 'v1.0',
    api: 'http://localhost:4000',
    website: 'http://localhost',
    port: process.env.PORT || 4000
};