'use strict';

export default {
    app: {
        title: 'Instafix API',
        description: 'Instafix API'
    },
    db: {
        mysql: {
            username: process.env.DB_USERNAME || 'instafix',
            password: process.env.DB_PASSWORD || 'instafix123',
            database: process.env.DB_DATABASE || 'instafixDB',
            port: process.env.DB_PORT || 3306,
            host: process.env.DB_HOST || 'instafix.cmlq63m034sa.ap-south-1.rds.amazonaws.com',
            debug: process.env.MYSQLDB_DEBUG || false
        }
    },
    jwt: {
        normal: {
            secret: 'qCZe6np3uSELbnQDP4JBvFkRmbbFw4aA',
            expiresIn: '365d' //365 days
        },
        password: {
            secret: 'gJdFGPq22rVZDJWP9XnhUwRjy3U5whDy',
            expiresIn: '365d' //365 days
        }
    },
    appLink: {
        android: "https://play.google.com/store/apps/details?id=com.google.android.googlequicksearchbox"
    },
    sms: {
        // APIKey: 'ztYV5HrOnkaUs2XR556ZVA',
        // senderid: 'INSTFX',
        // channel: 'Trans',
        // route: 25
        senderid: 'INSTFX',
        username: 'HILDCCOR',
        password: 'Z6B)W!X4'
    },
    sendgrid: {
        apiKey: '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',
        defaultEmailFromName: 'no reply bot - Instafix',
        defaultEmailFrom: 'no-reply@hil.com',
        // defaultToEmail: 'hil.instafix@gmail.com'
        defaultToEmail: 'support.instafix@hil.in'
    },
    winston: {
        console: {
            colorize: true,
            timestamp: true,
            prettyPrint: true
        },
        file: {
            filename: 'logs/error.log',
            timestamp: true,
            maxsize: 2048,
            json: true,
            colorize: true,
            level: 'error'
        }
    },
    googleurl: {
        api_key: 'AIzaSyDSlW7jC1__e_2Pmrmh1AMA8T1zoygN_-E'
    },
    awsS3: {
        bucketName: 'instafix-dev'
    },
    version: 'v1.0',
    api: 'http://localhost:4000',
    website: 'http://localhost',
    port: process.env.PORT || 4000
};