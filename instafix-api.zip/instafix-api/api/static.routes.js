/*jshint esversion: 6 */
/*jshint globalstrict: true*/
'use strict';

import express from 'express';
import crypto from 'crypto';
import mongoose from 'mongoose';
import md5 from 'md5';
import config from "../config/config";
import {
    sendInstafixLink
} from '../common/messages';
import Pages from "./v1.0/pages/services/page.services";

// const fileUpload = require('express-fileupload');

import {
    forgotPasswordMail,
    sendResetMail,
    sendVerificationMail
} from "../common/mails";

const objectId = mongoose.Types.ObjectId;

const { check, validationResult } = require('express-validator/check');

let app = express();

// app.use(fileUpload());

app.set('view engine', 'ejs');

app.use('/assets', express.static('assets'));
// app.use(express.static(__dirname + '/assets'));

app.get('/about-us', function(req, res) {

    Pages.findOne({ page_name: 'about_us' })
        .then((response) => {
            console.log(response)
            res.render('pages', { data: response });
        }).catch((err) => {
            // console.log(err)
            if (err) {
                return res.status(500).send({ msg: err.message });
            }
        });
});

app.get('/contact-us', function(req, res) {

    Pages.findOne({ page_name: 'contact_us' })
        .then((response) => {
            console.log(response)
            res.render('pages', { data: response });
        }).catch((err) => {
            // console.log(err)
            if (err) {
                return res.status(500).send({ msg: err.message });
            }
        });
});

app.get('/faq', function(req, res) {

    Pages.findOne({ page_name: 'faq' })
        .then((response) => {
            console.log(response)
            res.render('pages', { data: response });
        }).catch((err) => {
            // console.log(err)
            if (err) {
                return res.status(500).send({ msg: err.message });
            }
        });
});

app.get('/terms-and-conditions', function(req, res) {

    Pages.findOne({ page_name: 'terms_and_conditions' })
        .then((response) => {
            console.log(response)
            res.render('pages', { data: response });
        }).catch((err) => {
            // console.log(err)
            if (err) {
                return res.status(500).send({ msg: err.message });
            }
        });
});

app.post('/sendLink', function(req, res) {
    console.log(req.body);
    let {
        mobile
    } = req.body;
    if (!mobile)
        return res.status(401).send({ error: 1, message: 'Please enter mobile number' });
    sendInstafixLink(mobile);
    return res.status(200).send({ error: 0, message: 'Instafix application link sent' });
});

app.all('*', function(req, res) {
    res.render('notfound');
});

export default app;