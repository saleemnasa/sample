'use strict';

import PageService from '../services/page.services';
import {
    toTitleCase
} from "../../../../common/utils";

import {
    sendForgotPassword,
    sendResetOTP,
    sendRegistrationOTP
} from "../../../../common/messages";

const getPages = async (req, res) => {

    let query = {};
    let {
        limit,
        offset
    } = req.query;

    query.limit = parseInt(limit) || 10;

    query.offset = parseInt(offset) || 0;
    query.where = { status: true };
    let count = await PageService.count({ where: query.where });
    PageService.findAll(query)
        .then(response => {
            if (response) {
                res.status(200).json({
                    error: '0',
                    message: "Pages data",
                    data: response,
                    count
                });
            } else {
                res.status(400).json({
                    error: '1',
                    message: "No pages exists in the database"
                });
            }
        })
        .catch(error => {
            console.log(error)
            res.status(500).json({
                error: '1',
                message: "Internal sever error"
            });
        });
}

const addPage = async (req, res) => {
    let data = req.body;
    try {
        let added_page = await PageService.create(data);
        if (added_page) {
            res.status(200).json({
                error: '0',
                message: "Page added successfully.",
                data: added_page
            });
        }
    } catch (err) {
        console.log(err);
        res.status(500).json({
            error: '1',
            message: err.errors[0].message

        });
    }
}

const updatePage = async (req, res) => {
    let data = {};
    data.where = { where: { id: req.params.page_id, status: true } };
    data.data = req.body;
    if (data.data.id)
        delete data.data.id;

    try {
        let updated_page = await PageService.update(data);
        console.log(updated_page)
        if (updated_page) {
            res.status(200).json({
                error: '0',
                message: "Page updated successfully.",
                data: data.data
            });
        } else {
            res.status(400).json({
                error: '1',
                message: "Page not found."
            });
        }
    } catch (err) {
        res.status(500).json({
            error: '2',
            message: err

        });
    }

}

const uploadCities = async (req, res) => {
    let data = req.body;
    data = data.map((item, i) => {
        delete item.alternatenames;
        return item;
    });
    try {
        let result = await PageService.upload_cities(data);
        res.send(data);
    } catch (err) {
        res.send(data);
    }
}

const uploadStates = async (req, res) => {
    let data = req.body;
    data = data.map((item, i) => {
        delete item.id;
        return item;
    });
    try {
        let result = await PageService.upload_states(data);
        res.send(result);
    } catch (err) {
        res.send(err);
    }
}

export default {
    getPages,
    addPage,
    updatePage,
    uploadCities,
    uploadStates
}