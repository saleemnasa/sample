'use strict';

import express from 'express';
import PagesControllers from '../controllers/pages.controller';
import {
    isCustomer,
    requires
} from '../../auth/auth.service';

let router = express.Router();

/**
 * @api {get} /pages?limit=10&offset=0 Pages list
 * @apiName Pages list
 * @apiGroup Pages
 *
 * @apiPermission Admin
 *
 * @apiHeader {String} x-access-code User Token
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
            "error": "0",
            "message": "Pages data",
            "data": [
                        {
                            "id": 1,
                            "title": "",
                            "content": "",
                            "page_name": ""
                        },
                        {
                            "id": 2,
                            "title": "",
                            "content": "",
                            "page_name": ""
                        }
                    ]
                }
            ]
        }
 *
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "1",
 *       "message": "No Pages exists in the database."
 *     }
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Server Error
 *     {
 *       "error": "2",
 *       "message": "Internal sever error"
 *     }
 *
 */

router.get('/v1.0/pages', PagesControllers.getPages);

/**
 * @api {post} /pages/add Add a page
 * @apiName Add a page
 * @apiGroup Pages
 *
 * @apiPermission Admin
 *
 * @apiHeader {String} x-access-code User Token
 *
 * @apiParamExample {json} Request-Example:
 * {
            "page_name": "about_us",
            "title": "About Us",
            "content": "this is sample content"
 * }
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
                    "error": "0",
                    "message": "Page added successfully.",
                    "data": {
                        "status": true,
                        "id": 6,
                        "page_name": "about_us1",
                        "title": "About Us",
                        "content": "this is sample content",
                        "created_by": 0,
                        "updated_by": 0,
                        "created_at": "2018-10-09T12:22:57.303Z",
                        "updated_at": "2018-10-09T12:22:57.303Z"
                    }
 *              }
 *
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Server Error
 *     {
 *       "error": "1",
 *       "message": "Internal sever error"
 *     }
 *
 */

router.post('/v1.0/pages/add', requires.body, isCustomer.hasAdminRole, PagesControllers.addPage);



/**
 * @api {post} /pages/update/:page_id Update a page
 * @apiName Update a page
 * @apiGroup Pages
 *
 * @apiPermission Admin
 *
 * @apiHeader {String} x-access-code User Token
 *
 * @apiParamExample {json} Request-Example:
 * {
            "page_name": "about_us",
            "title": "About Us",
            "content": "this is sample content",
            "status": false // add this key for soft delete of a page 
 * }
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
            "error": "0",
            "message": "Feedbacks data",
            "data":{
                    "error": "0",
                    "message": "Page added successfully.",
                    "data": {
                        "id": 6,
                        "page_name": "about_us1",
                        "title": "About Us",
                        "content": "this is sample content",
                    }
                }
                }
            ]
        }
 *
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Server Error
 *     {
 *       "error": "1",
 *       "message": "Internal sever error"
 *     }
 *
 */

router.post('/v1.0/pages/update/:page_id', requires.body, isCustomer.hasAdminRole, PagesControllers.updatePage);
router.post('/v1.0/pages/upload_cities', requires.body, PagesControllers.uploadCities);


router.post('/v1.0/pages/upload_states', requires.body, PagesControllers.uploadStates);
export default router;