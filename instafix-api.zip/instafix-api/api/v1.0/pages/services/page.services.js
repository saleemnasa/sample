'use strict';
const Sequelize = require('sequelize');
const Page = require('../../models').pages;
const City = require('../../models').cities;
const State = require('../../models').states;
const Op = Sequelize.Op;


const findAll = (query) => {
    return Page.findAll({
        where: query.where,
        offset: query.offset,
        limit: query.limit,
    });
}

const findOne = (query) => {
    return Page.findOne({ where: query });
}

const create = (data) => {
    return Page.create(data);
}

const update = (data) => {
    return Page.update(data.data, data.where);
}

const count = (where) => {
    return Page.count(where);
}

const upload_cities = (data) => {
    return City.bulkCreate(data);
}

const upload_states = (data) => {
    return State.bulkCreate(data);
}

export default {
    findAll,
    findOne,
    create,
    update,
    count,
    upload_cities,
    upload_states
};