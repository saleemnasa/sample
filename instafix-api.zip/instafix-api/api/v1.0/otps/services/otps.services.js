'use strict';
const Sequelize = require('sequelize');
const Otp = require('../../models').otps;
const Customer = require('../../models').customers;
const Op = Sequelize.Op;

const create = (data) => {
    return Otp.create(data);
}

const update = (data, query) => {
    return Otp.update(query, data);
}

const count = (query) => {
    return Otp.count(query);
}

const find = (query) => {
    return Otp.find(query);
}

export default {
    count,
    create,
    update,
    find
};