'use strict';

import OtpsService from '../services/otps.services';
import CustomerService from '../../customers/services/customers.services';
const Sequelize = require('sequelize');
const Op = Sequelize.Op;

import {
    generateJwtToken,
    generateOTP,
    idGenerator,
    toTitleCase,
    getPreSignedURL,
    deleteS3Object
} from "../../../../common/utils";

import {
    sendResetOTP,
    sendRegistrationOTP
} from "../../../../common/messages";
import otpsServices from '../services/otps.services';


const add = async (req, res) => {

    let { mobile } = req.params;
    let data = req.body;
    let { last_mobile, new_mobile } = data;

    if (!new_mobile) {
        res.status(400).json({
            error: '1',
            message: 'New mobile is required'
        });
        return;
    }

    let where = {
        [Op.or]: [{ mobile: mobile }]
    }

    try {

        let user_exists_with_new_mobile = await CustomerService.find({ where: { [Op.or]: [{ mobile: new_mobile }] } });
        let user_exists = await CustomerService.find({ where });

        if (!user_exists) {
            res.status(401).json({
                error: '2',
                message: 'User with given mobile does not exists'
            });
            return;
        }

        if (user_exists_with_new_mobile) {
            res.status(401).json({
                error: '3',
                message: 'User with given new mobile already exists'
            });
            return;
        }

        let otp = generateOTP();

        let new_obj = {
            last_mobile: mobile,
            mobile: new_mobile,
            otp
        }

        let otp_found = await OtpsService.find({
            where: {
                last_mobile: mobile,
                mobile: new_mobile,
                status: true
            }
        });
        if (otp_found) {
            let inactive_otp = await OtpsService.update({
                where: {
                    last_mobile: mobile,
                    mobile: new_mobile,
                    status: true
                }
            }, { status: false });
        }

        let added_otp = await OtpsService.create(new_obj);

        sendRegistrationOTP(added_otp.otp, added_otp.mobile);

        res.status(200).json({
            error: '0',
            message: 'Otp has been sent to ' + added_otp.mobile
        });
    } catch (err) {
        console.log(err);
        res.status(401).json({
            error: '2',
            message: '' + err[0].message
        });
    }

}


const verify_otp = async (req, res) => {
    let data = req.body;
    let { mobile } = req.params;

    let { otp, new_mobile } = data;

    if (!new_mobile || !otp) {
        res.status(401).json({
            error: '1',
            message: 'Both New mobile and otp are required'
        });
        return;
    }

    try {
        let where = {
            mobile: new_mobile,
            last_mobile: mobile,
            status: true,
            otp
        }
        let your_otp = await OtpsService.find({ where });
        if (!your_otp) {
            res.status(401).json({
                error: '2',
                message: 'Invalid otp.'
            });
            return;
        } else {

            let new_data = {
                mobile: new_mobile
            };
            let updated_customer = await CustomerService.update({
                where: {
                    mobile: mobile
                }
            }, new_data);

            if (updated_customer[0]) {
                let where_n = {
                    where: {
                        mobile: new_mobile,
                        last_mobile: mobile,
                        status: true,
                        otp
                    }
                }
                let inactive_otp = await OtpsService.update(where_n, { status: false });
                res.status(200).json({
                    error: '0',
                    message: 'Customer updated with new mobile ' + new_mobile + '.'
                });
            } else {
                res.status(401).json({
                    error: '3',
                    message: 'Customer not updated. Please try again.'
                });
            }
        }


    } catch (err) {
        console.log(err);
        res.status(401).json({
            error: '2',
            message: '' + err[0].message,
        });
    }
}

export default {
    add,
    verify_otp
}