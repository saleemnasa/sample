'use strict';

import express from 'express';
import OtpsController from '../controllers/otps.controller';
import {
	isCustomer,
	requires
} from '../../auth/auth.service';

import config from "../../../../config/config";

let router = express.Router();



/**
 * @api {post} /otp/customer_add_otp/:mobile Generate Otp to update customer's mobile
 * @apiName Generate Otp to update customer's mobile
 * @apiGroup Otp
 *
 * 
 * @apiHeader {String} x-access-code value: token
 *
 * @apiParamExample {json} Request-Example:
 *     {
            new_mobile: 8142217184,      // required,
 *     }
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 201 OK
 *     {
			"error": "0",
			"message": "Otp has been sent to 8142217184"
 *		}
 *
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 401 Bad Request
 *     {
    "error": "2",
    "message": "User with given mobile does not exists"
 * }
 * 
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 401 Bad Request
 *     {
    "error": "3",
    "message": "User with given new mobile already exists"
 * }
 * 
 * 
 *  * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 400 Bad Request
 *     {
    "error": "1",
    "message": "New mobile is required"
 * }
 *
 */
router.post('/v1.0/otp/customer_add_otp/:mobile', isCustomer.authenticated, requires.body, OtpsController.add);



/**
 * @api {post} /otp/customer_verify_otp/:mobile Verify Otp with customer's new mobile number
 * @apiName Verify Otp with customer's new mobile number
 * @apiGroup Otp
 *
 * 
 * @apiHeader {String} x-access-code value: token
 *
 * @apiParamExample {json} Request-Example:
 *     {
 * "otp": 233757,
 * "new_mobile": 9494019291
 * }
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 201 OK
 *     {
			"error": "0",
			"message": "Customer updated with new mobile 8142217184"
 *		}
 *
 *
 * 
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 401 Bad Request
 *     {
    "error": "2",
    "message": "Invalid otp."
 * }
 * 
 * 
 *  * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 400 Bad Request
 *     {
     "error": "1",
    "message": "Both New mobile and otp are required"
 * }
 *
 */
router.post('/v1.0/otp/customer_verify_otp/:mobile', isCustomer.authenticated, requires.body, OtpsController.verify_otp);

export default router;

