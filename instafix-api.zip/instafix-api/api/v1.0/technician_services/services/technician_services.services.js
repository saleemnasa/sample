
'use strict';
const Sequelize = require('sequelize');
const TechnicianServices = require('../../models').technician_services;
const Op = Sequelize.Op;

const create = (data) => {
    return TechnicianServices.create(data);
}

const update = (query, data) => {
    return TechnicianServices.update(data, query);
}

const findQuery = (query) => {
    let attr = ['first_name', 'last_name', 'mobile', 'email', 'gender', 'is_verified', 'profile_pic', 'created_at']
    return TechnicianServices.findAll({
        where: query.where,
        // include: [{
        // }]
    });
}

export default {
    create,
    update,
    findQuery
};