'use strict';
const Sequelize = require('sequelize');
const FeedbackCategory = require('../../models').feedback_categories;
const Op = Sequelize.Op;

const findOne = (query, selectable) => {
    return FeedbackCategory.findOne({
        where: query,
        attributes: selectable
    });
}

const findFeedbackCategory = (query) => {
    return FeedbackCategory.findOne({ where: query });
}

const findAll = (query) => {
    return FeedbackCategory.findAll({
        where: query.where
    });
}

const create = (data) => {
    return FeedbackCategory.create(data);
}

const update = (data, query) => {
    return FeedbackCategory.update(data, query);
}

const remove = (query) => {
    return FeedbackCategory.destroy(query);
}

const count = (query) => {
    return FeedbackCategory.count(query);
}

export default {
    findOne,
    findFeedbackCategory,
    create,
    findAll,
    update,
    remove,
    count
};