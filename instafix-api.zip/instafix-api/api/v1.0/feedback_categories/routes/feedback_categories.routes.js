'use strict';

import express from 'express';
import FeedbackController from '../controllers/feedback_categories.controller';
import {
    isCustomer,
    requires
} from '../../auth/auth.service';

let router = express.Router();

/**
 * @api {get} /categories Feedback Categories list
 * @apiName Feedback Categories list
 * @apiGroup Feedback Categories
 *
 * @apiPermission Admin
 *
 * @apiHeader {String} x-access-code User Token
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
        "error": "0",
        "message": "Feedback category data",
        "data":     [
                {
                    "id": 1,
                    "name": "Category 1",
                    "created_by": null,
                    "updated_by": null,
                    "status": true,
                    "created_at": "2018-10-09T07:42:33.000Z",
                    "updated_at": "2018-10-09T07:56:33.000Z"
                },
                {
                    "id": 2,
                    "name": "Category 2",
                    "created_by": null,
                    "updated_by": null,
                    "status": true,
                    "created_at": "2018-10-09T07:42:37.000Z",
                    "updated_at": "2018-10-09T07:56:26.000Z"
                }
            ],
        }
 *
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "1",
 *       "message": "No feedbacks exists in the database."
 *     }
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Server Error
 *     {
 *       "error": "2",
 *       "message": "Internal sever error"
 *     }
 *
 */

router.get('/v1.0/categories', isCustomer.authenticated, FeedbackController.getFeedbacks);

/**
 * @api {post} /categories/add Add Category
 * @apiName Add Category
 * @apiGroup Feedback Categories
 *
 * @apiPermission Mobile
 * 
 * @apiHeader {String} x-request-from value: mobile
 * @apiHeader {String} x-access-code value: token
 *
 * @apiParamExample {json} Request-Example:
 *     {
            name: "Category 1",         // required,
 *     }
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 201 OK
 *     {
            "error": "0",
            "message": "Feedback added",
            "data": {
                "is_replied": false,
                "status": true,
                "id": 1,
                "customer_id": "1",
                "feedback_title": "testtitle1112",
                "feedback_text": "this is text",
                "feedback_type": "query12",
                "updated_at": "2018-10-03T11:53:45.224Z",
                "created_at": "2018-10-03T11:53:45.224Z"
            }
        }
 *
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 400 Bad Request
 *     {
 *       "error": "1",
 *       "message": "Error: {message}"
 *     }
 * 
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Bad Request
 *     {
 *       "error": "2",
 *       "message": "Internal server error"
 *     }
 *
 */

router.post('/v1.0/categories/add', isCustomer.hasAdminRole, requires.body, FeedbackController.add);

/**
 * @api {get} /categories/:id Get Category
 * @apiName Get Category
 * @apiGroup Feedback Categories
 *
 * @apiPermission Admin
 *
 * @apiHeader {String} x-access-code User Token
 *
 * @apiSuccessExample Success-Response:
 *      HTTP/1.1 200 OK
 *      {
            "error": "0",
            "message": "Feedback category data",
            "data": {
                "id": 2,
                "name": "Category 1",
                "created_by": null,
                "updated_by": null,
                "status": true,
                "created_at": "2018-10-09T07:42:37.000Z",
                "updated_at": "2018-10-09T07:42:37.000Z"
            }
        }
 *
 *
 * @apiErrorExample {json} Error-Response:
 *      HTTP/1.1 404 Not Found
 *      {
            "error": "1",
            "message": "No category exists in the database"
        }
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Server Error
 *     {
 *          "error": "2",
 *          "message": "Internal sever error"
 *     }
 *
 */

router.get('/v1.0/categories/:id', isCustomer.hasAdminRole, FeedbackController.getFeedback);

/**
 * @api {put} /categories/:id Update Category
 * @apiName Update Category
 * @apiGroup Feedback Categories
 *
 * @apiPermission Admin
 *
 * @apiHeader {String} x-access-code User Token
 *
 * @apiSuccessExample Success-Response:
 *      HTTP/1.1 200 OK
 *      {
            error: '0',
            message: "Category updated successfully."
        }
 *
 *
 * @apiErrorExample {json} Error-Response:
 *      HTTP/1.1 404 Not Found
 *      {
            "error": "1",
            "message": "No category exists in the database"
        }
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Server Error
 *     {
 *          "error": "2",
 *          "message": "Internal sever error"
 *     }
 *
 */

router.put('/v1.0/categories/:id', isCustomer.hasAdminRole, requires.body, FeedbackController.updateFeedback);

/**
 * @api {delete} /categories/:id Delete Category
 * @apiName Delete Category
 * @apiGroup Feedback Categories
 *
 * @apiPermission Admin
 *
 * @apiHeader {String} x-access-code User Token
 *
 * @apiSuccessExample Success-Response:
 *      HTTP/1.1 200 OK
 *      {
            error: '0',
            message: "Category deleted successfully."
        }
 *
 *
 * @apiErrorExample {json} Error-Response:
 *      HTTP/1.1 404 Not Found
 *      {
            "error": "1",
            "message": "No category exists in the database"
        }
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Server Error
 *     {
 *          "error": "2",
 *          "message": "Internal sever error"
 *     }
 *
 */

router.delete('/v1.0/categories/:id', isCustomer.hasAdminRole, FeedbackController.deleteFeedback);

export default router;