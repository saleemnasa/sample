'use strict';

import FeedbackService from '../services/feedback_categories.services';
import {
    toTitleCase
} from "../../../../common/utils";

const add = (req, res) => {
    let data = req.body;
    let {
        userID
    } = req.userID;

    data.created_by = userID;
    data.name = toTitleCase(data.name);

    FeedbackService.create(data)
        .then(response => {
            res.status(200).json({
                error: "0",
                message: "Feedback category added",
                data: response
            });
        })
        .catch(error => {
            console.log(error);
            res.status(500).json({
                error: "1",
                message: "Error: " + error.errors[0].message
            });
        })
}

const getFeedbacks = (req, res) => {

    let query = {};

    query.where = {};

    FeedbackService.findAll(query)
        .then(response => {
            if (response) {
                res.status(200).json({
                    error: '0',
                    message: "Feedback category data",
                    data: response
                });
            } else {
                res.status(400).json({
                    error: '1',
                    message: "No categories exists in the database"
                });
            }
        })
        .catch(error => {
            console.log(error)
            res.status(500).json({
                error: '1',
                message: "Internal sever error"
            });
        });
}

const getFeedback = (req, res) => {

    let {
        id
    } = req.params;

    FeedbackService.findFeedbackCategory({ id })
        .then(response => {
            if (response) {
                res.status(200).json({
                    error: '0',
                    message: "Feedback category data",
                    data: response
                });
            } else {
                res.status(400).json({
                    error: '1',
                    message: "No category exists in the database"
                });
            }
        })
        .catch(error => {
            console.log(error)
            res.status(500).json({
                error: '1',
                message: "Internal sever error"
            });
        });
}

const updateFeedback = (req, res) => {

    let query = {};
    let {
        id
    } = req.params, data = req.body;


    query.where = { id };

    FeedbackService.update(data, query)
        .then(response => {
            res.status(200).json({
                error: '0',
                message: "Category updated successfully."
            });
        })
        .catch(error => {
            console.log(error)
            res.status(500).json({
                error: '1',
                message: "Internal sever error"
            });
        });
}

const deleteFeedback = (req, res) => {

    let query = {};
    let {
        id
    } = req.params;

    query.where = { id };

    FeedbackService.remove(query)
        .then(response => {
            res.status(200).json({
                error: '0',
                message: "Category deleted successfully."
            });
        })
        .catch(error => {
            console.log(error)
            res.status(500).json({
                error: '1',
                message: "Internal sever error"
            });
        });
}

export default {
    add,
    getFeedbacks,
    updateFeedback,
    deleteFeedback,
    getFeedback
}