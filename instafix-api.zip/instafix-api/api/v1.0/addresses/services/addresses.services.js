
'use strict';
const Sequelize = require('sequelize');
const Address = require('../../models').addresses;
const Service = require('../../models').services;
const Technician = require('../../models').technicians;
const Op = Sequelize.Op;

const create = (data) => {
    return Address.create(data);
    // console.log(Address.create(data))
    // return new Address(data);
}

const update = (query, data) => {
    data.updated_at = new Date();
    return Address.update(data, query);
}


// not using below 

const findOneAddress = (query, selectable) => {
    return Address.findOne(query);
}

const findOnetoPush = (query) => {
    return Address.findOne(query);
}

const findAddress = (query) => {
    //console.log(query);
    return Address.findOne(query);
}

const find = (query) => {
    return Address.find(query);
}

const findQuery = (query, selectable) => {
    return Address.find(query);
}

const updateMany = (query, data) => {
    return Address.updateMany(query, data);
}

const remove = (query) => {
    return Address.remove(query);
}

const count = (query) => {
    return Address.count(query);
}

const countAll = () => {
    return Address.count().then(c);
}

export default {
    countAll,
    findOnetoPush,
    findAddress,
    findOneAddress,
    create,
    find,
    findQuery,
    update,
    updateMany,
    remove,
    count
};