'use strict';

import SettingService from '../services/settings.service';
import {
    times
} from "../../../../config/constants";
import settingsService from '../services/settings.service';

const getSettings = async (req, res) => {

    let query = {};
    let {
        limit,
        offset
    } = req.query;

    let { role } = req.params;

    query.limit = parseInt(limit) || undefined;

    query.offset = parseInt(offset) || undefined;
    query.where = { status: true };
    let count = 0
    try {
        count = await SettingService.count({ where: query.where });
    } catch (err) {
        console.log({ err });
    }

    SettingService.findAll(query)
        .then(response => {
            if (response) {
                let settings = {};
                response && response.map((item, i) => {
                    settings[item.name] = item.value;
                });

                let final_res = {
                    error: '0',
                    message: "Settings data",
                    data: response,
                    android: settings,
                    count
                }
                if (!role) {
                    delete final_res.data;
                }

                res.status(200).json(final_res);
            } else {
                res.status(400).json({
                    error: '1',
                    message: "No Settings exists in the database"
                });
            }
        })
        .catch(error => {
            console.log(error)
            res.status(500).json({
                error: '1',
                message: "Internal sever error"
            });
        });
}

const addSetting = async (req, res) => {
    let data = req.body;
    try {
        let added_page = await SettingService.create(data);
        if (added_page) {
            res.status(200).json({
                error: '0',
                message: "Page added successfully.",
                data: added_page
            });
        }
    } catch (err) {
        console.log(err);
        res.status(500).json({
            error: '1',
            message: err.errors[0].message

        });
    }
}

const updateSetting = async (req, res) => {
    let data = {};
    data.where = { where: { id: req.params.setting_id, status: true } };
    data.data = req.body;
    if (data.data.id)
        delete data.data.id;

    try {
        let updated_page = await SettingService.update(data);
        if (updated_page) {
            res.status(200).json({
                error: '0',
                message: "Setting updated successfully.",
                data: data.data
            });
        } else {
            res.status(400).json({
                error: '1',
                message: "Setting not found."
            });
        }
    } catch (err) {
        res.status(500).json({
            error: '2',
            message: err
        });
    }

}

const getStates = async (req, res) => {
    try {
        let query = { where: { status: true } };
        let states_list = await SettingService.getStates(query);
        let temp = states_list && states_list.map((item, i) => {
            item = JSON.parse(JSON.stringify(item));
            return {
                name: item.adminName1,
                code: item.adminCode1
            }

        })
        temp = temp.sort(function (a, b) {
            if (a.name < b.name) { return -1; }
            if (a.name > b.name) { return 1; }
            return 0;
        })
        res.status(200).json({
            error: '0',
            message: "States found.",
            data: temp
        });
    } catch (err) {
        res.status(500).json({
            error: '1',
            message: err
        });
    }
}

const getCities = async (req, res) => {
    let { state_code } = req.params;
    if (state_code) {
        try {
            let query = { where: { status: true, admin1_code: state_code } };
            let cities = await SettingService.getCities(query);
            let temp = cities && cities.map((item, i) => {
                item = JSON.parse(JSON.stringify(item));
                return {
                    name: item.asciiname,
                    state_code: item.admin1_code
                }
            });
            temp = temp.sort(function (a, b) {
                if (a.name < b.name) { return -1; }
                if (a.name > b.name) { return 1; }
                return 0;
            })
            res.status(200).json({
                error: '0',
                message: "Cities found.",
                data: temp
            });
        } catch (err) {
            res.status(500).json({
                error: '1',
                message: err
            });
        }
    }
}

const getTimes = (req, res) => {
    return res.status(200).json({
        error: '0',
        message: "Times data.",
        data: times
    });
}

const updateGroup = async (req, res) => {
    let data = req.body;
    let final = [];
    if (data.length) {
        for (let i = 0; i < data.length; i++) {
            let item = data[i];
            try {
                let { value, id } = item;
                let query = {};
                query.where = { where: { id, status: true } };
                query.data = { value };
                let result = await settingsService.update(query);
                console.log({ result });
                if (result[0]) {
                    item.is_updated = true
                    final.push(item);
                } else {
                    item.is_updated = false
                    final.push(item);
                }
            } catch (err) {
                final.push(err)
            }
        }

        res.status(200).json({
            error: '0',
            message: 'Updated Successfully.',
            data: final
        });

    } else {
        res.status(401).json({
            error: '1',
            message: "Send array of records.",
            data
        });
    }
}

export default {
    getSettings,
    addSetting,
    updateSetting,
    getStates,
    getTimes,
    getCities,
    updateGroup
}