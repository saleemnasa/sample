'use strict';

import express from 'express';
import SettingsControllers from '../controllers/settings.controller';
import {
    isCustomer,
    requires
} from '../../auth/auth.service';
import { settings } from 'cluster';
import settingsController from '../controllers/settings.controller';

let router = express.Router();

/**
 * @api {get} /settings?limit=10&offset=0 Settings list
 * @apiName Settings list
 * @apiGroup Settings
 *
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
            "error": "0",
            "message": "Settings data",
            "android": {
                "radius": "3",
                "app_name": "Insta Fix",
                "plumber_default_img": "https://s3.ap-south-1.amazonaws.com/instafix-dev/images/plumber.jpg",
                "customer_default_img": "https://s3.ap-south-1.amazonaws.com/instafix-dev/images/customer.jpg",
                "radius_min_range": "1",
                "radius_max_range": "10",
                "radius_units": "km"
            }
        }
 *
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "1",
 *       "message": "No Settings exists in the database."
 *     }
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Server Error
 *     {
 *       "error": "2",
 *       "message": "Internal sever error"
 *     }
 *
 */

router.get('/v1.0/settings', SettingsControllers.getSettings);


/**
 * @api {get} /settings/admin?limit=10&offset=0 Settings list
 * @apiName Settings list for Admin operations
 * @apiGroup Settings
 *
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
            "error": "0",
            "message": "Settings data",
            "android": {
            "radius": "3",
            "app_name": "Insta Fix",
            "plumber_default_img": "https://s3.ap-south-1.amazonaws.com/instafix-dev/images/plumber.jpg",
            "customer_default_img": "https://s3.ap-south-1.amazonaws.com/instafix-dev/images/customer.jpg",
            "radius_min_range": "1",
            "radius_max_range": "10",
            "radius_units": "km"
        },
            "data": [
                        {
                            "id": 1,
                            "name": "radius",
                            "value": "2"
                        },
                        {
                            "id": 2,
                            "name": "app_name",
                            "value": "Insta Fix"
                        }
                    ]
                }
            ]
        }
 *
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "1",
 *       "message": "No Settings exists in the database."
 *     }
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Server Error
 *     {
 *       "error": "2",
 *       "message": "Internal sever error"
 *     }
 *
 */

router.get('/v1.0/settings/:role', SettingsControllers.getSettings);

/**
 * @api {post} /settings/add Add a setting
 * @apiName Add a setting
 * @apiGroup Settings
 *
 * @apiPermission Admin
 *
 * @apiHeader {String} x-access-code User Token
 *
 * @apiParamExample {json} Request-Example:
 * {
            "name": "radius",
            "value": "2",
 * }
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
                    "error": "0",
                    "message": "Setting added successfully.",
                    "data": {
                        "status": true,
                        "id": 6,
                        "name": "radius",
                        "value": "2",
                        "created_by": 0,
                        "updated_by": 0,
                        "created_at": "2018-10-09T12:22:57.303Z",
                        "updated_at": "2018-10-09T12:22:57.303Z"
                    }
 *              }
 *
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Server Error
 *     {
 *       "error": "1",
 *       "message": "Internal sever error"
 *     }
 *
 */

router.post('/v1.0/settings/add', requires.body, isCustomer.hasAdminRole, SettingsControllers.addSetting);



/**
 * @api {post} /settings/update/:setting_id Update a setting
 * @apiName Update a setting
 * @apiGroup Settings
 *
 * @apiPermission Admin
 *
 * @apiHeader {String} x-access-code User Token
 *
 * @apiParamExample {json} Request-Example:
 * {
            "name": "radius",
            "value": "2", // meeters
            "status": false // add this key for soft delete of a setting 
 * }
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
            "error": "0",
            "message": "Feedbacks data",
            "data":{
                    "error": "0",
                    "message": "Setting added successfully.",
                    "data": {
                        "id": 6,
                        "name": "radius",
                        "value": "2",
                    }
                }
                }
            ]
        }
 *
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Server Error
 *     {
 *       "error": "1",
 *       "message": "Internal sever error"
 *     }
 *
 */

router.post('/v1.0/settings/update/:setting_id', requires.body, isCustomer.hasAdminRole, SettingsControllers.updateSetting);

/**
 * @api {get} /get_states Get States list
 * @apiName Get States list
 * @apiGroup Settings
 *
 * @apiPermission Admin
 *
 * @apiHeader {String} x-access-code User Token
 *

 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
    "error": "0",
    "message": "States found.",
    "data": [
        {
            "name": "Andhra Pradesh",
            "code": "02"
        },
        {
            "name": "Manipur",
            "code": "17"
        },
        {
            "name": "Himachal Pradesh",
            "code": "11"
        },
        {
            "name": "Jharkhand",
            "code": "38"
        },
        {
            "name": "Punjab",
            "code": "23"
        },
        {
            "name": "Tamil Nadu",
            "code": "25"
        }
    ]
 * }
 *
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Server Error
 *     {
 *       "error": "1",
 *       "message": "Internal sever error"
 *     }
 *
 */
router.get('/v1.0/get_states', isCustomer.authenticated, settingsController.getStates);

/**
 * @api {get} /get_cities/:state_code Get Cities list by state code
 * @apiName Get Cities list
 * @apiGroup Settings
 *
 * @apiPermission Admin
 *
 * @apiHeader {String} x-access-code User Token
 *

 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
    "error": "0",
    "message": "Cities found.",
    "data": [
        {
            "name": "Zahirabad",
            "state_code": "40"
        },
        {
            "name": "Yellandu",
            "state_code": "40"
        },
        {
            "name": "Warangal",
            "state_code": "40"
        },
        {
            "name": "Wanparti",
            "state_code": "40"
        }
    ]
 * }
 *
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Server Error
 *     {
 *       "error": "1",
 *       "message": "Internal sever error"
 *     }
 *
 */
router.get('/v1.0/get_cities/:state_code', isCustomer.authenticated, settingsController.getCities);

/**
 * @api {get} /times Get Times data
 * @apiName Get Times data
 * @apiGroup Settings
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
    "error": "0",
    "message": "Times data.",
    "data": [
        '00:00', ...etc
    ]
 * }
 */

router.get('/v1.0/times', settingsController.getTimes);



/**
 * @api {put} /settings/update/group Update multiple settings 
 * @apiName Update multiple setting
 * @apiGroup Settings
 *
 * @apiPermission Admin
 *
 * @apiHeader {String} x-access-code User Token
 *
 * @apiParamExample {json} Request-Example:
 * [
	{
		"id": 6,
		"value": "1"
	},{
		"id": 7,
		"value": "10"
	}
* ]
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
    "error": "0",
    "message": "Updated Successfully.",
    "data": [
        {
            "id": 6,
            "value": "1",
            "is_updated": true
        },
        {
            "id": 7,
            "value": "10",
            "is_updated": true
        }
    ]
 * }
 *
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Server Error
 *     {
 *       "error": "1",
 *       "message": "Internal sever error"
 *     }
 *
 */

router.put('/v1.0/settings/update/group', requires.body, isCustomer.hasAdminRole, settingsController.updateGroup);

export default router;