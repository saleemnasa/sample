import { STATES } from 'mongoose';

'use strict';
const Sequelize = require('sequelize');
const Setting = require('../../models').settings;
const States = require('../../models').states;
const Cities = require('../../models').cities;
const Op = Sequelize.Op;


const findAll = (query) => {
    return Setting.findAll({
        where: query.where,
        offset: query.offset,
        limit: query.limit,
    });
}

const create = (data) => {
    return Setting.create(data);
}

const update = (data) => {
    return Setting.update(data.data, data.where);
}

const count = (where) => {
    return Setting.count(where);
}

const getStates = (where) => {
    return States.findAll(where);
}

const getCities = (where) => {
    return Cities.findAll(where);
}
export default {
    findAll,
    create,
    update,
    count,
    getStates,
    getCities
};