'use strict';
import Promise from 'bluebird';

Promise.config({
    longStackTraces: true,
    warnings: true // note, run node with --trace-warnings to see full stack traces for warnings
})

module.exports = (sequelize, DataTypes) => {

    var Otps = sequelize.define('otps', {

        last_mobile: {
            type: DataTypes.BIGINT,
            allowNull: false,
            validate: {
                len: [10, 10]
            }
        },
        mobile: {
            type: DataTypes.BIGINT,
            allowNull: false,
            validate: {
                len: [10, 10]
            }
        },
        otp: {
            type: DataTypes.INTEGER,
            allowNull: false,
            validate: {
                len: [6, 6]
            }
        },
        created_by: {
            type: DataTypes.STRING,
            allowNull: true
        },
        updated_by: {
            type: DataTypes.STRING,
            allowNull: true
        },
        status: {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: true
        },
    }, {
            underscored: true
        });
    return Otps;
};