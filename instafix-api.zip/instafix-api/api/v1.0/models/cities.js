'use strict';
import Promise from 'bluebird';

Promise.config({
    longStackTraces: true,
    warnings: true // note, run node with --trace-warnings to see full stack traces for warnings
})

module.exports = (sequelize, DataTypes) => {

    var Cities = sequelize.define('cities', {
        geonameid: {
            type: DataTypes.STRING
        },
        name: {
            type: DataTypes.STRING
        },

        asciiname: {
            type: DataTypes.STRING
        },
        latitude: {
            type: DataTypes.STRING
        },
        longitude: {
            type: DataTypes.STRING
        },
        feature_class: {
            type: DataTypes.STRING
        },
        feature_code: {
            type: DataTypes.STRING
        },
        country_code: {
            type: DataTypes.STRING
        },
        cc2: {
            type: DataTypes.STRING
        },
        admin1_code: {
            type: DataTypes.STRING
        },
        admin2_code: {
            type: DataTypes.STRING
        },
        admin3_code: {
            type: DataTypes.STRING
        },
        admin4_code: {
            type: DataTypes.STRING
        },
        population: {
            type: DataTypes.STRING
        },
        elevation: {
            type: DataTypes.STRING
        },
        dem: {
            type: DataTypes.STRING
        },
        timezone: {
            type: DataTypes.STRING
        },
        modification_date: {
            type: DataTypes.STRING
        },
        status: {
            type: DataTypes.BOOLEAN,
            defaultValue: true
        },
        created_by: {
            type: DataTypes.INTEGER,
            allowNull: true
        },
        updated_by: {
            type: DataTypes.INTEGER,
            allowNull: true
        }
    });
    Cities.associate = function (models) {
    };

    return Cities;
};