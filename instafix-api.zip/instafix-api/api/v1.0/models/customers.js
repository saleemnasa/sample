'use strict';
import Promise from 'bluebird';

Promise.config({
    longStackTraces: true,
    warnings: true // note, run node with --trace-warnings to see full stack traces for warnings
})

module.exports = (sequelize, DataTypes) => {
    var Customers = sequelize.define('customers', {
        first_name: {
            type: DataTypes.STRING(32),
            allowNull: false,
            validate: {
                notEmpty: true,
                len: [1, 20]
            }
        },
        last_name: {
            type: DataTypes.STRING(32),
            allowNull: false,
            validate: {
                notEmpty: true,
                len: [1, 20]
            }
        },
        name: {
            type: DataTypes.TEXT,
            allowNull: true,
            get() {
                const first_name = this.getDataValue('first_name');
                const last_name = this.getDataValue('last_name');
                // 'this' allows you to access attributes of the instance
                return first_name + ' ' + last_name;
            },
        },
        mobile: {
            type: DataTypes.BIGINT,
            allowNull: false,
            unique: true,
            validate: {
                len: [10, 10]
            }
        },
        email: {
            type: DataTypes.STRING,
            allowNull: false,
            unique: true,
            validate: {
                isEmail: true,
                notEmpty: true
            },
            set: function (val) {
                this.setDataValue('email', val.toLowerCase());
            }
        },
        gender: {
            type: DataTypes.ENUM,
            values: ['MALE', 'FEMALE', 'OTHER'],
            allowNull: true
        },
        customer_id: {
            type: DataTypes.STRING(10),
            allowNull: false,
            unique: true,
            validate: {
                isAlphanumeric: true,
                isUppercase: true
            }
        },
        address_id: {
            type: DataTypes.INTEGER,
            allowNull: true
        },
        profile_pic: {
            type: DataTypes.STRING,
            allowNull: true
        },
        password: {
            type: DataTypes.STRING,
            allowNull: false
        },
        signup_from: {
            type: DataTypes.STRING,
            allowNull: false
        },
        created_by: {
            type: DataTypes.STRING,
            allowNull: true
        },
        userType: {
            type: DataTypes.STRING,
            defaultValue: "customer"
        },
        updated_by: {
            type: DataTypes.STRING,
            allowNull: true
        },
        is_verified: {
            type: DataTypes.BOOLEAN,
            defaultValue: false
        },
        is_mobile_verified: {
            type: DataTypes.BOOLEAN,
            defaultValue: false
        },
        is_email_verified: {
            type: DataTypes.BOOLEAN,
            defaultValue: false
        },
        mobile_verified_on: {
            type: DataTypes.DATE
        },
        email_verified_on: {
            type: DataTypes.DATE
        },
        otp: {
            type: DataTypes.INTEGER,
            validate: {
                len: [6, 6]
            }
        },
        block: {
            type: DataTypes.BOOLEAN,
            defaultValue: true
        },
        status: {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: true
        },

    }, {
            underscored: true
        });

    Customers.associate = function (models) {
        // associations can be defined here
        Customers.belongsTo(models.addresses, {
            foreignKey: 'address_id',
            onDelete: 'CASCADE',
            as: 'address'
        });

        Customers.hasMany(models.feedbacks, {
            foreignKey: 'customer_id',
            as: 'feedback'
        });

    };

    return Customers;
};