'use strict';
import Promise from 'bluebird';

Promise.config({
    longStackTraces: true,
    warnings: true // note, run node with --trace-warnings to see full stack traces for warnings
})

module.exports = (sequelize, DataTypes) => {

    var Pages = sequelize.define('pages', {
        page_name: {
            type: DataTypes.STRING,
            allowNull: true,
            unique: true
        },
        title: {
            type: DataTypes.STRING,
            allowNull: true
        },
        content: {
            type: DataTypes.TEXT,
            allowNull: true
        },
        status: {
            type: DataTypes.BOOLEAN,
            defaultValue: true
        },
        created_by: {
            type: DataTypes.INTEGER,
            allowNull: true
        },
        updated_by: {
            type: DataTypes.INTEGER,
            allowNull: true
        }
    }, {
            underscored: true
        });
    Pages.associate = function (models) {
    };

    return Pages;
};