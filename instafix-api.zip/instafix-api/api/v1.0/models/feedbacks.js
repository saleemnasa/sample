'use strict';
import Promise from 'bluebird';

Promise.config({
    longStackTraces: true,
    warnings: true // note, run node with --trace-warnings to see full stack traces for warnings
})

module.exports = (sequelize, DataTypes) => {
    var Feedbacks = sequelize.define('feedbacks', {

        customer_id: {
            type: DataTypes.INTEGER,
            allowNull: false
        },
        feedback_title: {
            type: DataTypes.STRING,
            allowNull: true,
            // validate: {
            //     len: [5, 30]
            // }
        },
        feedback_text: {
            type: DataTypes.STRING,
            allowNull: true,
            // validate: {
            //     len: [10, 500]
            // }
        },
        feedback_type: {
            type: DataTypes.INTEGER,
            allowNull: false
        },
        reply_message: {
            type: DataTypes.STRING,
            allowNull: true
        },
        is_replied: {
            type: DataTypes.BOOLEAN,
            defaultValue: false
        },
        created_by: {
            type: DataTypes.INTEGER,
            allowNull: true
        },
        replied_by: {
            type: DataTypes.INTEGER,
            allowNull: true
        },
        status: {
            type: DataTypes.BOOLEAN,
            defaultValue: true
        }

    }, {
            underscored: true
        });

    Feedbacks.associate = function (models) {

        Feedbacks.belongsTo(models.customers, {
            foreignKey: 'customer_id',
            as: 'customer',
        });

        Feedbacks.belongsTo(models.feedback_categories, {
            foreignKey: 'feedback_type',
            as: 'feedback_categories'
        });
    };

    return Feedbacks;
};