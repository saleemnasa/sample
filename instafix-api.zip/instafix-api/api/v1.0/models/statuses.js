'use strict';
import Promise from 'bluebird';

Promise.config({
    longStackTraces: true,
    warnings: true
})

module.exports = (sequelize, DataTypes) => {
    var Statuses = sequelize.define('statuses', {

        technician_id: {
            type: DataTypes.INTEGER,
            allowNull: false
        },
        reason: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        verification_status_from:{
            type: DataTypes.ENUM('verified', 'pending', 'rejected'),
            defaultValue: null,
            allowNull: true,
        },
        verification_status_to:{
            type: DataTypes.ENUM('verified', 'pending', 'rejected'),
            defaultValue: null,
            allowNull: true,
        },
        status: {
            type: DataTypes.BOOLEAN,
            defaultValue: true
        },
        verified_by:{
            type: DataTypes.INTEGER,
            allowNull: false
        }

    }, { underscored: true });

    Statuses.associate = function (models) {

        Statuses.belongsTo(models.customers, {
            foreignKey: 'verified_by',
            as: 'customer',
        });

        Statuses.belongsTo(models.technicians, {
            foreignKey: 'technician_id',
            as: 'technicians'
        });
    };

    return Statuses;
};