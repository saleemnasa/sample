'use strict';
import Promise from 'bluebird';

Promise.config({
    longStackTraces: true,
    warnings: true // note, run node with --trace-warnings to see full stack traces for warnings
})

module.exports = (sequelize, DataTypes) => {
    var Technicians = sequelize.define('technicians', {
        first_name: {
            type: DataTypes.STRING(32),
            allowNull: false,
            validate: {
                len: [2, 32],
                is: /^[a-zA-Z ]*$/i,
            }
        },
        last_name: {
            type: DataTypes.STRING(32),
            allowNull: true,
            validate: {
                is: /^[a-zA-Z ]*$/i,
            }
        },
        name: {
            type: DataTypes.TEXT,
            allowNull: true,
            get() {
                const first_name = this.getDataValue('first_name');
                const last_name = this.getDataValue('last_name');
                // 'this' allows you to access attributes of the instance
                return first_name + ' ' + last_name;
            },
        },
        email: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        gender: {
            type: DataTypes.ENUM,
            values: ['MALE', 'FEMALE', 'OTHER'],
            allowNull: true
        },
        mobile: {
            type: DataTypes.BIGINT,
            allowNull: false,
            unique: true,
            validate: {
                len: [10, 10]
            }
        },
        technician_id: {
            type: DataTypes.STRING(10),
            allowNull: false,
            unique: true,
            validate: {
                isAlphanumeric: true,
                isUppercase: true
            }
        },
        address_id: {
            type: DataTypes.INTEGER,
            allowNull: true,
            unique: true
        },
        pan: {
            type: DataTypes.STRING,
            allowNull: true,
            defaultValue: null
        },
        aadhar: {
            type: DataTypes.BIGINT,
            allowNull: true,
            defaultValue: null
        },
        aadhar_front: {
            type: DataTypes.STRING,
            allowNull: true,
            defaultValue: null
        },
        aadhar_back: {
            type: DataTypes.STRING,
            allowNull: true,
            defaultValue: null
        },
        profile_pic: {
            type: DataTypes.STRING,
            allowNull: true
        },
        password: {
            type: DataTypes.STRING,
            allowNull: true
        },
        signup_from: {
            type: DataTypes.STRING,
            allowNull: false
        },
        user_type: {
            type: DataTypes.ENUM,
            values: ['customer', 'technician', 'admin', 'guest']
        },
        created_by: {
            type: DataTypes.INTEGER,
            allowNull: true
        },
        updated_by: {
            type: DataTypes.INTEGER,
            allowNull: true
        },
        is_verified: {
            type: DataTypes.ENUM('verified', 'pending', 'rejected'),
            defaultValue: 'pending'
        },
        is_mobile_verified: {
            type: DataTypes.BOOLEAN,
            defaultValue: false
        },
        is_email_verified: {
            type: DataTypes.BOOLEAN,
            defaultValue: false
        },
        mobile_verified_on: {
            type: DataTypes.DATE
        },
        email_verified_on: {
            type: DataTypes.DATE
        },
        otp: {
            type: DataTypes.INTEGER,
            allowNull: true,
            validate: {
                len: [6, 6]
            }
        },
        block: {
            type: DataTypes.BOOLEAN,
            defaultValue: true
        },
        status: {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: true
        },
        distributor_city: {
            type: DataTypes.STRING,
            allowNull: true
        },
        distributor_state: {
            type: DataTypes.STRING,
            allowNull: true
        },
        verified_on: {
            type: DataTypes.DATE,
            allowNull: true
        },
        country_code: {
            type: DataTypes.INTEGER,
            validate: {
                len: [2, 2]
            }
        }

    }, {
            underscored: true
        });
    Technicians.associate = function (models) {
        // associations can be defined here
        Technicians.belongsTo(models.addresses, {
            foreignKey: 'address_id',
            onDelete: 'CASCADE',
            as: 'address'
        });

        Technicians.belongsToMany(models.services, {
            as: 'services',
            through: 'technician_services',
            foreignKey: 'technician_id'
        });
    };

    return Technicians;
};