'use strict';
import Promise from 'bluebird';

Promise.config({
    longStackTraces: true,
    warnings: true // note, run node with --trace-warnings to see full stack traces for warnings
})

module.exports = (sequelize, DataTypes) => {
    var FeedbackCategories = sequelize.define('feedback_categories', {

        name: {
            type: DataTypes.STRING,
            allowNull: false,
            validate: {
                len: [5, 30]
            }
        },
        created_by: {
            type: DataTypes.INTEGER,
            allowNull: true
        },
        updated_by: {
            type: DataTypes.INTEGER,
            allowNull: true
        },
        status: {
            type: DataTypes.BOOLEAN,
            defaultValue: true
        }

    }, {
            underscored: true
        });

    FeedbackCategories.associate = function (models) {

        FeedbackCategories.hasMany(models.feedbacks, {
            foreignKey: 'feedback_type',
            as: 'feedbacks',
        });
    };

    return FeedbackCategories;
};