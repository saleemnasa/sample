'use strict';
import Promise from 'bluebird';

Promise.config({
    longStackTraces: true,
    warnings: true // note, run node with --trace-warnings to see full stack traces for warnings
})

module.exports = (sequelize, DataTypes) => {

    var Addresses = sequelize.define('addresses', {
        address1: {
            type: DataTypes.TEXT,
            allowNull: true
        },
        address2: {
            type: DataTypes.TEXT,
            allowNull: true
        },
        city: {
            type: DataTypes.STRING,
            allowNull: true
        },
        state: {
            type: DataTypes.STRING,
            allowNull: true
        },
        country: {
            type: DataTypes.STRING,
            allowNull: true
        },
        pin: {
            type: DataTypes.INTEGER,
            allowNull: true,
            validate: {
                len: [6, 6]
            }
        },
        latitude: {
            type: DataTypes.STRING,
            allowNull: true,
            defaultValue: null
        },
        longitude: {
            type: DataTypes.STRING,
            allowNull: true,
            defaultValue: null
        },
        location: {
            type: DataTypes.GEOMETRY('POINT'),
            allowNull: true
        },
        status: {
            type: DataTypes.BOOLEAN,
            allowNull: true,
            defaultValue: true,
        },
        created_by: {
            type: DataTypes.INTEGER,
            allowNull: true
        },
        updated_by: {
            type: DataTypes.INTEGER,
            allowNull: true
        }
    }, {
            validate: {
                bothCoordsOrNone() {
                    if ((this.latitude === null) !== (this.longitude === null)) {
                        throw new Error('Require either both latitude and longitude or neither')
                    }
                }
            },
            underscored: true
        });
    Addresses.associate = function (models) {
        // associations can be defined here
        Addresses.hasOne(models.customers, {
            foreignKey: 'address_id',
            as: 'customer'
        });

        Addresses.hasOne(models.technicians, {
            foreignKey: 'address_id',
            as: 'technician'
        });
    };

    return Addresses;
};