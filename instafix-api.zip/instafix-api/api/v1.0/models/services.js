'use strict';
import Promise from 'bluebird';

Promise.config({
    longStackTraces: true,
    warnings: true // note, run node with --trace-warnings to see full stack traces for warnings
})

module.exports = (sequelize, DataTypes) => {
    var Services = sequelize.define('services', {
        name: {
            type: DataTypes.STRING,
            allowNull: false
        },
        status: {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: true,
        },
        created_by: {
            type: DataTypes.INTEGER,
            allowNull: true
        },
        updated_by: {
            type: DataTypes.INTEGER,
            allowNull: true
        }
    }, {
        underscored: true
    });

    Services.associate = function(models) {
        // associations can be defined here
        Services.belongsToMany(models.technicians, {
            as: 'technicians',
            through: 'technician_services', 
            foreignKey: 'service_id' 
        });
    };

    return Services;
};