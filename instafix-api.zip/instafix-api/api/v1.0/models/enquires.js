'use strict';
import Promise from 'bluebird';

Promise.config({
    longStackTraces: true,
    warnings: true
});

module.exports = (sequelize, DataTypes) => {
    var Enquires = sequelize.define('enquires', {
        name: {
            type: DataTypes.STRING,
            allowNull: false,
            validate: {
                len: [2, 32],
            }

        },
        email: {
            type: DataTypes.STRING,
            allowNull: false,
            validate: {
                isEmail: true,
            }

        },
        number: {
            type: DataTypes.INTEGER,
            allowNull: false,
            validate: {
                len: [10, 12],
            }

        },
        message: {
            type: DataTypes.TEXT,
            allowNull: false
        },
        source: {
            type: DataTypes.STRING,
            defaultValue: 'web'
        },
        created_by: {
            type: DataTypes.INTEGER,
            allowNull: true
        },
        updated_by: {
            type: DataTypes.INTEGER,
            allowNull: true
        }
    }, {
            underscored: true
        });
    return Enquires;
};