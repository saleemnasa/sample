'use strict';
import Promise from 'bluebird';

Promise.config({
    longStackTraces: true,
    warnings: true // note, run node with --trace-warnings to see full stack traces for warnings
})

module.exports = (sequelize, DataTypes) => {
    var Tokens = sequelize.define('tokens', {
        user_id: {
            type: DataTypes.INTEGER,
            allowNull: false
        },
        token: {
            type: DataTypes.TEXT,
            allowNull: false
        },
        login_type: {
            type: DataTypes.STRING,
            allowNull: false
        }
    }, {
        underscored: true
    });

    return Tokens;
};