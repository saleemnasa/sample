'use strict';
import Promise from 'bluebird';

Promise.config({
    longStackTraces: true,
    warnings: true // note, run node with --trace-warnings to see full stack traces for warnings
})

module.exports = (sequelize, DataTypes) => {

    var States = sequelize.define('states', {
        countryId: {
            type: DataTypes.STRING
        },
        adminCode1: {
            type: DataTypes.STRING
        },
        countryName: {
            type: DataTypes.STRING
        },
        fclName: {
            type: DataTypes.STRING
        },
        countryCode: {
            type: DataTypes.STRING
        },
        lng: {
            type: DataTypes.STRING
        },
        fcodeName: {
            type: DataTypes.STRING
        },
        toponymName: {
            type: DataTypes.STRING
        },
        fcl: {
            type: DataTypes.STRING
        },
        numberOfChildren: {
            type: DataTypes.INTEGER
        },
        name: {
            type: DataTypes.STRING
        },
        fcode: {
            type: DataTypes.STRING
        },
        geonameId: {
            type: DataTypes.INTEGER
        },
        lat: {
            type: DataTypes.STRING
        },
        adminName1: {
            type: DataTypes.STRING
        },
        population: {
            type: DataTypes.INTEGER
        },
        status: {
            type: DataTypes.BOOLEAN,
            defaultValue: true
        },
        created_by: {
            type: DataTypes.INTEGER,
            allowNull: true
        },
        updated_by: {
            type: DataTypes.INTEGER,
            allowNull: true
        }
    });
    States.associate = function (models) {
    };

    return States;
};