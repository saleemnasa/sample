'use strict';
import Promise from 'bluebird';

Promise.config({
    longStackTraces: true,
    warnings: true
});

module.exports = (sequelize, DataTypes) => {
    var Settings = sequelize.define('settings', {
        name: {
            type: DataTypes.STRING,
            allowNull: false,
            unique: true
        },
        value: {
            type: DataTypes.STRING,
            allowNull: true
        },
        status: {
            type: DataTypes.BOOLEAN,
            defaultValue: true
        },
        created_by: {
            type: DataTypes.INTEGER,
            allowNull: true
        },
        updated_by: {
            type: DataTypes.INTEGER,
            allowNull: true
        }
    });
    return Settings;
};