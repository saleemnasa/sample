'use strict';

import FeedbackService from '../services/feedbacks.services';
const Sequelize = require('sequelize');
const Op = Sequelize.Op;

const add = (req, res) => {
    let data = req.body;
    let {
        userID
    } = req.decoded;

    data.customer_id = +userID;

    FeedbackService.create(data)
        .then(response => {
            res.status(200).json({
                error: "0",
                message: "Feedback added",
                data: response
            });
        })
        .catch(error => {
            console.log(error);
            res.status(500).json({
                error: "1",
                message: "Error: " + error.errors[0].message
            });
        })
}

const getCountByCustomer = (req, res) => {

    let {
        customerID
    } = req.params, query = {};

    query.customer_id = customerID;

    FeedbackService.count(query)
        .then((response) => {
            let count = response;
            let data = {
                customers: count
            }
            res.status(200).json({
                error: "0",
                message: "Data fetch successful",
                data: data
            });
        })
        .catch((error) => {
            console.log(error)
            res.status(500).json({
                error: "1",
                message: "Error in fetching data"
            });
        });
}

const getFeedbacks = (req, res) => {

    let query = {};
    query.where = {};
    let {
        limit,
        offset,
        q,
        fbc_name
    } = req.query;

    if (q) {
        query.where = {
            [Op.or]: [
                {
                    feedback_title: {
                        $like: '%' + q + '%'
                    }
                },
                {
                    feedback_text: {
                        $like: '%' + q + '%'
                    }
                },
                {
                    '$feedback_categories.name$': {
                        $like: '%' + q + '%'
                    }
                },
                {
                    '$customer.name$': {
                        $like: '%' + q + '%'
                    }
                },
                {
                    '$customer.mobile$': {
                        $like: '%' + q + '%'
                    }
                }
            ],
        }

    } else if (fbc_name) {
        query.where = {
            '$feedback_categories.name$': fbc_name
        }
    } else {

    }


    if (limit)
        query.limit = +limit || undefined;
    if (offset)
        query.offset = +offset || undefined;

    FeedbackService.findAll(query)
        .then(response => {
            if (response) {
                res.status(200).json({
                    error: '0',
                    message: "Feedbacks data",
                    data: response
                });
            } else {
                res.status(400).json({
                    error: '1',
                    message: "No feedbacks exists in the database"
                });
            }
        })
        .catch(error => {
            console.log(error)
            res.status(500).json({
                error: '1',
                message: "Internal sever error"
            });
        });
}

const getFeedbackDetails = (req, res) => {

    let query = {};
    let {
        feedback_id
    } = req.params;

    query = { id: +feedback_id };
    FeedbackService.findFeedback(query)
        .then(response => {
            if (response) {
                res.status(200).json({
                    error: '0',
                    message: "Feedback data",
                    data: response
                });
            } else {
                res.status(400).json({
                    error: '1',
                    message: "No feedback exists in the database"
                });
            }
        })
        .catch(error => {
            console.log(error)
            res.status(500).json({
                error: '1',
                message: "Internal sever error"
            });
        });
}

const replyFeedback = (req, res) => {
    let data = req.body,
        query = {};

    if (!data.id)
        return res.status(500).json({
            error: '2',
            message: "feedback id needed"
        });

    query.where = { id: data.id }
    if (data.reply_message)
        data.is_replied = true;

    FeedbackService.update(data, query)
        .then(response => {
            if (response[0])
                res.status(200).json({
                    error: '0',
                    message: "Feedback updated."
                });
            else
                res.status(400).json({
                    error: '2',
                    message: "Feedback not found."
                });

        })
        .catch(error => {
            console.log(error)
            res.status(500).json({
                error: '1',
                message: "Error: " + error.errors[0].message
            });
        });
}

export default {
    add,
    getFeedbacks,
    getFeedbackDetails,
    getCountByCustomer,
    replyFeedback
}