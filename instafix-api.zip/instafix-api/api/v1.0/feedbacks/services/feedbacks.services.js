'use strict';
const Sequelize = require('sequelize');
const Feedback = require('../../models').feedbacks;
const Customer = require('../../models').customers;
const FeedbackCategory = require('../../models').feedback_categories;
const Op = Sequelize.Op;

const findOneFeedback = (query, selectable) => {
    return Feedback.findOne({
        where: query,
        attributes: selectable
    });
}

const findFeedback = (query) => {
    return Feedback.findOne({
        where: query,
        include: {
            model: Customer,
            where: {
                id: Sequelize.col('feedbacks.customer_id')
            },
            attributes: ['first_name', 'last_name', 'mobile', 'email'],
            as: 'customer'
        }
    });
}

const find = (query) => {
    return Feedback.find(query);
}

const findAll = (query) => {
    return Feedback.findAll({
        where: query.where,
        include: [{
            model: Customer,
            where: {
                id: Sequelize.col('feedbacks.customer_id')
            },
            attributes: { exclude: ['password', 'created_at', 'updated_at', 'otp', 'block', 'updated_by', 'created_by', 'userType', 'is_verified', 'is_mobile_verified', 'is_email_verified', 'mobile_verified_on', 'email_verified_on'] },
            as: 'customer'
        }, {
            model: FeedbackCategory,
            attributes: { exclude: ['status', 'created_by', 'updated_by', 'created_at', 'updated_at'] },
            as: 'feedback_categories'
        }],
        offset: query.offset,
        limit: query.limit,
        order: [
            ['created_at', 'DESC']
        ]
    });
}

const create = (data) => {
    return Feedback.create(data);
}

const update = (data, query) => {
    return Feedback.update(data, query);
}

const updateMany = (query, data) => {
    return Feedback.updateMany(query, data);
}

const remove = (query) => {
    return Feedback.remove(query);
}

const count = (query) => {
    return Feedback.count(query);
}

export default {
    findFeedback,
    findOneFeedback,
    create,
    find,
    findAll,
    update,
    updateMany,
    remove,
    count
};