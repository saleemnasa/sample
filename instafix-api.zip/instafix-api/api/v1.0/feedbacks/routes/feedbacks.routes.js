'use strict';

import express from 'express';
import FeedbackController from '../controllers/feedbacks.controller';
import {
    isCustomer,
    requires
} from '../../auth/auth.service';

let router = express.Router();

/**
 * @api {get} /feedbacks?limit=10&offset=0 Feedbacks list
 * @apiName Feedbacks list
 * @apiGroup Feedbacks
 *
 * @apiPermission Admin
 *
 * @apiHeader {String} x-access-code User Token
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
            "error": "0",
            "message": "Feedbacks data",
            "data": [
                        {
                            "id": 1,
                            "customer_id": 2,
                            "feedback_title": "feed back 2",
                            "feedback_text": "feed back 2",
                            "feedback_type": 0,
                            "reply_message": null,
                            "is_replied": false,
                            "created_by": null,
                            "replied_by": null,
                            "status": true,
                            "created_at": "2018-10-04T06:12:35.000Z",
                            "updated_at": "2018-10-04T06:12:35.000Z",
                            "customer": {
                                "id": 2,
                                "first_name": "Suresh",
                                "last_name": "Koduri",
                                "email": "sureshkoduri36@gmail.com",
                                "gender": null,
                                "mobile": 9885224116,
                                "customer_id": "CUST100002",
                                "address_id": null,
                                "profile_pic": null,
                                "signup_from": "mobile",
                                "status": true
                            }
                        },
                        {
                            "id": 2,
                            "customer_id": 1,
                            "feedback_title": "feed back 1",
                            "feedback_text": "feed back 1",
                            "feedback_type": 0,
                            "reply_message": null,
                            "is_replied": false,
                            "created_by": null,
                            "replied_by": null,
                            "status": true,
                            "created_at": "2018-10-04T06:12:46.000Z",
                            "updated_at": "2018-10-04T06:12:46.000Z",
                            "customer": {
                                "id": 1,
                                "first_name": "Admin",
                                "last_name": "Admin",
                                "email": "admin@sparity.com",
                                "gender": null,
                                "mobile": 9999999999,
                                "customer_id": "CUST100001",
                                "address_id": null,
                                "profile_pic": null,
                                "signup_from": "mobile",
                                "status": true
                            }
                        }
                    ]
                }
            ]
        }
 *
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "1",
 *       "message": "No feedbacks exists in the database."
 *     }
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Server Error
 *     {
 *       "error": "2",
 *       "message": "Internal sever error"
 *     }
 *
 */

router.get('/v1.0/feedbacks', isCustomer.hasAdminRole, FeedbackController.getFeedbacks);

/**
 * @api {get} /feedbacks/:feedback_id Get Feedback by ID
 * @apiName Get Feedback by ID
 * @apiGroup Feedbacks
 *
 * @apiPermission Admin
 *
 * @apiHeader {String} x-access-code User Token
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
            "error": "0",
            "message": "Feedback data",
            "data": 
                    {
                        "id": 1,
                        "customer_id": 2,
                        "feedback_title": "feed back 2",
                        "feedback_text": "feed back 2",
                        "feedback_type": 0,
                        "reply_message": null,
                        "is_replied": false,
                        "created_by": null,
                        "replied_by": null,
                        "status": true,
                        "created_at": "2018-10-04T06:12:35.000Z",
                        "updated_at": "2018-10-04T06:12:35.000Z",
                        "customer": {
                            "id": 2,
                            "first_name": "Suresh",
                            "last_name": "Koduri",
                            "email": "sureshkoduri36@gmail.com",
                            "gender": null,
                            "mobile": 9885224116,
                            "customer_id": "CUST100002",
                            "address_id": null,
                            "profile_pic": null,
                            "signup_from": "mobile",
                            "status": true
                        }
                    
                    }
            
        }
 *
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "1",
 *       "message": "No feedback exists in the database."
 *     }
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Server Error
 *     {
 *       "error": "2",
 *       "message": "Internal sever error"
 *     }
 *
 */

router.get('/v1.0/feedbacks/:feedback_id', isCustomer.hasAdminRole, FeedbackController.getFeedbackDetails);

/**
 * @api {post} /feedbacks/add Add Feedback
 * @apiName Add Feedback
 * @apiGroup Feedbacks
 *
 * @apiPermission Mobile
 * 
 * @apiHeader {String} x-request-from value: mobile
 * @apiHeader {String} x-access-code value: token
 *
 * @apiParamExample {json} Request-Example:
 *     {
            customer_id: Number,         // required,
            feedback_title: String,     // required
            feedback_text: Text,     // required,
            feedback_type: Number,      // required,
 *     }
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 201 OK
 *     {
            "error": "0",
            "message": "Feedback added",
            "data": {
                "is_replied": false,
                "status": true,
                "id": 1,
                "customer_id": "1",
                "feedback_title": "testtitle1112",
                "feedback_text": "this is text",
                "feedback_type": "query12",
                "updated_at": "2018-10-03T11:53:45.224Z",
                "created_at": "2018-10-03T11:53:45.224Z"
            }
        }
 *
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 400 Bad Request
 *     {
 *       "error": "1",
 *       "message": "Error: {message}"
 *     }
 * 
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Bad Request
 *     {
 *       "error": "2",
 *       "message": "Internal server error"
 *     }
 *
 */

router.post('/v1.0/feedbacks/add', isCustomer.authenticated, requires.body, FeedbackController.add);

/**
 * @api {post} /feedbacks/reply Reply Feedback
 * @apiName Reply Feedback
 * @apiGroup Feedbacks
 *
 * @apiPermission Admin
 * 
 * @apiHeader {String} x-access-code value: token
 *
 * @apiParamExample {json} Request-Example:
 *     {
            id: Number,         // required,
            reply_message: Text,      // required,
 *     }
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 201 OK
 *     {
            "error": "0",
            "message": "Feedback updated."
        }
 *
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Server error
 *     {
 *       "error": "1",
 *       "message": "Error: {message}"
 *     }
 * 
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 400 Bad Request
 *     {
 *       "error": "2",
 *       "message": "Feedback not found"
 *     }
 *
 */

router.post('/v1.0/feedbacks/reply', isCustomer.hasAdminRole, requires.body, FeedbackController.replyFeedback);

export default router;