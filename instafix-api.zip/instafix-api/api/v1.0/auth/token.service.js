'use strict';

const Token = require('../models').tokens;

const findOne = (query, selectable) => {
    return Token.findOne(query).select(selectable).exec();
}

const find = (query) => {
    return Token.find(query).exec();
}

const create = (data) => {
    return Token.create(data);
}

const update = (query, data) => {
    return Token.findOneAndUpdate(query, data, { new: true }).exec();
}

const remove = (query) => {
    return Token.remove(query).exec();
}

export default {
    findOne,
    create,
    find,
    update,
    remove
};