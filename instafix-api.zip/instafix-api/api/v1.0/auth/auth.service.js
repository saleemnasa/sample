'use strict';

import _ from 'lodash';

import { decodeJwtToken } from '../../../common/utils.js';

let isCustomer = {};

isCustomer.authenticated = (req, res, next) => {
    const token = req.headers['x-access-code'];
    if (!token)
        return res.status(401).json({ success: false, message: "You are not authorised." });

    decodeJwtToken(token)
        .then(decoded => {
            req.decoded = decoded.data;
            next();
            return null;
        })
        .catch((error) => {
            res.status(401).json({ success: false, message: "Your Login Token Expired. Please Login." });
        });

};

isCustomer.hasCustomerID = (req, res, next) => {
    const token = req.headers['x-access-code'];
    if (!token)
        return next();

    decodeJwtToken(token)
        .then(decoded => {
            req.userID = decoded.data.userID;
            next();
            return null;
        })
        .catch((error) => {
            next();
        });

};

isCustomer.hasAdminRole = (req, res, next) => {
    const token = req.headers['x-access-code'];
    if (!token)
        return res.status(401).json({ success: false, message: "You are not authorised." });

    decodeJwtToken(token)
        .then(decoded => {
            req.decoded = decoded.data;
            req.userID = decoded.data.userID;
            let role = decoded.data.role;
            if (role == 'admin' || role == 'modifier') {
                next();
                return null;
            } else
                res.status(401).json({ success: false, message: "You don't have access." });
        })
        .catch((error) => {
            res.status(401).json({ success: false, message: "Your Login Token Expired. Please Login." });
        });

};

isCustomer.hasMasterRole = (req, res, next) => {
    const token = req.headers['x-access-code'];
    if (!token)
        return res.status(401).json({ success: false, message: "You are not authorised." });

    decodeJwtToken(token)
        .then(decoded => {
            req.decoded = decoded.data;
            let role = decoded.data.role;
            if (role == 'admin') {
                next();
                return null;
            } else
                return res.status(401).json({ success: false, message: "You don't have access." });
        })
        .catch((error) => {
            res.status(401).json({ success: false, message: "Your Login Token Expired. Please Login." });
        });

};

isCustomer.hasToken = (req, res, next) => {
    const token = req.headers['x-url-token'];
    if (!token)
        return next();

    decodeUrl(token)
        .then(decoded => {
            req.userID = decoded.data.userID;
            next();
            return null;
        })
        .catch((error) => {
            next();
        });

}

let requires = {};

requires.body = (req, res, next) => {
    if (!_.isEmpty(req.body)) next();
    else res.json({ success: false, message: 'Request Body is Empty. Please Provide Data.' });
};

export {
    isCustomer,
    requires
};