'use strict';

// import emailValidator from "email-validator";
// import crypto from 'crypto';
const Sequelize = require('sequelize');
const Op = Sequelize.Op;
import TechnicianService from '../services/technicians.services';
import StatusesService from '../services/statuses.services';
// import TokenService from '../../auth/token.service';
import AddressService from '../../addresses/services/addresses.services';
import Tech_Service_Service from '../../technician_services/services/technician_services.services';
const excelToJson = require('convert-excel-to-json');
import _ from 'lodash';
import {
    // generateJwtToken,
    // generateOTP,
    idGenerator,
    toTitleCase,
    // getPreSignedURL,
    deleteS3Object,
    getCoordsFromAddress
} from "../../../../common/utils";
import { decodeJwtToken } from '../../../../common/utils.js';
import statusesServices from '../services/statuses.services';

// import config from "../../../../config/config";

var multer = require('multer');
var path = require('path');
var moment = require('moment');

const START_TIME = '00:00:00';
const END_TIME = '00:00:00';

// notes

// inserting or updating of a technician happens in register, updateTechnician and upload excel. any changes related to this should be written in therse 3 places as of now

var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './public/excels/')
    },
    filename: function (req, file, cb) {
        cb(null, file.fieldname + "_" + Date.now() + "_" + file.originalname);
    }
});


const upload = multer({
    storage: storage,
    fileFilter: function (req, file, callback) {
        var ext = path.extname(file.originalname);
        if (ext !== '.xls' && ext !== '.xlsx') {
            return callback(new Error('Only xls extensions are allowed'))
        }
        callback(null, true)
    }
}).single('file');

const register = (req, res) => {
    let data = req.body;
    let userData = data;
    let files = req.files;
    let requestFrom = req.headers["x-request-from"] || 'web';
    // if (email || mobile) {
    let response_temp = null;
    // TechnicianService.count()
    //     .then(response => {
    //         let nextID = response;
    // data.technician_id = idGenerator('TECH', nextID);
    data.signup_from = requestFrom.toLowerCase();
    data.first_name = toTitleCase(data.first_name);
    data.last_name = data.last_name ? toTitleCase(data.last_name) : '';

    if (files && files.profile && files.profile.length)
        data.profile_pic = req.protocol + "://" + req.get('host') + "/" + files.profile[0].path;
    if (files && files.aadhar_front && files.aadhar_front.length)
        data.aadhar_front = req.protocol + "://" + req.get('host') + "/" + files.aadhar_front[0].path;
    if (files && files.aadhar_back && files.aadhar_back.length)
        data.aadhar_back = req.protocol + "://" + req.get('host') + "/" + files.aadhar_back[0].path;
    if (data.is_verified && data.is_verified == 'verified') {
        data.verified_on = new Date();
    }
    console.log('technician_id', data.technician_id)
    TechnicianService.create(data)
        .then(async (response) => {

            if (response) {
                response_temp = response;
                let { latitude, longitude } = data.address || {};
                if (latitude && longitude) {
                    data.address.location = { type: 'Point', coordinates: [longitude, latitude] };
                } else {
                    data.address = {};
                    let geoCodeRes = await getCoordsFromAddress(`${data && data.service ? data.service.preferred_location : data.distributor_city}`);
                    // console.log({ geoCodeRes: JSON.stringify(geoCodeRes.json.results[0].geometry.location) });
                    if (geoCodeRes && geoCodeRes.status == 200) {

                        let { geometry } = geoCodeRes.json.results && geoCodeRes.json.results.length && geoCodeRes.json.results[0];
                        if (geometry && geometry.location) {
                            let loc = geoCodeRes.json.results[0].geometry.location;
                            data.address.latitude = String(loc.lat);
                            // data.address.address2 = data.address.address2 + 'from geo code';
                            data.address.longitude = String(loc.lng);
                            data.address.location = { type: 'Point', coordinates: [String(loc.lng), String(loc.lat)] };
                        }

                    }
                }
                return AddressService.create(data.address)
            }
        })
        .then((address_res) => {
            return TechnicianService.update({ where: { technician_id: response_temp.technician_id } }, { address_id: address_res.id })
        })
        .then((update_res) => {
            return Tech_Service_Service.create({
                technician_id: response_temp.id,
                service_id: data.service.service_id,
                preferred_location: data.service.preferred_location,
                start_time: data.service.start_time || START_TIME,
                end_time: data.service.end_time || END_TIME
            })
        })
        .then((response) => {
            if (response) {
                let host = req.get('host');
                // sendVerificationMail({ name: userData.first_name, email: userData.email, token: response.token, host });
                res.status(200).json({
                    error: "0",
                    message: "Technician Register is Successful",
                    data: userData
                });
            }
        })
        .catch((err) => {
            console.log({ err });
            // if (files && files.profile && files.profile.length)
            //     deleteS3Object(files.profile[0].location);
            // if (files && files.aadhar_front && files.aadhar_front.length)
            //     deleteS3Object(files.aadhar_front[0].location);
            // if (files && files.aadhar_back && files.aadhar_back.length)
            //     deleteS3Object(files.aadhar_back[0].location);
            // let errArr = [];
            // for (let index = 0; index < err.errors.length; index++) {
            //     const element = err.errors[index];
            //     errArr.push({ message: element.message })
            // }
            // console.log(errArr)
            if (err.name == "SequelizeUniqueConstraintError" || err.name == 'SequelizeValidationError')
                res.status(400).json({
                    error: '2',
                    message: "" + err.errors[0].message
                });
            else
                res.status(500).json({
                    error: '3',
                    message: "Internal server error"
                });
        });
    // } else {
    //     res.status(400).json({
    //         error: '2',
    //         message: "Please enter a valid email or mobile number."
    //     });
    // }
}

const get_list_by_location = (req, res) => {
    let data = req.body;
    let query = {};
    query.where = data;
    let {
        limit,
        offset,
        start_time,
        end_time,
        is_verified,
    } = req.query;

    if (start_time && end_time) {
        query.where.start_time = start_time;
        query.where.end_time = end_time;
    }

    // new_where to be applied on technician table
    query.new_where = {
        status: true,
        is_verified: {
            [Op.not]: 'rejected'
        }
    };
    if (is_verified) {
        query.new_where.is_verified = is_verified;
    }

    query.limit = parseInt(limit) || undefined;
    query.offset = parseInt(offset) || undefined;
    // console.log(query);
    if (data.locality) {
        TechnicianService.findByLocality(query)
            .then(instance => {
                let temp = removeServiceArray(instance);
                res.status(200).json({
                    error: '0',
                    message: "Technicians data",
                    data: temp,
                    limit: query.limit,
                    offset: query.offset,
                    count: temp.length
                });
            })
    } else {
        TechnicianService.findByLocation(query)
            .then(instance => {
                let temp = removeServiceArray(instance);
                temp = temp.sort((a, b) => a.address.distance - b.address.distance);
                res.status(200).json({
                    error: '0',
                    message: "Technicians data",
                    data: temp,
                    limit: query.limit,
                    offset: query.offset,
                    count: temp.length
                });
            })
            .catch(error => {
                console.log(error)
                res.status(500).json({
                    error: '1',
                    message: "Internal sever error"
                });
            });
    }

}

// get list
const getTechnicians = async (req, res) => {

    let query = {};
    let {
        limit,
        offset,
        is_verified,
        bydate,
        order,
        q
    } = req.query;
    query.where = {};

    if (q) {
        query.where = {

            [Op.or]: [{
                name: {
                    $like: '%' + q + '%'
                }
            },
            {
                distributor_city: {
                    $like: '%' + q + '%'
                }
            },
            {
                distributor_state: {
                    $like: '%' + q + '%'
                }
            },
            {
                mobile: {
                    $like: '%' + q + '%'
                }
            },
            {
                is_verified: {
                    $like: '%' + q + '%'
                }
            }
            ]

        };
    }
    if (is_verified) {
        query.where.is_verified = is_verified;
    }

    if (bydate) {
        if (bydate == 'today') {
            query.where.verified_on = {
                [Op.gte]: moment().startOf('day').format("YYYY-MM-DD HH:mm:ss")
            }

        } else if (bydate == "tweek") {
            let startOf_week = moment().startOf('isoWeek').format("YYYY-MM-DD HH:mm:ss");
            let endOf_week = moment().endOf('isoWeek').format("YYYY-MM-DD HH:mm:ss");

            query.where.verified_on = {
                [Op.between]: [startOf_week, endOf_week]
            }

        } else {
            let startOf_month = moment().startOf('month').format("YYYY-MM-DD HH:mm:ss");
            let endOf_month = moment().endOf('month').format("YYYY-MM-DD HH:mm:ss");

            query.where.verified_on = {
                [Op.between]: [startOf_month, endOf_month]
            }

        }
    }

    // query.throuth_where = {
    //     [Op.or]: [{
    //         preferred_location: {
    //             $like: '%' + q + '%'
    //         }
    //     }]
    // }

    console.log('where===', query.where)

    query.limit = +limit || 10;
    query.offset = +offset || 0;

    if (query.limit > 100) query.limit = 100;

    if (order) {
        query.order = [
            [order.split('@')[0], order.split('@')[1]]
        ]
    } else {
        query.order = [
            ['created_at', 'DESC']
        ]
    }

    let count = await TechnicianService.count({ where: query.where });
    TechnicianService.findQuery(query)
        .then(response => {
            if (response) {
                let temp = removeServiceArray(response, true);
                res.status(200).json({
                    error: '0',
                    message: "Technicians data",
                    data: temp,
                    count,
                    limit: query.limit,
                    offset: query.offset,
                    order: query.order
                });
            } else {
                res.status(400).json({
                    error: '1',
                    message: "No technicians exists in the database"
                });
            }
        })
        .catch(error => {
            console.log(error)
            res.status(500).json({
                error: '1',
                message: "Internal sever error"
            });
        });
}

// update technician

const updateTechnician = async (req, res) => {
    let query = {};
    let data = req.body;
    let {
        role,
        userID
    } = req.decoded;
    let files = req.files;
    let { mobile } = req.params; // this mobile is now a technician_id key from technician data
    let new_mobile = mobile;

    if (files && files.profile && files.profile.length) {
        data.profile_pic = req.protocol + "://" + req.get('host') + "/" + files.profile[0].path;
    } else {
        delete data.profile_pic;
    }

    if (files && files.aadhar_front && files.aadhar_front.length) {
        data.aadhar_front = req.protocol + "://" + req.get('host') + "/" + files.aadhar_front[0].path;
    } else {
        delete data.aadhar_front;
    }

    if (files && files.aadhar_back && files.aadhar_back.length) {
        data.aadhar_back = req.protocol + "://" + req.get('host') + "/" + files.aadhar_back[0].path;
    } else {
        delete data.aadhar_back;
    }

    let { address, services } = data;
    if (address && address.latitude && address.longitude) {
        address.location = { type: 'Point', coordinates: [address.longitude, address.latitude] }
    } else if (services && (data.distributor_city || data.services.preferred_location)) {
        // data.address = {};
        try {
            let geoCodeRes = await getCoordsFromAddress(`${data && data.services ? data.services.preferred_location : data.distributor_city}`);
            // console.log({ geoCodeRes: JSON.stringify(geoCodeRes.json.results[0].geometry.location) });
            if (geoCodeRes && geoCodeRes.status == 200) {

                let { geometry } = geoCodeRes.json.results && geoCodeRes.json.results.length && geoCodeRes.json.results[0];
                if (geometry && geometry.location) {
                    let loc = geoCodeRes.json.results[0].geometry.location;
                    if (!data.address)
                        data.address = {};
                    data.address.latitude = String(loc.lat);
                    // data.address.address2 = data.address.address2 + 'from geo code';
                    data.address.longitude = String(loc.lng);
                    data.address.location = { type: 'Point', coordinates: [String(loc.lng), String(loc.lat)] };
                    address = data.address;
                }
            }
        } catch (err) {
            console.log(err);
        }

    }
    query.technician_id = mobile;
    query.status = true;

    if (data.is_verified && data.is_verified == 'verified') {
        data.verified_on = new Date();
    }


    // remove fields that should not be updated
    if (address) {
        delete data.address;
    }
    if (services) {
        delete data.services;
    }
    if (data.mobile) {
        // delete data.mobile;
        // new_mobile = data.mobile;
    }

    if (data.password)
        delete data.password
    if (data.service_id)
        delete data.service_id
    if (data.profile) {
        delete data.profile;
    }

    TechnicianService.findOne({ where: { technician_id: new_mobile } })
        .then(response => {
            if (response) {

                // if(role=='admin' && !data.reason 
                // && (response.is_verified=="verified" && response.is_verified!=data.is_verified) 
                // || data.is_verified=="rejected" )

                if (role != 'admin' && ((response.is_verified == 'verified' || response.is_verified == 'rejected')
                    && (data.is_verified == 'pending' || data.is_verified == 'rejected'))) {
                    console.log('no statues update')
                    delete data.is_verified;
                    return true;
                } else if (role == 'admin' && (!data.reason
                    && (((response.is_verified == "verified" || response.is_verified == "rejected") && response.is_verified != data.is_verified)
                        || data.is_verified == "rejected"))) {
                    console.log('no reason')
                    return res.status(400).json({
                        error: '1',
                        message: 'Reason should not be empty, when changing Verification Status'
                    })
                } else {

                    let statData = {
                        technician_id: response.id,
                        reason: data.reason || null,
                        verification_status_from: response.is_verified,
                        verification_status_to: data.is_verified,
                        verified_by: userID
                    }
                    return StatusesService.create(statData);
                }

            }
        })
        .then(response => {
            // if(response)
            return TechnicianService.update({ where: query }, data)
        })

        .then(async (update_res) => {
            if (update_res[0]) {
                let technician = {};
                if (address) {
                    // get address_id and update address
                    console.log({ where: { technician_id: new_mobile, status: true } })
                    TechnicianService.findQuery({ where: { technician_id: new_mobile, status: true } })
                        .then(technician_data => {
                            technician = JSON.parse(JSON.stringify(technician_data[0]));
                            return AddressService.update({ where: { id: technician.address_id, status: true } }, address)
                        })
                        .then(up_address => {
                            if (up_address[0]) {
                                if (services) {
                                    let new_service = services;
                                    if (new_service.technician_id)
                                        delete new_service.technician_id;

                                    Tech_Service_Service.update({ where: { technician_id: technician.id, service_id: Number(services.service_id) } }, new_service)
                                        .then(tech_ser => {
                                            if (tech_ser[0]) {
                                                data.address = address;
                                                data.services = services;
                                                return res.status(200).json({
                                                    error: '0',
                                                    message: 'Technician updated successfully.',
                                                    data: data
                                                })
                                            }
                                        })
                                } else {
                                    data.address = address;
                                    return res.status(200).json({
                                        error: '0',
                                        message: 'Technician data & address updated successfully.',
                                        data
                                    })
                                }


                            } else {
                                return res.status(400).json({
                                    error: '1',
                                    message: 'Technician address not found. data updated successfully',
                                    data
                                })
                            }
                        })
                } else if (services) {
                    technician = await TechnicianService.findQuery({ where: { technician_id: new_mobile, status: true } });
                    technician = JSON.parse(JSON.stringify(technician[0]));
                    let new_service = services;
                    if (new_service.technician_id)
                        delete new_service.technician_id;

                    Tech_Service_Service.update({ where: { technician_id: technician.id, service_id: Number(services.service_id) } }, new_service)
                        .then(tech_ser => {
                            console.log(tech_ser);
                            if (tech_ser[0]) {
                                data.address = address;
                                data.services = services;
                                return res.status(200).json({
                                    error: '0',
                                    message: 'Technician updated successfully.',
                                    data: data
                                })
                            }
                        })
                } else {
                    return res.status(200).json({
                        error: '0',
                        message: 'Technician updated successfully.',
                        data
                    })
                }


            } else {
                // if (files && files.profile && files.profile.length)
                //     deleteS3Object(files.profile[0].location);
                // if (files && files.aadhar_front && files.aadhar_front.length)
                //     deleteS3Object(files.aadhar_front[0].location);
                // if (files && files.aadhar_back && files.aadhar_back.length)
                //     deleteS3Object(files.aadhar_back[0].location);
                return res.status(400).json({
                    error: '1',
                    message: 'Technician not found.'
                })
            }
        })
        .catch(err => {
            console.log(err);
            res.status(500).json({
                error: '2',
                message: "" + err.errors[0].message
            });
        });

}

const deleteTechnician = (req, res) => {
    let technician = {};
    let data = req.body;
    let query = {
        id: data.id,
        status: true
    };
    let new_data = { status: false }
    TechnicianService.findQuery({ where: { id: query.id } })
        .then(technicians => {
            if (technicians.length) {
                technician = JSON.parse(JSON.stringify(technicians))[0];
                return TechnicianService.update({ where: query }, new_data)
            } else {
                res.status(400).json({
                    error: '1',
                    message: 'Technician not found.'
                })
            }

        })
        .then(tech_res => {
            return AddressService.update({ where: { id: technician.address_id } }, { status: true })
        })
        .then((deleted_res) => {
            if (deleted_res[0]) {
                res.status(200).json({
                    error: '0',
                    message: 'Technician deleted successfully.'
                })
            } else {
                res.status(400).json({
                    error: '1',
                    message: 'Technician not found.'
                })
            }

        })
        .catch(err => {
            console.log(err);
            res.status(500).json({
                error: '2',
                message: "Internal sever error"
            });
        });
}

// update address of a technician

const updateAddress = (req, res) => {
    let data = req.body;
    let { technician_id, address } = data;

    if (address && address.latitude && address.longitude) {
        address.location = { type: 'Point', coordinates: [address.longitude, address.latitude] }
    }

    TechnicianService.findQuery({ where: { id: technician_id, status: true } })
        .then(response => {
            if (response.length) {
                let technician = JSON.parse(JSON.stringify(response[0]));
                AddressService.update({ where: { id: technician.address_id, status: false } }, address)
                    .then(updated_address => {
                        if (updated_address[0]) {
                            res.status(200).json({
                                error: '0',
                                message: 'Technician address updated successfully.'
                            })
                        } else {
                            res.status(400).json({
                                error: '1',
                                message: 'Technician address not found.'
                            })
                        }
                    })
                    .catch(err => {
                        console.log(err);
                        res.status(500).json({
                            error: '2',
                            message: "Internal sever error"
                        });
                    });
            } else {
                res.status(400).json({
                    error: '3',
                    message: 'Technician not found.'
                })
            }
        })
        .catch(err => {
            console.log(err);
            res.status(500).json({
                error: '4',
                message: "Internal sever error"
            });
        });
}


const getTechnicianById = (req, res) => {
    let id = req.params.id;
    let query = {};
    query.where = {
        status: true,
        id
    };
    TechnicianService.findOne(query)
        .then(response => {
            if (response) {
                response = JSON.parse(JSON.stringify(response));
                if (response.services && response.services.length)
                    response.services = response.services[0];
                res.status(200).json({
                    error: '0',
                    message: 'Technician data.',
                    data: response
                })
            } else {
                res.status(400).json({
                    error: '1',
                    message: 'Technician not found.'
                })
            }
        })
        .catch(err => {
            console.log(err);
            res.status(500).json({
                error: '2',
                message: "Internal sever error"
            });
        });
}

// upload technicians list from excel 
const uploadExcel = async (req, res) => {
    req.setTimeout(1000 * 60 * 10); // milliseconds*sec*min
    upload(req, res, async (err) => {
        try {
            if (err) {
                return res.status(400).json({
                    error: "1",
                    message: err.message || "Something went wrong"
                });
            }

            const resData = excelToJson({
                sourceFile: req.file.path,

                header: {
                    rows: 1
                },
                columnToKey: {
                    A: "name",
                    B: "mobile",
                    C: "city",
                    D: "state"
                }
            });

            let list = [];


            resData.data = resData.Sheet1 || resData.data;

            // check for excel validations
            let invalid_data = false;
            let invalid_message = 'Invalid data found.';
            resData && resData.data && resData.data.map((item, i) => {
                // Object.keys(item).map((key) => {
                //     if (key != 'mobile')
                //         item[key] = item[key].trim() || item[key];
                // });
                if (!item.mobile || !item.name || !item.city || !item.state) {
                    invalid_data = true;
                    invalid_message = 'Invalid data found in excel. Name, Mobile, City and State are required.';
                } else if (isNaN(Number(item.mobile))) {
                    invalid_data = true;
                    invalid_message = 'Invalid data found in excel. Mobile must be a number and must be in second column. Sequance is Name, Mobile, City and State in first row.';
                }
            });

            if (invalid_data) {
                res.status(422).json({
                    error: '4',
                    message: invalid_message,
                    data: resData.data
                });
                return;
            }


            // check if excel is empty
            if (!resData.data.length) {
                res.status(422).json({
                    error: '2',
                    message: "No data found in excel.",
                    data: resData.data
                });
                return;
            }

            // check for duplicate mobile numbers
            let byMobile = _.map(resData.data, 'mobile');
            let duplicates = checkDupicates(byMobile);
            if (duplicates.length) {
                res.status(422).json({
                    error: '1',
                    message: "duplicate mobile numbers found in excel.",
                    duplicates
                });
                return;
            }
            let defected = [];

            // mobile lengt validation and others
            resData.data.map((item, i) => {
                if (item && item.mobile && String(item.mobile).length < 10) {
                    defected.push(item);
                }
            })
            if (defected.length) {
                res.status(422).json({
                    error: '3',
                    message: "mobile number validation failed. No technicians inserted.",
                    defected
                });
                return;
            }

            let existMobiles = await TechnicianService.findQuery({
                where: {
                    mobile: {
                        [Op.in]: byMobile
                    }
                }
            }, { fields: ['mobile'] });
            if (existMobiles.length) {
                res.status(422).json({
                    error: '2',
                    message: "Existed data found in excel."
                });

            } else {
                for (let item of resData.data) {

                    item.city = toTitleCase(item.city);
                    item.state = toTitleCase(item.state);
                    let tech = {
                        address: {
                            city: item.city,
                            state: item.state
                        },
                        service: {
                            service_id: 1, // plumber
                            preferred_location: item.city,
                        },
                        mobile: item.mobile,
                        first_name: item.name.split(" ")[0] || item.name,
                        last_name: item.name.split(" ")[1] || '',
                        distributor_city: item.city,
                        distributor_state: item.state
                    }
                    if (item.city) {
                        let geoCodeRes = await getCoordsFromAddress(`${item.city}`);
                        // console.log({ geoCodeRes: JSON.stringify(geoCodeRes.json.results[0].geometry.location) });
                        if (geoCodeRes && geoCodeRes.status == 200) {

                            let { geometry } = geoCodeRes.json.results[0];
                            if (geometry && geometry.location) {
                                let loc = geoCodeRes.json.results[0].geometry.location;
                                tech.address.latitude = String(loc.lat);
                                // data.address.address2 = data.address.address2 + 'from geo code';
                                tech.address.longitude = String(loc.lng);
                                tech.address.location = { type: 'Point', coordinates: [String(loc.lng), String(loc.lat)] };
                            }

                        }
                    }


                    let insert = await insertTechnician(tech);
                    // tech.insert = insert;

                    list.push(tech);

                }
                res.status(200).json({
                    error: '0',
                    message: 'Technician data.',
                    data: list
                })
            }
        } catch (err) {
            console.log({ err });
            res.status(500).json({
                error: '1',
                message: "Internal server error"
            });

        }
    });

}

const filterByTimes = async (req, res) => {
    let { limit, offset } = req.query;
    let query = {};
    let data = req.body;
    let given = data;

    query.limit = parseInt(limit) || 10;
    query.offset = parseInt(offset) || 0;

    query.where = {
        start_time: {
            [Op.and]: {
                [Op.lt]: moment(given.end_time, "HH:mm:ss").format("HH:mm:ss"),
                // [Op.lte]: moment(given.start_time, "HH:mm:ss").format("HH:mm:ss")
            }
        },
        end_time: {
            [Op.and]: {
                // [Op.gte]: moment(given.end_time, "HH:mm:ss").format("HH:mm:ss"),
                [Op.gte]: moment(given.start_time, "HH:mm:ss").format("HH:mm:ss")
            }
        }
    };

    try {
        // let list = await Tech_Service_Service.findQuery(query);
        let count = await Tech_Service_Service.findQuery({ where: query.where });
        count = count.length;
        let list = await TechnicianService.findByTime(query);
        let temp = removeServiceArray(list);
        res.status(200).json({
            error: '0',
            message: 'Technician data.',
            count,
            data: temp,
            limit: query.limit,
            offset: query.offset
        });
    } catch (err) {
        console.log({ err });
        res.status(500).json({
            error: '1',
            message: "Internal sever error"
        });
    }

}

const insertTechnician = async (item) => {
    let data = item;
    let userData;
    let requestFrom = 'web';
    let nextID = await TechnicianService.count();
    data.technician_id = idGenerator('TECH', nextID);
    data.signup_from = requestFrom.toLowerCase();
    data.first_name = toTitleCase(data.first_name);
    data.last_name = toTitleCase(data.last_name);

    let { latitude, longitude } = data.address;

    if (latitude && longitude) {
        data.address.location = { type: 'Point', coordinates: [longitude, latitude] };
    }

    let address_res = await AddressService.create(data.address);
    data.address_id = address_res.id;

    let response_temp = await TechnicianService.create(data);

    // await TechnicianService.update({ where: { technician_id: response_temp.technician_id } }, { address_id: address_res.id })

    let final = await Tech_Service_Service.create({
        technician_id: response_temp.id,
        service_id: data.service.service_id,
        preferred_location: data.service.preferred_location,
        start_time: data.service.start_time || START_TIME,
        end_time: data.service.end_time || END_TIME
    })

    return final;

}

const uploadProfileImage = (req, res) => {

    let profile_pic = req.file.location;
    let { file } = req;
    TechnicianService.findOne({
        where: { id: req.params.technician_id, status: true }
    })
        .then(response => {
            if (response) {

                if (file && file.fieldname && file.fieldname != 'avatar')
                    response[file.fieldname] = profile_pic;
                else
                    response.profile_pic = profile_pic;
                return response.save();
            } else {
                let delObj = deleteS3Object(profile_pic);
                return res.status(400).json({
                    error: '2',
                    message: "Technician data not found"
                });
            }
        })
        .then(response => {
            // response.profile_pic = getPreSignedURL(response.profile_pic);
            let result = {};
            if (file && file.fieldname && file.fieldname != 'avatar')
                result[file.fieldname] = response[file.fieldname];
            else
                result.profile_pic = response.profile_pic;
            res.status(200).json({
                error: "0",
                message: "Profile image uploaded successfully",
                data: result
            });
        })
        .catch(error => {
            res.status(500).json({
                error: '1',
                message: "Internal server error"
            });
        })

}

const verifiedListByYear = async (req, res) => {
    let query = {};

    let { limit, offset } = req.query;
    query.limit = parseInt(limit) || undefined;
    query.offset = parseInt(offset) || undefined;

    let startOf_year = moment().startOf('year').format("YYYY-MM-DD HH:mm:ss");
    let endOf_year = moment().endOf('year').format("YYYY-MM-DD HH:mm:ss");

    query.where = {
        verified_on: {
            [Op.between]: [startOf_year, endOf_year]
        }
    }

    let count = await TechnicianService.count({ where: query.where });
    TechnicianService.findQuery(query)
        .then(customers => {
            if (customers) {
                res.status(200).json({
                    error: '0',
                    message: "Technicians data",
                    data: customers,
                    count,
                    startOf_year,
                    endOf_year
                });
            } else {
                res.status(400).json({
                    error: '1',
                    message: "No Technicians exists in the database",
                    startOf_year,
                    endOf_year
                });
            }
        })
        .catch(error => {
            console.log(error)
            res.status(500).json({
                error: '2',
                message: "Internal sever error"
            });
        });
}

// util functions here 

const removeServiceArray = (response, isAdmin) => {
    // chekc for admin access

    let temp = response.map((item) => {
        item = JSON.parse(JSON.stringify(item));
        // let ttm = item.is_verified.split('-');
        // if (ttm.length > 1) {
        //     item.is_verified = `${toTitleCase(ttm[0])} ${toTitleCase(ttm[1])}`;
        // } else {
        //     item.is_verified = toTitleCase(item.is_verified);
        // }

        if (item.aadhar_back && (item.aadhar_back == undefined || item.aadhar_back == 'undefined')) {
            item.aadhar_back = '';
        }

        if (item.aadhar_front && (item.aadhar_front == undefined || item.aadhar_front == 'undefined')) {
            item.aadhar_front = '';
        }

        if (item.is_verified == '') {
            item.is_verified = 'not-verified';
        }

        if (item.is_verified != 'verified') {
            delete item.profile_pic;
        }

        item.name = `${item.first_name} ${item.last_name}`.trim();

        if (item.aadhar)
            delete item.aadhar;

        if (!isAdmin) {
            delete item.pan;
            delete item.aadhar_front;
            delete item.aadhar_back;
            if (item.is_verified && item.is_verified == 'pending')
                item.is_verified = 'not-verified';
        }
        if (item.services && item.services.length) {

            item.services = item.services[0];
        } else {
            item.services = {
                "id": 0,
                "name": null,
                "technician_services": {
                    "technician_id": null,
                    "service_id": 0,
                    "preferred_location": null,
                    "start_time": null,
                    "end_time": null,
                    "status": false,
                    "created_by": null,
                    "updated_by": null,
                    "created_at": null,
                    "updated_at": null
                }
            };
        }
        return item;
    });

    return temp;
}

const checkDupicates = (arr) => {
    var sorted_arr = arr.slice().sort(); // You can define the comparing function here. 
    // JS by default uses a crappy string compare.
    // (we use slice to clone the array so the
    // original array won't be modified)
    var results = [];
    for (var i = 0; i < sorted_arr.length - 1; i++) {
        if (sorted_arr[i + 1] == sorted_arr[i]) {
            results.push(sorted_arr[i]);
        }
    }

    return results
}

export default {
    getTechnicianById,
    getTechnicians,
    get_list_by_location,
    register,
    updateTechnician,
    deleteTechnician,
    updateAddress,
    uploadExcel,
    uploadProfileImage,
    filterByTimes,
    verifiedListByYear
}