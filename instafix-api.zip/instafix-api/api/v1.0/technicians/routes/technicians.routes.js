'use strict';

import express from 'express';
import TechnicianController from '../controllers/technicians.controller';
import TechnicianService from '../services/technicians.services';
import {
    idGenerator,
} from "../../../../common/utils";

import {
    isCustomer,
    requires
} from '../../auth/auth.service';

// import config from "../../../../config/config";
// import AWS from "aws-sdk";

// AWS.config.loadFromPath('./config/s3_credentials.json');

// const BucketName = config.default.awsS3.bucketName;
var multer = require('multer');
var path = require('path');
import * as fs from 'fs';
// const upload = multer({ dest: './uploads/' })
// const multerS3 = require('multer-s3')

// var s3 = new AWS.S3()

var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        if (req.params.mobile) { // mobile is now technician_id key in technician data
            let dir = './uploads/technicians/' + req.params.mobile + "/";
            if (!fs.existsSync(dir)) {
                fs.mkdirSync(dir);
            }
            cb(null, dir)
        } else {
            TechnicianService.count().then(res => {
                let nextID = res;
                req.body.technician_id = idGenerator('TECH', nextID);
                let dir = './uploads/technicians/' + req.body.technician_id + "/"
                if (!fs.existsSync(dir)) {
                    fs.mkdirSync(dir);
                }

                cb(null, dir)
            })
        }
    },
    filename: function (req, file, cb) {
        cb(null, file.fieldname + "_" + Date.now() + "_" + file.originalname);
    }
});


const upload = multer({
    storage: storage,
    fileFilter: function (req, file, callback) {
        var ext = path.extname(file.originalname);
        if (ext !== '.png' && ext !== '.jpg' && ext !== '.gif' && ext !== '.jpeg') {
            return callback(new Error('Only images are allowed'))
        }
        callback(null, true)
    }
});

// const upload = multer({
//     storage: multerS3({
//         s3: s3,
//         bucket: BucketName,
//         acl: 'public-read',
//         serverSideEncryption: 'AES256',
//         contentType: multerS3.AUTO_CONTENT_TYPE,
//         metadata: function(req, file, cb) {
//             cb(null, { fieldName: file.fieldname });
//         },
//         key: function(req, file, cb) {
//             cb(null, 'technicians/' + req.params.mobile + '/' + file.fieldname + "_" + Date.now().toString());
//         }
//     })
// })

// const storage = multer.diskStorage({
//     destination: function(req, file, cb) {
//         cb(null, './public/aadhar/')
//     },
//     filename: function(req, file, cb) {
//         cb(null, Date.now() + "_" + file.originalname);
//     }
// });

// const upload_aadhar = multer({
//     storage: storage
// }).any()

// const aadhar = (req, res, cb) => {

//     upload_aadhar(req, res, (err) => {
//         if (err) {
//             console.log(err);
//         } else {
//             upload.single(req.files[0].fieldname)

//         }
//     })
// }

let router = express.Router();

/**
 * @api {post} /technicians/register/:mobile Add Technician
 * @apiName Add Technician
 * @apiGroup Technicians
 *
 * @apiPermission Admin Technician
 * 
 * @apiHeader {String} x-request-from value: web/mobile , profile : file, aadhar_front: file, aadhar_back: file
 *
 * @apiParamExample {json} Request-Example:
 *  { // note: send data in form-data format // keys for file uploads profile pic - profile, aadhar front - aadhar_front, aadhar back - aadhar_back
	"first_name": "Hans",
	"last_name": "Jimmar",
	"mobile": 1234567043,
	"password": "password",
	"service": {
		"service_id": 1,
		"preferred_location": "ameerpet",
		"start_time": "1:00",
		"end_time": "13:00"
	},
	"address": {
		"address1": "hidden hills",
		"city": "LA",
		"state": "state",
		"pin": 495227,
		"country": "india",
		"latitude": "17.438907",
		"longitude": "78.364215"
	}
 * }
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 201 OK
 *     {
 *       "error": "0",
 *       "message": "Technician Register is Successful"
 *    }
 *
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 400 Bad Request
 *     {
 *       "error": "1",
 *       "message": "Technician Registration Failed."
 *     }
 * 
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 400 Bad Request
 *     {
 *       "error": "2",
 *       "message": "Some Fields are missing."
 *     }
 * 
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 400 Bad Request
 *     {
 *       "error": "3",
 *       "message": "Technician Already Exists with same details"
 *     }
 * 
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Bad Request
 *     {
 *       "error": "4",
 *       "message": "Internal Sever Error"
 *     }
 * 
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 400 Bad Request
 *     {
 *       "error": "2",
 *       "message": "Please enter a valid email or mobile number"
 *     }
 *
 */
const cpUpload = upload.fields([{ name: 'profile', maxCount: 1 }, { name: 'aadhar_front', maxCount: 1 }, { name: 'aadhar_back', maxCount: 1 }])
router.post('/v1.0/technicians/register', isCustomer.hasAdminRole, cpUpload, TechnicianController.register);
// router.post('/v1.0/technicians/register', isCustomer.hasAdminRole, requires.body, TechnicianController.register);

/**
 * @api {get} /technicians?limit=10&offset=0 Get Technicians
 * @apiName Get Technicians
 * @apiGroup Technicians
 *
 * @apiPermission Admin Technician
 * 
 *
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 201 OK
 *{
    "error": "0",
    "message": "Technicians data",
    "data": [
        {
            "id": 8,
            "first_name": "Martin",
            "last_name": "Km",
            "email": null,
            "gender": null,
            "mobile": 1234567049,
            "technician_id": "TECH100005",
            "address_id": 7,
            "pan": null,
            "aadhar": null,
            "profile_pic": null,
            "status": true,
            "services": {
                "id": 1,
                "name": "Plumber",
                "technician_services": {
                    "technician_id": 8,
                    "service_id": 1,
                    "preferred_location": "Chennai",
                    "start_time": "01:00:00",
                    "end_time": "13:00:00"
                }
            },
            "address": {
                "id": 7,
                "address1": "T nagar",
                "address2": null,
                "city": "Chennai",
                "state": "Tamil Nadu",
                "country": "india",
                "pin": 495227,
                "latitude": "12.902424563866342",
                "longitude": "80.20500580068112",
                "location": {
                    "type": "Point",
                    "coordinates": [
                        12.902424563866342,
                        80.20500580068112
                    ]
                }
            }
        },
        {
            "id": 9,
            "first_name": "Cristina",
            "last_name": "Mate",
            "email": null,
            "gender": null,
            "mobile": 1234567042,
            "technician_id": "TECH100006",
            "address_id": 8,
            "pan": null,
            "aadhar": null,
            "profile_pic": null,
            "status": true,
            "services": {
                "id": 1,
                "name": "Plumber",
                "technician_services": {
                    "technician_id": 9,
                    "service_id": 1,
                    "preferred_location": "Chennai",
                    "start_time": "01:00:00",
                    "end_time": "13:00:00"
                }
            },
            "address": {
                "id": 8,
                "address1": "T nagar",
                "address2": null,
                "city": "Chennai",
                "state": "Tamil Nadu",
                "country": "india",
                "pin": 495227,
                "latitude": "12.902424563866342",
                "longitude": "80.20500580068112",
                "location": {
                    "type": "Point",
                    "coordinates": [
                        12.902424563866342,
                        80.20500580068112
                    ]
                }
            }
        },
        {
            "id": 11,
            "first_name": "Julia",
            "last_name": "Home",
            "email": null,
            "gender": null,
            "mobile": 1234567040,
            "technician_id": "TECH100007",
            "address_id": 9,
            "pan": null,
            "aadhar": null,
            "profile_pic": null,
            "status": true,
            "services": {
                "id": 1,
                "name": "Plumber",
                "technician_services": {
                    "technician_id": 11,
                    "service_id": 1,
                    "preferred_location": "Chennai",
                    "start_time": "01:00:00",
                    "end_time": "13:00:00"
                }
            },
            "address": {
                "id": 9,
                "address1": "T nagar",
                "address2": null,
                "city": "Chennai",
                "state": "Tamil Nadu",
                "country": "india",
                "pin": 495227,
                "latitude": "12.902424563866342",
                "longitude": "80.20500580068112",
                "location": {
                    "type": "Point",
                    "coordinates": [
                        12.902424563866342,
                        80.20500580068112
                    ]
                }
            }
        }
    ]
 * }
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 400 Bad Request
 *     {
 *       "error": "1",
 *       "message": "No technicians exists in the database."
 *     }
 * 
 * 
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Bad Request
 *     {
 *       "error": "1",
 *       "message": "Internal Sever Error"
 *     }
 * 
 *
 */

router.get('/v1.0/technicians', isCustomer.hasAdminRole, TechnicianController.getTechnicians);


/**
 * @api {post} /technicians/update/:technician_id (like TECH102596) Update a Technician
 * @apiName Update Technicians
 * @apiGroup Technicians
 *
 * @apiPermission Admin Technician
 * 
 * 
 * @apiHeader {String} x-access-code value: User Token 
 * 
 * @apiParamExample {json} Request-Example:
 *  { // note: send data in form-data format // keys for file uploads profile pic - profile, aadhar front - aadhar_front, aadhar back - aadhar_back
	"id": 5,
	"last_name": "something",
	"email": "email@email.com",
	"address" : {
		"city": "toronto",
		"country": "canada"
	},
	"service": {
		"service_id": 1,
		"preferred_location": "kadapa"
	}
 * }
 *
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
    "error": "0",
    "message": "Technician updated successfully.",
    "data": {
        "id": 5,
        "last_name": "something",
        "email": "email@email.com",
        "address": {
            "city": "toronto",
            "country": "canada"
        },
        "service": {
            "service_id": 1,
            "preferred_location": "kadapa"
        }
    }
 * }
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 400 Bad Request
 *     {
 *       "error": "1",
 *       "message": "Technician not found."
 *     }
 * 
 * 
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Bad Request
 *     {
 *       "error": "2",
 *       "message": "Internal Sever Error"
 *     }
 * 
 *
 */


router.post('/v1.0/technicians/update/:mobile', isCustomer.hasAdminRole, cpUpload, TechnicianController.updateTechnician);


/**
 * @api {post} /technicians/delete Delete a Technician
 * @apiName Delete Technicians
 * @apiGroup Technicians
 *
 * @apiPermission Admin Technician
 * 
 * 
 * @apiHeader {String} x-access-code value: User Token profile : file, aadhar_front: file, aadhar_back: file
 * 
 * @apiParamExample {json} Request-Example:
 *  {
 *   "id": 1, // required must be technician id
    }
 *
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "error": "0",
 *       "message": "Technician deleted successfully."
 *    }
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 400 Bad Request
 *     {
 *       "error": "1",
 *       "message": "Technician not found."
 *     }
 * 
 * 
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Bad Request
 *     {
 *       "error": "2",
 *       "message": "Internal Sever Error"
 *     }
 * 
 *
 */

router.post('/v1.0/technicians/delete', isCustomer.hasAdminRole, requires.body, TechnicianController.deleteTechnician);
/**
 * @api {post} /technicians/get_list_by_location?limit=10&offset=0 Get Technicians list by location
 * @apiName Get Technicians by location
 * @apiGroup Technicians
 *
 * @apiPermission Admin Technician
 * 
 ** 
 * @apiParamExample {json} Request-Example:
 *  {
	"center": {
		"lat": "17.442633",
		"lng": "78.382679"
	},
    "radius": 600 // in meters from center
    "locality": "chennai" // if locality is passed then center and radius are ignored // remove locality if you want to filter by center and radius
 * }
 *
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *{
    "error": "0",
    "message": "Technicians data",
    "data": [
        {
            "id": 8,
            "first_name": "Martin",
            "last_name": "Km",
            "email": null,
            "gender": null,
            "mobile": 1234567049,
            "technician_id": "TECH100005",
            "address_id": 7,
            "pan": null,
            "aadhar": null,
            "profile_pic": null,
            "status": true,
            "services": {
                "id": 1,
                "name": "Plumber",
                "technician_services": {
                    "technician_id": 8,
                    "service_id": 1,
                    "preferred_location": "Chennai",
                    "start_time": "01:00:00",
                    "end_time": "13:00:00"
                }
            },
            "address": {
                "id": 7,
                "address1": "T nagar",
                "address2": null,
                "city": "Chennai",
                "state": "Tamil Nadu",
                "country": "india",
                "pin": 495227,
                "latitude": "12.902424563866342",
                "longitude": "80.20500580068112",
                "location": {
                    "type": "Point",
                    "coordinates": [
                        12.902424563866342,
                        80.20500580068112
                    ]
                }
            }
        },
        {
            "id": 9,
            "first_name": "Cristina",
            "last_name": "Mate",
            "email": null,
            "gender": null,
            "mobile": 1234567042,
            "technician_id": "TECH100006",
            "address_id": 8,
            "pan": null,
            "aadhar": null,
            "profile_pic": null,
            "status": true,
            "services": {
                "id": 1,
                "name": "Plumber",
                "technician_services": {
                    "technician_id": 9,
                    "service_id": 1,
                    "preferred_location": "Chennai",
                    "start_time": "01:00:00",
                    "end_time": "13:00:00"
                }
            },
            "address": {
                "id": 8,
                "address1": "T nagar",
                "address2": null,
                "city": "Chennai",
                "state": "Tamil Nadu",
                "country": "india",
                "pin": 495227,
                "latitude": "12.902424563866342",
                "longitude": "80.20500580068112",
                "location": {
                    "type": "Point",
                    "coordinates": [
                        12.902424563866342,
                        80.20500580068112
                    ]
                }
            }
        },
        {
            "id": 11,
            "first_name": "Julia",
            "last_name": "Home",
            "email": null,
            "gender": null,
            "mobile": 1234567040,
            "technician_id": "TECH100007",
            "address_id": 9,
            "pan": null,
            "aadhar": null,
            "profile_pic": null,
            "status": true,
            "services": {
                "id": 1,
                "name": "Plumber",
                "technician_services": {
                    "technician_id": 11,
                    "service_id": 1,
                    "preferred_location": "Chennai",
                    "start_time": "01:00:00",
                    "end_time": "13:00:00"
                }
            },
            "address": {
                "id": 9,
                "address1": "T nagar",
                "address2": null,
                "city": "Chennai",
                "state": "Tamil Nadu",
                "country": "india",
                "pin": 495227,
                "latitude": "12.902424563866342",
                "longitude": "80.20500580068112",
                "location": {
                    "type": "Point",
                    "coordinates": [
                        12.902424563866342,
                        80.20500580068112
                    ]
                }
            }
        }
    ]
 * }
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 400 Bad Request
 *     {
 *       "error": "1",
 *       "message": "Technician not found."
 *     }
 * 
 * 
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Bad Request
 *     {
 *       "error": "2",
 *       "message": "Internal Sever Error"
 *     }
 * 
 *
 */

router.post('/v1.0/technicians/get_list_by_location', requires.body, TechnicianController.get_list_by_location);



/**
 * @api {get} /technicians/:id Get a technician by Id
 * @apiName Get a technician by id
 * @apiGroup Technicians
 *
 * @apiPermission Admin Technician
 * 
 * 
 * @apiHeader {String} x-access-code value: User Token 
 * 
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
    "error": "0",
    "message": "Technician data.",
    "data": {
        "id": 5,
        "first_name": "Ramesh",
        "last_name": "something",
        "email": null,
        "gender": null,
        "mobile": 1234567023,
        "technician_id": "TECH100003",
        "address_id": 5,
        "pan": null,
        "aadhar": null,
        "profile_pic": null,
        "status": true,
        "address": {
            "id": 5,
            "address1": "tcs mind space office",
            "address2": null,
            "city": "city",
            "state": "state",
            "country": "india",
            "pin": 495227,
            "latitude": "17.444367",
            "longitude": "78.377645",
            "location": {
                "type": "Point",
                "coordinates": [
                    17.444367,
                    78.377645
                ]
            }
        },
        "services": {
            "id": 1,
            "name": "Plumber",
            "technician_services": {
                "technician_id": 5,
                "service_id": 1,
                "preferred_location": "ameerpet",
                "start_time": null,
                "end_time": null
            }
        }
    }
 * }
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 400 Bad Request
 *     {
 *       "error": "1",
 *       "message": "Technician not found."
 *     }
 * 
 * 
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Bad Request
 *     {
 *       "error": "2",
 *       "message": "Internal Sever Error"
 *     }
 * 
 *
 */

router.get('/v1.0/technicians/:id', TechnicianController.getTechnicianById);

/**
 * @api {post} /technicians/upload Upload technicians from excel
 * @apiName Upload Technicians from excel
 * @apiGroup Technicians
 *
 * @apiPermission Admin Technician
 * 
 * 
 * @apiHeader {String} x-access-code value: User Token 
 * 
 * @apiParamExample {json} Request-Example:
 *  Upload excel with sheet name data // follow sample excel for ref.
 *
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
                error: '0',
                message: 'Technician data.',
                data: [{}, {}]
 *          }
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 400 Bad Request
 *     {
                error: '1',
                message: "duplicate mobile numbers found in excel.",
                duplicates: [8923982398, 9844439839]
 *          }
 * 
 * 
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Bad Request
 *     {
                error: '2',
                message: "Existed data found in excel."
 *          }
 * 
 *
 */
router.post('/v1.0/technicians/upload', isCustomer.hasAdminRole, TechnicianController.uploadExcel);

/**
 * @api {post} /technicians/get_list_by_times?limit3&offset=0 Get Technicians list by Preferred timings
 * @apiName Get Technicians by Preferred timings
 * @apiGroup Technicians
 * 
 *
 * @apiParamExample {json} Request-Example:
 *  {
	"start_time": "1:00:00", // 24 hour format
	"end_time": "23:59:59" // 24 hour format
 * }
 *
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *{
    "error": "0",
    "message": "Technicians data",
    "data": [
        {
            "id": 8,
            "first_name": "Martin",
            "last_name": "Km",
            "email": null,
            "gender": null,
            "mobile": 1234567049,
            "technician_id": "TECH100005",
            "address_id": 7,
            "pan": null,
            "aadhar": null,
            "profile_pic": null,
            "status": true,
            "services": {
                "id": 1,
                "name": "Plumber",
                "technician_services": {
                    "technician_id": 8,
                    "service_id": 1,
                    "preferred_location": "Chennai",
                    "start_time": "01:00:00",
                    "end_time": "13:00:00"
                }
            },
            "address": {
                "id": 7,
                "address1": "T nagar",
                "address2": null,
                "city": "Chennai",
                "state": "Tamil Nadu",
                "country": "india",
                "pin": 495227,
                "latitude": "12.902424563866342",
                "longitude": "80.20500580068112",
                "location": {
                    "type": "Point",
                    "coordinates": [
                        12.902424563866342,
                        80.20500580068112
                    ]
                }
            }
        },
        {
            "id": 9,
            "first_name": "Cristina",
            "last_name": "Mate",
            "email": null,
            "gender": null,
            "mobile": 1234567042,
            "technician_id": "TECH100006",
            "address_id": 8,
            "pan": null,
            "aadhar": null,
            "profile_pic": null,
            "status": true,
            "services": {
                "id": 1,
                "name": "Plumber",
                "technician_services": {
                    "technician_id": 9,
                    "service_id": 1,
                    "preferred_location": "Chennai",
                    "start_time": "01:00:00",
                    "end_time": "13:00:00"
                }
            },
            "address": {
                "id": 8,
                "address1": "T nagar",
                "address2": null,
                "city": "Chennai",
                "state": "Tamil Nadu",
                "country": "india",
                "pin": 495227,
                "latitude": "12.902424563866342",
                "longitude": "80.20500580068112",
                "location": {
                    "type": "Point",
                    "coordinates": [
                        12.902424563866342,
                        80.20500580068112
                    ]
                }
            }
        },
        {
            "id": 11,
            "first_name": "Julia",
            "last_name": "Home",
            "email": null,
            "gender": null,
            "mobile": 1234567040,
            "technician_id": "TECH100007",
            "address_id": 9,
            "pan": null,
            "aadhar": null,
            "profile_pic": null,
            "status": true,
            "services": {
                "id": 1,
                "name": "Plumber",
                "technician_services": {
                    "technician_id": 11,
                    "service_id": 1,
                    "preferred_location": "Chennai",
                    "start_time": "01:00:00",
                    "end_time": "13:00:00"
                }
            },
            "address": {
                "id": 9,
                "address1": "T nagar",
                "address2": null,
                "city": "Chennai",
                "state": "Tamil Nadu",
                "country": "india",
                "pin": 495227,
                "latitude": "12.902424563866342",
                "longitude": "80.20500580068112",
                "location": {
                    "type": "Point",
                    "coordinates": [
                        12.902424563866342,
                        80.20500580068112
                    ]
                }
            }
        }
    ],
    count: 20,
    limit: 3,
    offset: 0
 * }
 *
 * 
 * 
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Bad Request
 *     {
 *       "error": "1",
 *       "message": "Internal Sever Error"
 *     }
 * 
 *
 */
router.post('/v1.0/technicians/get_list_by_times', requires.body, TechnicianController.filterByTimes);

export default router;