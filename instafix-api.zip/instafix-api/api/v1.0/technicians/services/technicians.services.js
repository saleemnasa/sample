'use strict';
const Sequelize = require('sequelize');
const Technician = require('../../models').technicians;
const Address = require('../../models').addresses;
const Services = require('../../models').services;
const TechnicianServices = require('../../models').technician_services;
import md5 from 'md5';
const Op = Sequelize.Op;
const attributes_to_hide = ['user_type', 'signup_from', 'password', 'updated_at', 'otp', 'block', 'updated_by', 'created_by', 'userType', 'is_mobile_verified', 'is_email_verified', 'mobile_verified_on', 'email_verified_on'];

const findQuery = (query) => {
    console.log(query.throuth_where)
    return Technician.findAll({
        attributes: { exclude: attributes_to_hide },
        where: query.where,
        include: [{
            model: Address,
            attributes: { exclude: ['created_at', 'updated_at', 'updated_by', 'created_by', 'status'] },
            as: 'address'
        }, {
            model: Services,
            through: {
                required: false,
                where: query.throuth_where || {},
                attributes: { exclude: ['created_at', 'updated_at', 'updated_by', 'created_by', 'status'] },
            },
            attributes: { exclude: ['created_at', 'updated_at', 'updated_by', 'created_by', 'status'] },
            as: 'services'
        }],
        offset: query.offset,
        limit: query.limit,
        order: query.order
    });
}

const findByLocation = (query) => {
    console.log(query);
    var attributes = Object.keys(Address.attributes);
    let location = Sequelize.literal(`ST_GeomFromText('POINT(${query.where.center.lng} ${query.where.center.lat})')`);
    var distance = Sequelize.fn('ST_Distance_Sphere', Sequelize.literal('location'), location);
    // var distance = Sequelize.literal("6371 * acos(cos(radians(" + query.where.center.lat + ")) * cos(radians(latitude)) * cos(radians(" + query.where.center.lng + ") - radians(longitude)) + sin(radians(" + query.where.center.lat + ")) * sin(radians(latitude)))")
    attributes.push([distance, 'distance']);
    // console.log({ here: Sequelize.where(distance, { $lte: query.where.radius }) })
    let address_where = {};
    if (query.where.start_time && query.where.end_time) {
        address_where = {
            distance: { $lte: query.where.radius },
            start_time: {
                [Op.and]: {
                    [Op.lt]: moment(query.where.end_time, "HH:mm:ss").format("HH:mm:ss"),
                    // [Op.lte]: moment(given.start_time, "HH:mm:ss").format("HH:mm:ss")
                }
            },
            end_time: {
                [Op.and]: {
                    // [Op.gte]: moment(given.end_time, "HH:mm:ss").format("HH:mm:ss"),
                    [Op.gte]: moment(query.where.start_time, "HH:mm:ss").format("HH:mm:ss")
                }
            }
        }
    } else {
        address_where = {
            distance: { $lte: query.where.radius }
        }
    }
    return Technician.findAll({
        where: query.new_where,
        attributes: { exclude: attributes_to_hide },
        include: [{
            model: Address,
            required: true,
            attributes: { include: attributes, exclude: ['created_at', 'updated_at', 'updated_by', 'created_by', 'status'] },
            // [Sequelize.literal('distance ASC')],
            where: Sequelize.where(distance, { $lte: Number(query.where.radius) }), // address_where,
            as: "address",
            order: [
                ['distance', 'ASC']
            ],
        }, {
            model: Services,
            attributes: { exclude: ['created_at', 'updated_at', 'updated_by', 'created_by', 'status'] },
            as: 'services'
        }],
        limit: query.limit,
        offset: query.offset,
        subQuery: false
    });
}

const findByLocality = (query) => {
    return Technician.findAll({
        where: { status: true },
        attributes: { exclude: attributes_to_hide },
        include: [{
            model: Services,
            required: true,
            attributes: { exclude: ['created_at', 'updated_at', 'updated_by', 'created_by', 'status'] },
            through: {
                attributes: { exclude: ['created_at', 'updated_at', 'updated_by', 'created_by', 'status'] },
                where: {
                    preferred_location: {
                        $like: '%' + query.where.locality + '%'
                    }
                },
            },
            as: 'services'
        }, {
            model: Address,
            attributes: { exclude: ['created_at', 'updated_at', 'updated_by', 'created_by', 'status'] },
            as: 'address'
        }],
        limit: query.limit,
        offset: query.offset,
    })
}

// const findQuery = (query) => {
//     let attr = ['first_name', 'last_name', 'email', 'gender', 'is_verified', 'profile_pic', 'created_at']
//     return Service.findAll({
//         where: query,
//         include: [{
//             model: Technician,
//             as: 'technicians'
//         }]
//     });
// }
const findByTime = (query) => {
    return Technician.findAll({
        where: {
            status: true, is_verified: {
                [Op.not]: 'rejected'
            }
        },
        attributes: { exclude: attributes_to_hide },
        include: [{
            model: Services,
            required: true,
            attributes: { exclude: ['created_at', 'updated_at', 'updated_by', 'created_by', 'status'] },
            through: {
                attributes: { exclude: ['created_at', 'updated_at', 'updated_by', 'created_by', 'status'] },
                where: query.where,
            },
            as: 'services'
        }, {
            model: Address,
            attributes: { exclude: ['created_at', 'updated_at', 'updated_by', 'created_by', 'status'] },
            as: 'address'
        }],
        limit: query.limit,
        offset: query.offset,
    })
}

const count = (query) => {
    return Technician.count(query);
}

const create = (data) => {
    if (data.password) {
        data.password = md5(data.password);
    }
    return Technician.create(data);
    // console.log(Technician.create(data))
    // return new Technician(data);
}

const update = (query, data) => {
    data.updated_at = new Date();
    if (data.password)
        data.password = md5(data.password);

    return Technician.update(data, query);
}

const findOne = (query) => {
    return Technician.findOne({
        where: query.where,
        attributes: { exclude: attributes_to_hide },
        include: [{
            model: Address,
            attributes: { exclude: ['created_at', 'updated_at', 'updated_by', 'created_by', 'status'] },
            as: 'address'
        }, {
            model: Services,
            attributes: { exclude: ['created_at', 'updated_at', 'updated_by', 'created_by', 'status'] },
            through: {
                attributes: { exclude: ['created_at', 'updated_at', 'updated_by', 'created_by', 'status'] },
            },
            as: 'services'
        }]
    })

}

export default {
    create,
    findQuery,
    findByLocation,
    update,
    count,
    findByLocality,
    findOne,
    findByTime
};