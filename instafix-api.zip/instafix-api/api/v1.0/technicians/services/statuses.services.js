'use strict';
const Sequelize = require('sequelize');
const Statuses = require('../../models').statuses;
const Customer = require('../../models').customers;
const Technician = require('../../models').technicians;
const Op = Sequelize.Op;

const findOne = (query, selectable) => {
    return Statuses.findOne({
        where: query,
        attributes: selectable
    });
}

const findStatus = (query) => {
    return Statuses.findOne({
        where: query,
        include: [{
            model: Customer,
            where: {
                id: Sequelize.col('statuses.verified_by')
            },
            attributes: ['first_name', 'last_name', 'mobile', 'email'],
            as: 'customer'
        },{
            model: Technician,
            where: {
                id: Sequelize.col('statuses.technician_id')
            },
            attributes: ['first_name', 'last_name', 'name', 'mobile', 'email'],
            as: 'technicians'
        }]
    });
}

const find = (query) => {
    return Statuses.find(query);
}

const findAll = (query) => {
    return Statuses.findAll({
        where: query.where,
        include: [{
            model: Customer,
            where: {
                id: Sequelize.col('statuses.verified_by')
            },
            attributes: { exclude: ['password', 'created_at', 'updated_at', 'otp', 'block', 'updated_by', 'created_by', 'userType', 'is_verified', 'is_mobile_verified', 'is_email_verified', 'mobile_verified_on', 'email_verified_on'] },
            as: 'customer'
        },{
            model: Technician,
            where: {
                id: Sequelize.col('statuses.technician_id')
            },
            attributes: ['first_name', 'last_name', 'name', 'mobile', 'email'],
            as: 'technicians'
        }],
        offset: query.offset,
        limit: query.limit,
        order: [
            ['created_at', 'DESC']
        ]
    });
}

const create = (data) => {
    return Statuses.create(data);
}

const update = (data, query) => {
    return Statuses.update(data, query);
}

const updateMany = (query, data) => {
    return Statuses.updateMany(query, data);
}

const remove = (query) => {
    return Statuses.remove(query);
}

const count = (query) => {
    return Statuses.count(query);
}

export default {
    findOne,
    findStatus,
    create,
    find,
    findAll,
    update,
    updateMany,
    remove,
    count
};