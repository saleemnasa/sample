'use strict';

import crypto from 'crypto';

import CustomerService from '../services/customers.services';
import TokenService from '../../auth/token.service';

import {
    generateJwtToken,
    generateOTP,
    idGenerator,
    toTitleCase,
    getPreSignedURL,
    deleteS3Object
} from "../../../../common/utils";

// import {
//     forgotPasswordMail,
//     sendResetMail,
//     sendVerificationMail
// } from "../../../../common/mails";

import {
    sendResetOTP,
    sendRegistrationOTP
} from "../../../../common/messages";

// import config from "../../../../config/config";
import md5 from 'md5';
const Sequelize = require('sequelize');
const Op = Sequelize.Op;
const moment = require('moment');

// var multer = require('multer');
// var path = require('path')

// var storage = multer.diskStorage({
//     destination: function(req, file, cb) {
//         cb(null, './public/uploads/')
//     },
//     filename: function(req, file, cb) {
//         cb(null, file.fieldname + "_" + Date.now() + "_" + file.originalname);
//     }
// });

// const upload = multer({
//     storage: storage,
//     fileFilter: function(req, file, callback) {
//         var ext = path.extname(file.originalname);
//         if (ext !== '.png' && ext !== '.jpg' && ext !== '.gif' && ext !== '.jpeg') {
//             return callback(new Error('Only images are allowed'))
//         }
//         callback(null, true)
//     }
// }).single('file');

// const uploadImage = (req, res) => {
//     upload(req, res, function(err) {
//         if (err) {
//             console.log(err.message);
//             return res.status(400).json({
//                 error: "1",
//                 message: err.message || "Something went wrong"
//             });
//         }
//         let {
//             userID,
//             role
//         } = req.decoded;

//         if (role == 'admin') {
//             userID = req.query.id;
//         }

//         let prof_pic = "http://" + req.get('host') + "/" + req.file.path;

//         CustomerService.update({
//                 _id: objectId(userID)
//             }, { prof_pic })
//             .then(response => {
//                 console.log(response);
//                 return res.status(200).json({
//                     error: "0",
//                     message: "Profile updated",
//                     data: response
//                 });
//             })
//             .catch((err) => {
//                 console.log(err)
//                 res.status(500).json({
//                     error: '2',
//                     message: "Internal Sever Error"
//                 });
//             });

//     });


// }

const uploadProfileImage = (req, res) => {

    let profile_pic = req.file.location;
    CustomerService.findCustomer({
        id: req.params.id
    })
        .then(response => {
            if (response) {
                response.profile_pic = profile_pic;
                return response.save();
            } else {
                let delObj = deleteS3Object(profile_pic);
                return res.status(400).json({
                    error: '2',
                    message: "Customer data not found"
                });
            }
        })
        .then(response => {
            // response.profile_pic = getPreSignedURL(response.profile_pic);
            res.status(200).json({
                error: "0",
                message: "Profile image uploaded successfully",
                data: {
                    profile_pic: response.profile_pic
                }
            });
        })
        .catch(error => {
            res.status(500).json({
                error: '1',
                message: "Internal server error"
            });
        })

}

const deleteProfileImage = (req, res) => {
    let {
        id
    } = req.params;

    CustomerService.findCustomer({
        id: id
    })
        .then(response => {
            if (response) {
                let delObj = deleteS3Object(response.profile_pic);
                response.profile_pic = "";
                return response.save();
            } else {
                return res.status(400).json({
                    error: '2',
                    message: "Customer data not found"
                });
            }

        })
        .then(response => {
            if (response)
                res.status(400).json({
                    error: "0",
                    message: "Profile image deleted successfully",
                });
        })
        .catch(error => {
            res.status(500).json({
                error: '1',
                message: "Internal server error"
            });
        })
}

const register = (req, res) => {
    let data = req.body;
    let userData;
    let requestFrom = req.headers["x-request-from"];
    let query = { where: { mobile: data.mobile } }
    CustomerService.count(query)
        .then(response => {
            if (response === 1) {
                return res.status(400).json({
                    error: '3',
                    message: "Account already exist with mobile number: " + data.mobile,
                });
            }
            return CustomerService.lastInsertedID()
        })
        .then(response => {

            let nextID = response[0].id;
            data.customer_id = idGenerator('CUST', nextID)
            data.signup_from = requestFrom.toLowerCase();
            data.first_name = toTitleCase(data.first_name);
            data.last_name = toTitleCase(data.last_name);
            data.otp = generateOTP();
            data.created_by = data.customer_id;
            return CustomerService.create(data);
        })
        .then((response) => {

            if (response) {
                response.password = undefined;
                sendRegistrationOTP(response.otp, response.mobile);
                res.status(200).json({
                    error: "0",
                    message: "Customer register is successful",
                    data: {
                        "first_name": response.first_name,
                        "last_name": response.last_name,
                        "email": response.email,
                        "mobile": response.mobile,
                        "customer_id": response.customer_id,
                        "id": response.id,
                    }
                });
            }
        })
        .catch((error) => {
            if (error) {
                console.log(error)
                let message = '';
                if (error.errors[0].type == 'Validation error') {
                    if (error.errors[0].path == 'password')
                        message = "Password should be 6-16 characters length. Must have 1 capital and 1 numeric"
                    else if (error.errors[0].path == 'first_name')
                        message = "First name must be in alphabetical characters.";
                    else if (error.errors[0].path == 'last_name')
                        message = "Last name must be in alphabetical characters.";
                    else if (error.errors[0].path == 'mobile')
                        message = "Please enter valid mobile number. ";
                } else if (error.errors[0].type == 'unique violation' && error.errors[0].path == 'email')
                    message = "Email already exist";
                else
                    message = error.errors[0].message;

                res.status(400).json({
                    error: '1',
                    message: message
                });
            } else
                res.status(500).json({
                    error: '2',
                    message: "Internal server error"
                });
        });

}

const resetPassword = (req, res) => {
    let {
        mobile,
        oldPassword,
        newPassword
    } = req.body, query = {};

    if (mobile)
        query.mobile = mobile;

    if (oldPassword == newPassword) {
        return res.status(400).json({
            error: '1',
            message: "Old and new passwords shouldn't be same."
        });
    }

    CustomerService.findCustomer(query)
        .then((response) => {
            if (response) {
                oldPassword = md5(oldPassword);
                if (oldPassword != response.password) {
                    return res.status(400).json({
                        error: '2',
                        message: "Old password does not match"
                    });
                } else {
                    response.password = md5(newPassword);
                    response.save();
                    return CustomerService.findOneCustomer({
                        mobile
                    }, ['mobile', 'email', 'first_name', 'last_name']);
                }

            } else {
                throw {
                    reason: "NotFound"
                }
            }
        })
        .then((response) => {

            res.status(200).json({
                error: '0',
                message: "Your password reset successful"
            });
        })
        .catch((err) => {
            if (err.reason == 'NotFound')
                res.status(400).json({
                    error: '4',
                    message: "Details not found with the given mobile"
                });
            else
                res.status(500).json({
                    error: '3',
                    message: "Error: " + err.errors[0].message
                });
        });
}

const setPassword = (req, res) => {
    let {
        mobile,
        otp,
        password
    } = req.body, query = {};

    if (mobile)
        query.mobile = mobile;

    CustomerService.findCustomer(query)
        .then((response) => {
            if (response) {
                if (otp != response.otp) {
                    return res.status(400).json({
                        error: '1',
                        message: "OTP does not match"
                    });
                }
                password = md5(password);
                response.password = password;
                response.block = false;
                response.is_verified = true;
                response.is_mobile_verified = true;
                response.mobile_verified_on = Date.now();
                response.updated_by = response.customer_id;
                response.otp = null;
                response.verified = true;
                response.save();
                return CustomerService.findOneCustomer({
                    mobile
                }, ['mobile', 'email', 'first_name', 'last_name']);

            } else {
                throw {
                    reason: "NotFound"
                }
            }
        })
        .then((response) => {

            res.status(200).json({
                error: '0',
                message: "Your password reset successful"
            });
        })
        .catch((err) => {
            if (err.reason == 'NotFound')
                res.status(400).json({
                    error: '2',
                    message: "Details not found with the given mobile"
                });
            else
                res.status(500).json({
                    error: '3',
                    message: "Error: " + err.errors[0].message
                });
        });
}

const updateMobile = (req, res) => {
    let {
        mobile,
        otp,
        mobileNew
    } = req.body, query = {};

    if (mobile)
        query.mobile = mobile;

    CustomerService.findCustomer(query)
        .then((response) => {
            if (response) {
                if (otp != response.otp) {
                    return res.status(400).json({
                        error: '1',
                        message: "OTP does not match"
                    });
                }
                response.mobile = mobileNew;
                response.otp = null;
                response.save();
                return CustomerService.findOneCustomer({
                    mobile
                }, ['mobile', 'email', 'first_name', 'last_name']);

            } else {
                throw {
                    reason: "NotFound"
                }
            }
        })
        .then((response) => {

            res.status(200).json({
                error: '0',
                message: "Your mobile number updated successfully"
            });
        })
        .catch((err) => {
            if (err.reason == 'NotFound')
                res.status(400).json({
                    error: '2',
                    message: "Details not found with the given mobile"
                });
            else
                res.status(500).json({
                    error: '3',
                    message: "Error: " + err.errors[0].message
                });
        });
}

const adminLogin = (req, res) => {
    let requestFrom = req.headers["x-request-from"];
    let {
        email,
        password
    } = req.body;
    let block = false,
        is_verified = true;
    if (email)
        email = email.trim();
    if (password)
        password = password.trim();

    if (requestFrom != "web")
        res.status(400).json({
            error: '1',
            message: "Login from mobile is not allowed"
        });

    CustomerService.findCustomer({
        email,
        password,
        is_verified,
        block
    })
        .then(response => {
            if (response && (response.userType == 'admin' || response.userType == 'modifier')) {

                let data = getCustomerResponseData(response, requestFrom);
                res.status(200).json({
                    error: '0',
                    message: "Customer Exists",
                    data
                });
            } else {
                throw {
                    reason: "NotExists"
                }
            }
        })
        .catch(error => {
            if (error.reason == "NotExists")
                res.status(400).json({
                    error: '1',
                    message: "Invalid Credentials."
                });
            else
                res.status(500).json({
                    error: '1',
                    message: "Internal Sever Error"
                });
        });
}

const login = (req, res) => {
    let requestFrom = req.headers["x-request-from"];
    let {
        mobile,
        password
    } = req.body;
    // let block = false,
    //     is_verified = true;
    if (mobile)
        mobile = mobile;
    if (password)
        password = password.trim();

    CustomerService.findCustomer({
        mobile,
        password,
        // is_verified,
        // block
    })
        .then(response => {
            if (response && response.userType == 'customer') {
                if (!response.is_verified || response.block) {
                    return res.status(400).json({
                        error: '3',
                        message: "Your account not activated. Please enter OTP to activate"
                    });
                }
                let data = getCustomerResponseData(response, requestFrom);
                res.status(200).json({
                    error: '0',
                    message: "Customer Exists",
                    data
                });
            } else {
                throw {
                    reason: "NotExists"
                }
            }
        })
        .catch(error => {
            if (error.reason == "NotExists")
                res.status(400).json({
                    error: '1',
                    message: "Please enter valid credentials."
                });
            else
                res.status(500).json({
                    error: '2',
                    message: "Internal Sever Error"
                });
        });
}

const forgotPassword = (req, res) => {

    let { mobile } = req.body;

    CustomerService.findCustomer({ mobile })
        .then((response) => {
            if (response) {
                let otp = generateOTP();
                response.otp = otp;
                sendResetOTP(otp, response.mobile);
                response.save();
                res.status(200).json({ error: "0", message: "OTP sent successfully. " });
            } else
                res.status(404).json({ error: "1", message: "Please enter registered mobile number. " });
        })
        .catch((error) => {
            res.status(500).json({ error: "2", message: error.errors[0].message });
        });
}

const verifyOTP = (req, res) => {

    let { mobile, otp } = req.body;

    if (mobile)
        mobile = mobile;

    CustomerService.findCustomer({ mobile })
        .then((response) => {
            if (response) {
                if (response.otp == otp) {
                    response.block = false;
                    response.is_verified = true;
                    response.is_mobile_verified = true;
                    response.mobile_verified_on = Date.now();
                    response.updated_by = response.customer_id;
                    response.otp = null;
                    response.verified = true;
                    return response.save();
                } else {
                    throw {
                        reason: "OTPMisMatch"
                    }
                }
            } else {
                throw {
                    reason: "NotFound"
                }
            }
        })
        .then((response) => {
            res.status(200).json({ error: "0", message: "Your OTP verfication is successful" });
        })
        .catch((err) => {
            if (err.reason == "OTPMisMatch")
                res.status(400).json({ error: '1', message: "Your OTP doesn't match" });
            else if (err.reason == "NotFound")
                res.status(404).json({ error: '2', message: "Please enter registered mobile number" });
            else
                res.status(500).json({ error: '3', message: "Internal Sever Error" });
        });
}

const resendOTP = (req, res) => {

    let { mobile } = req.body;

    CustomerService.findCustomer({ mobile })
        .then((response) => {
            if (response) {
                let otp = generateOTP();
                response.otp = otp;
                response.save();
                sendRegistrationOTP(response.otp, response.mobile);
                res.status(200).json({ error: "0", message: "OTP has been sent to " + response.mobile });

            } else {
                res.status(200).json({ error: "1", message: "Please enter registered mobile number." });
            }
        })
        .catch((error) => {
            res.status(400).json({ error: "2", message: "Internal Sever Error" });
        });
}

const getProfile = (req, res) => {

    let {
        mobile
    } = req.decoded;

    CustomerService.findCustomerProfile({
        mobile
    })
        .then((response) => {
            if (response)
                res.status(200).json({
                    error: "0",
                    message: "Customer data found",
                    data: response
                });
            else
                res.status(404).json({
                    error: "1",
                    message: "Please enter registered mobile number"
                });
        })
        .catch((error) => {
            res.status(500).json({
                error: "2",
                message: "Error in getting profile data"
            });
        });
}

const getCount = (req, res) => {

    let {
        userID,
        userType
    } = req.decoded;

    let usersCount = 0,
        usersQuery = {
            userType: 'customer'
        };;

    CustomerService.count(usersQuery)
        .then((response) => {
            usersCount = response;
            let data = {
                users: usersCount
            }
            res.status(200).json({
                error: "0",
                message: "Data fetch successful",
                data: data
            });
        })
        .catch((error) => {
            res.status(404).json({
                error: "1",
                message: "Error in fetching data"
            });
        });
}

const getCustomers = async (req, res) => {

    let query = {};
    let {
        limit,
        offset,
        bydate,
        order,
        q
    } = req.query;

    query.where = {};

    query.limit = +limit || 10;
    query.offset = +offset || 0;

    if(query.limit > 100 ) query.limit = 100;

    if (q) {
        query.where = {
            [Op.or]: [
                {
                    name: {
                        $like: '%' + q + '%'
                    }
                },
                {
                    email: {
                        $like: '%' + q + '%'
                    }
                },
                {
                    mobile: {
                        $like: '%' + q + '%'
                    }
                }
            ],
            userType: 'customer'
        }

    }
    
    if(bydate){
        if(bydate=='today'){
            query.where.created_at = {
                [Op.gte]: moment().startOf('day').format("YYYY-MM-DD HH:mm:ss")
            }
        }else if(bydate=="tweek"){
            let startOf_week = moment().startOf('isoWeek').format("YYYY-MM-DD HH:mm:ss");
            let endOf_week = moment().endOf('isoWeek').format("YYYY-MM-DD HH:mm:ss");

            query.where.created_at = {
                [Op.between]: [startOf_week, endOf_week]
            }
        }else {
            let startOf_month = moment().startOf('month').format("YYYY-MM-DD HH:mm:ss");
            let endOf_month = moment().endOf('month').format("YYYY-MM-DD HH:mm:ss");

            query.where.created_at = {
                [Op.between]: [startOf_month, endOf_month]
            }
        }
    }

    query.where.userType = 'customer' ;


    if (order) {
        query.order = [
            [order.split('@')[0], order.split('@')[1]]
        ]
    } else {
        query.order = [
            ['created_at', 'DESC']
        ]
    }

    let count = await CustomerService.count({ where: query.where });

    CustomerService.findQuery(query)
        .then(response => {
            if (response) {
                res.status(200).json({
                    error: '0',
                    message: "Customers data",
                    data: response,
                    count
                });
            } else {
                res.status(400).json({
                    error: '1',
                    message: "No customers exists in the database"
                });
            }
        })
        .catch(error => {
            console.log(error)
            res.status(500).json({
                error: '1',
                message: "Internal sever error"
            });
        });
}

function getCustomerResponseData(data, requestFrom) {
    let userData = {
        _id: data.id,
        first_name: data.first_name,
        last_name: data.last_name,
        mobile: data.mobile,
        role: data.userType,
        email: data.email
    };

    let response = {
        userData
    };

    response.token = generateJwtToken({
        userID: data.id,
        first_name: data.first_name,
        first_name: data.last_name,
        mobile: data.mobile,
        email: data.email,
        role: data.userType
    }, requestFrom);

    return response;
}

const listByYear = async (req, res) => {
    let query = {};

    let { limit, offset } = req.query;
    query.limit = parseInt(limit) || undefined;
    query.offset = parseInt(offset) || undefined;

    let startOf_year = moment().startOf('year').format("YYYY-MM-DD HH:mm:ss");
    let endOf_year = moment().endOf('year').format("YYYY-MM-DD HH:mm:ss");

    query.where = {
        created_at: {
            [Op.between]: [startOf_year, endOf_year]
        }
    }

    let count = await CustomerService.count({ where: query.where });
    CustomerService.findQuery(query)
        .then(customers => {
            if (customers) {
                res.status(200).json({
                    error: '0',
                    message: "Customers data",
                    data: customers,
                    count,
                    startOf_year,
                    endOf_year
                });
            } else {
                res.status(400).json({
                    error: '1',
                    message: "No customers exists in the database",
                    startOf_year,
                    endOf_year
                });
            }
        })
        .catch(error => {
            console.log(error)
            res.status(500).json({
                error: '2',
                message: "Internal sever error"
            });
        });
}


const updateCustomer = async (req, res) => {
    let query = {};

    let { id } = req.params;
    let data = req.body;

    query.where = {
        id,
        status: true
    }

    let { first_name, last_name, gender, email } = data;

    let new_data = { first_name, last_name, gender, email };

    for (let key in new_data) {
        if (!new_data[key]) {
            delete new_data[key];
        }
    }

    try {
        let updated_cus = await CustomerService.update({ where: query.where }, new_data);
        if (updated_cus[0]) {
            res.status(200).json({
                error: '0',
                message: "Customer updated",
                data
            });
        } else {
            res.status(400).json({
                error: '1',
                message: "No customers exists with given id " + id
            });
        }
    } catch (error) {
        if (error) {
            console.log(error)
            let message = '';
            if (error.errors[0].type == 'Validation error') {
                if (error.errors[0].path == 'password')
                    message = "Password should be 6-16 characters length. Must have 1 capital and 1 numeric"
                else if (error.errors[0].path == 'first_name')
                    message = "First name must be in alphabetical characters.";
                else if (error.errors[0].path == 'last_name')
                    message = "Last name must be in alphabetical characters.";
                else if (error.errors[0].path == 'mobile')
                    message = "Please enter valid mobile number. ";
            } else if (error.errors[0].type == 'unique violation' && error.errors[0].path == 'email')
                message = "Email already exist";
            else
                message = error.errors[0].message;

            res.status(400).json({
                error: '1',
                message: message
            });
        } else
            res.status(500).json({
                error: '2',
                message: "Internal server error"
            });
    }
}

export default {
    register,
    forgotPassword,
    resetPassword,
    setPassword,
    updateMobile,
    login,
    adminLogin,
    getProfile,
    getCustomers,
    getCount,
    verifyOTP,
    resendOTP,
    uploadProfileImage,
    deleteProfileImage,
    listByYear,
    updateCustomer
}