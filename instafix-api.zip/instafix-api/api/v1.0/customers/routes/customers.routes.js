'use strict';

import express from 'express';
import CustomerController from '../controllers/customers.controller';
import {
    isCustomer,
    requires
} from '../../auth/auth.service';
import config from "../../../../config/config";
import AWS from "aws-sdk";

AWS.config.loadFromPath('./config/s3_credentials.json');

const BucketName = config.default.awsS3.bucketName;
var multer = require('multer');
// const upload = multer({ dest: './uploads/' })
const multerS3 = require('multer-s3')

var s3 = new AWS.S3()

const upload = multer({
    storage: multerS3({
        s3: s3,
        bucket: BucketName,
        acl: 'public-read',
        serverSideEncryption: 'AES256',
        contentType: multerS3.AUTO_CONTENT_TYPE,
        metadata: function(req, file, cb) {
            cb(null, { fieldName: file.fieldname });
        },
        key: function(req, file, cb) {
            cb(null, 'customers/' + req.params.id + '/' + req.params.id + "_" + Date.now().toString())
        }
    })
})

let router = express.Router();

/**
 * @api {post} /customers/register Customer registration
 * @apiName Customer registration
 * @apiGroup Customers
 *
 * @apiPermission Mobile
 * 
 * @apiHeader {String} x-request-from value: mobile
 *
 * @apiParamExample {json} Request-Example:
 *     {
            first_name:String,  // required,
            last_name: String,  // required
            password: String,   // required,
            mobile: Number,     // required,
            email: String       // required
 *     }
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 201 OK
 *     {
            "error": "0",
            "message": "Customer register is successful",
            "data": {
                    "is_verified": false,
                    "is_mobile_verified": false,
                    "is_email_verified": false,
                    "block": true,
                    "status": true,
                    "id": 10,
                    "mobile": "9885224114",
                    "email": "sureshkoduri34@gmail.com",
                    "first_name": "Suresh",
                    "last_name": "Koduri",
                    "customer_id": "CUST100004",
                    "signup_from": "web",
                    "updated_at": "2018-09-28T13:06:24.601Z",
                    "created_at": "2018-09-28T13:06:24.601Z"
            }
        }
 *
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 400 Bad Request
 *     {
 *       "error": "1",
 *       "message": "Error: {message}"
 *     }
 * 
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 400 Bad Request
 *     {
 *       "error": "2",
 *       "message": "Internal server error"
 *     }
 *
 */

router.post('/v1.0/customers/register', requires.body, CustomerController.register);

/**
 * @api {post} /customers/login Login
 * @apiName Manual Login
 * @apiGroup Customers
 *
 * @apiPermission Mobile
 *
 * @apiParamExample {json} Request-Example:
 *     {
 *          "mobile": 9885224114,
 *          "password": "welcome",
 *     }
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
            "error": "0",
            "message": "Customer Exists",
            "data": {
                "userData": {
                    "_id": "CUST100004",
                    "first_name": "Suresh",
                    "last_name": "Koduri",
                    "mobile": 9885224114,
                    "role": "customer"
                },
                "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7InVzZXJJRCI6IkNVU1QxMDAwMDQiLCJmbmFtZSI6IlN1cmVzaCIsImxuYW1lIjoiS29kdXJpIiwibW9iaWxlIjo5ODg1MjI0MTE0LCJyb2xlIjoiY3VzdG9tZXIifSwiaWF0IjoxNTM4MTQwMzkxLCJleHAiOjE1Njk2NzYzOTF9._PjaY9W080qjym_gn29zwIt-k41gSJS1r3OhLIiDO5I"
            }
        }
 *
 * 
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 400 Bad Request
 *     {
 *          "error": "1",
 *          "message": "Invalid Credentials"
 *     }
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Internal Server
 *     {
 *          "error": "2",
 *          "message": "Internal server error."
 *     }
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Internal Server
 *      {
            error: '3',
            message: "Your account not activated. Please enter OTP to activate"
        }
 *
 */

router.post('/v1.0/customers/login', requires.body, CustomerController.login);

/**
 * @api {post} /customers/admin/login Admin login
 * @apiName Admin login
 * @apiGroup Customers
 *
 * @apiPermission Web
 * 
 * @apiHeader {String} x-request-from value: web
 *
 * @apiParamExample {json} Request-Example:
 *     {
 *          "email": "admin@instafix.com",
 *          "password": "welcome@123",
 *     }
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
            "error": "0",
            "message": "Admin Exists",
            "data": {
                "userData": {
                    "_id": 1,
                    "first_name": "Admin",
                    "last_name": "Admin",
                    "email": "admin@instafix.com",
                    "role": "admin"
                },
                "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7InVzZXJJRCI6IkNVU1QxMDAwMDQiLCJmbmFtZSI6IlN1cmVzaCIsImxuYW1lIjoiS29kdXJpIiwibW9iaWxlIjo5ODg1MjI0MTE0LCJyb2xlIjoiY3VzdG9tZXIifSwiaWF0IjoxNTM4MTQwMzkxLCJleHAiOjE1Njk2NzYzOTF9._PjaY9W080qjym_gn29zwIt-k41gSJS1r3OhLIiDO5I"
            }
        }
 *
 * 
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 400 Bad Request
 *     {
 *          "error": "1",
 *          "message": "Invalid Credentials"
 *     }
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Internal Server
 *     {
 *          "error": "2",
 *          "message": "Internal server error."
 *     }
 *
 */

router.post('/v1.0/customers/admin/login', requires.body, CustomerController.adminLogin);

/**
 * @api {post} /customers/verify Verify OTP
 * @apiName Verify OTP
 * @apiGroup Customers
 *
 * @apiPermission Mobile App, Website
 *
 * @apiParamExample {json} Request-Example:
 *     {
 *           "mobile": 9885224116,
 *           "otp": 249021
 *     }
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "error": "0",
 *       "message": "Your OTP Verfication is successful"
 *    }
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 400 Bad Request
 *     {
 *       "error": "1",
 *       "message": "Your OTP doesn't match"
 *     }
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 400 Bad Request
 *     {
 *       "error": "2",
 *       "message": "Details not found with the given mobile"
 *     }
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Internal Server
 *     {
 *       "error": "3",
 *       "message": "Internal Sever Error"
 *     }
 *
 */

router.post('/v1.0/customers/verify', requires.body, CustomerController.verifyOTP);

/**
 * @api {post} /customers/otp/resend Resend OTP
 * @apiName Resend OTP
 * @apiGroup Customers
 *
 * @apiPermission Mobile App, Website
 *
 * @apiParamExample {json} Request-Example:
 *     {
 *           "mobile": 9885224116
 *     }
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "error": "0",
 *       "message": "OTP has been sent to 9885224116"
 *    }
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 400 Bad Request
 *     {
 *       "error": "1",
 *       "message": "Please check your mobile number."
 *     }
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Internal Server
 *     {
 *       "error": "2",
 *       "message": "Internal Sever Error"
 *     }
 *
 */

router.post('/v1.0/customers/otp/resend', requires.body, CustomerController.resendOTP);

/**
 * @api {post} /customers/password/forgot Forgot password
 * @apiName Forgot password
 * @apiGroup Customers
 *
 * @apiPermission Mobile App, Website
 *
 * @apiParamExample {json} Request-Example:
 *     {
 *           "mobile": 9885224116
 *     }
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *       "error": "0",
 *       "message": "OTP sent successfully"
 *    }
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 400 Bad Request
 *     {
 *       "error": "1",
 *       "message": "Customer data not found"
 *     }
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Internal Server
 *     {
 *       "error": "2",
 *       "message": "Internal Sever Error"
 *     }
 *
 */

router.post('/v1.0/customers/password/forgot', requires.body, CustomerController.forgotPassword);

/**
 * @api {post} /customers/password/reset Change password
 * @apiName Change password
 * @apiGroup Customers
 *
 * @apiPermission Mobile App, Website
 * 
 * @apiHeader {String} x-access-code User Token
 *
 * @apiParamExample {json} Request-Example:
 *     {
 *           "mobile": 9885224116,
 *           "oldPassword": "welcome",
 *           "newPassword": "welcome123"
 *     }
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *          "error": "0",
 *          "message": "Your password reset successful"
 *     }
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 400 Bad Request
 *     {
 *          "error": "1",
 *          "message": "Old and new passwords shouldn't be same."
 *     }
 * 
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 400 Bad Request
 *     {
 *          "error": "4",
 *          "message": "Details not found with the given mobile"
 *     }
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Internal Server
 *     {
 *          "error": "3",
 *          "message": "Error: ${ message }"
 *     }
 *
 */

router.post('/v1.0/customers/password/reset', isCustomer.authenticated, requires.body, CustomerController.resetPassword);

/**
 * @api {post} /customers/password/new New password
 * @apiName New password
 * @apiGroup Customers
 *
 * @apiPermission Mobile App, Website
 * 
 * @apiHeader {String} x-access-code User Token
 *
 * @apiParamExample {json} Request-Example:
 *     {
 *           "mobile": 9885224116,
 *           "otp": 234422,
 *           "password": "welcome123"
 *     }
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *          "error": "0",
 *          "message": "Your password reset successful"
 *     }
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 400 Bad Request
 *     {
 *          "error": "1",
 *          "message": "OTP didn't match."
 *     }
 * 
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 400 Bad Request
 *     {
 *          "error": "2",
 *          "message": "Details not found with the given mobile"
 *     }
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Internal Server
 *     {
 *          "error": "3",
 *          "message": "Error: ${ message }"
 *     }
 *
 */

router.post('/v1.0/customers/password/new', requires.body, CustomerController.setPassword);

/**
 * @api {post} /customers/update/mobile Mobile number update
 * @apiName Mobile number update
 * @apiGroup Customers
 *
 * @apiPermission Mobile App, Website
 * 
 * @apiHeader {String} x-access-code User Token
 *
 * @apiParamExample {json} Request-Example:
 *     {
 *           "mobile": 9885224116,
 *           "otp": 122111,
 *           "mobileNew": "7799139459"
 *     }
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
 *          "error": "0",
 *          "message": "Your mobile number updated successfully"
 *     }
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 400 Bad Request
 *     {
 *          "error": "1",
 *          "message": "OTP didn't match."
 *     }
 * 
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 400 Bad Request
 *     {
 *          "error": "2",
 *          "message": "Details not found with the given mobile"
 *     }
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Internal Server
 *     {
 *          "error": "3",
 *          "message": "Error: ${ message }"
 *     }
 *
 */

router.post('/v1.0/customers/update/mobile', isCustomer.authenticated, requires.body, CustomerController.updateMobile);

/**
 * @api {post} /customers/upload/profile_image/:id Profile Image update
 * @apiName Profile Image update
 * @apiGroup Customers
 *
 * @apiPermission Mobile App, Website
 * 
 * @apiHeader {String} x-access-code User Token
 * 
 * @apiParam (Request body) {File} avatar multipart/form-data file object
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     
 *    {
            "error": "0",
            "message": "Profile image uploaded successfully",
            "data": {
                profile_pic : "https://instafix-dev.s3.ap-south-1.amazonaws.com/CUST100001_1539002346235?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIAJ2427THK3UAFEWGQ%2F20181008%2Fap-south-1%2Fs3%2Faws4_request&X-Amz-Date=20181008T123907Z&X-Amz-Expires=900&X-Amz-Signature=ee43f8c2192354b5ab6b7b3a1101d2cafbd14b0c29b5bef60926b921a5a68e92&X-Amz-SignedHeaders=host"
            }
 *     }
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 400 Bad Request
 *     {
 *          "error": "2",
 *          "message": "Customer data not found"
 *     }
 * 
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Internal Server
 *     {
 *          "error": "1",
 *          "message": "Internal server error"
 *     }
 *
 */

router.post('/v1.0/customers/upload/profile_image/:id', isCustomer.authenticated, upload.single('avatar'), CustomerController.uploadProfileImage);

/**
 * @api {delete} /customers/remove/profile_image/:id Delete Profile Image
 * @apiName Delete Profile Image
 * @apiGroup Customers
 *
 * @apiPermission Mobile App, Website
 * 
 * @apiHeader {String} x-access-code User Token
 * 
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *    {
            "error": "0",
            "message": "Profile image deleted successfully"
 *     }
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 400 Bad Request
 *     {
 *          "error": "2",
 *          "message": "Customer data not found"
 *     }
 * 
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Internal Server
 *     {
 *          "error": "1",
 *          "message": "Internal server error"
 *     }
 *
 */

router.delete('/v1.0/customers/remove/profile_image/:id', isCustomer.authenticated, CustomerController.deleteProfileImage);

/**
 * @api {get} /customers?limit=10&offset=0 Customers list
 * @apiName Customers list
 * @apiGroup Customers
 *
 * @apiPermission Admin
 *
 * @apiHeader {String} x-access-code User Token
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
            "error": "0",
            "message": "Customers data",
            "data": [
                {
                    "first_name": "Manikyam",
                    "last_name": "Kavs",
                    "mobile": 9885224116,
                    "email": "kavsmanikyam@gmail.com",
                    "gender": null,
                    "is_verified": false,
                    "profile_pic": null,
                    "created_at": "2018-10-02T10:57:41.000Z",
                    "address": [
                        {
                            "id": 1,
                            "address1": "address 1 is here",
                            "address2": "",
                            "city": "city",
                            "state": "state",
                            "country": "india",
                            "pin": 495227,
                            "latitude": "17.438907",
                            "longitude": "78.364215",
                            "location": {
                                "type": "Point",
                                "coordinates": [
                                    17.438907,
                                    78.364215
                                ]
                            },
                            "status": false,
                            "createdBy": null,
                            "updatedBy": null,
                            "created_at": "2018-10-03T07:29:43.000Z",
                            "updated_at": "2018-10-03T07:29:43.000Z",
                            "customer_id": null,
                            "technician_id": null
                        }
                    ]
                }
            ]
        }
 *
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "1",
 *       "message": "No customers exists in the database."
 *     }
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Server Error
 *     {
 *       "error": "2",
 *       "message": "Internal sever error"
 *     }
 *
 */

router.get('/v1.0/customers', isCustomer.hasAdminRole, CustomerController.getCustomers);

/**
 * @api {get} /customers/profile Get profile
 * @apiName Customers Get profile
 * @apiGroup Customers
 *
 * @apiPermission logged in User
 *
 * @apiHeader {String} x-access-code User Token
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
            "error": "0",
            "message": "Customer data found",
            "data":
                {
                    "first_name": "Manikyam",
                    "last_name": "Kavs",
                    "mobile": 9885224116,
                    "email": "kavsmanikyam@gmail.com",
                    "gender": null,
                    "profile_pic": null,
                    "address":
                        {
                            "id": 1,
                            "address1": "address 1 is here",
                            "address2": "",
                            "city": "city",
                            "state": "state",
                            "country": "india",
                            "pin": 495227,
                            "latitude": "17.438907",
                            "longitude": "78.364215",
                            "location": {
                                "type": "Point",
                                "coordinates": [
                                    17.438907,
                                    78.364215
                                ]
                            },
                            "status": false,
                            "createdBy": null,
                            "updatedBy": null,
                            "created_at": "2018-10-03T07:29:43.000Z",
                            "updated_at": "2018-10-03T07:29:43.000Z",
                            "customer_id": null,
                            "technician_id": null
                        }
                    
                }
        }
 *
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "1",
 *       "message": "Mobile number not registered."
 *     }
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Server Error
 *     {
 *       "error": "2",
 *       "message": "Error in getting profile data"
 *     }
 *
 */

router.get('/v1.0/customers/profile', isCustomer.authenticated, CustomerController.getProfile);
/**
 * @api {post} /customers/update/:id Update a Customer
 * @apiName Update a Customer
 * @apiGroup Customers
 *
 * @apiPermission Customer
 *
 * @apiHeader {String} x-access-code User Token
 * 
 * @apiParamExample {json} Request-Example:
 *     {
 *           "email": "myemail@something.com"
 *     }
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
            "error": "0",
            "message": "Customer updated",
            "data": 
                {
                    "email": "myemail@something.com",
                   
                }
            
        }
 *
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "1",
 *       "message": "No customers exists with given id"
 *     }
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Server Error
 *     {
 *       "error": "2",
 *       "message": "Internal sever error"
 *     }
 *
 */
router.post('/v1.0/customers/update/:id', isCustomer.authenticated, requires.body, CustomerController.updateCustomer);


export default router;