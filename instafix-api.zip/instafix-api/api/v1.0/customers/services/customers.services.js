'use strict';
const Sequelize = require('sequelize');
const Customer = require('../../models').customers;
const Address = require('../../models').addresses;
import md5 from 'md5';
const Op = Sequelize.Op;

const findOne = (query, selectable) => {
    return Customer.findOne(query);
}

const findOneCustomer = (query, selectable) => {
    if (query.password) {
        query.password = md5(query.password);
    }
    return Customer.findOne({
        where: query,
        attributes: selectable
    });
}

const findCustomerProfile = (query) => {
    if (query.password) {
        query.password = md5(query.password);
    }
    return Customer.findOne({
        where: query,
        attributes: ['id', 'first_name', 'last_name', 'gender', 'mobile', 'email', 'profile_pic'],
        include: {
            model: Address,
            as: 'address'
        }
    });
}

const findOnetoPush = (query) => {
    return Customer.findOne(query);
}

const findCustomer = (query) => {
    //console.log(query);
    if (query.password) {
        query.password = md5(query.password);
    }
    return Customer.findOne({ where: query });
}

const find = (query) => {
    return Customer.find(query);
}

const lastInsertedID = () => {
    return Customer.findAll({
        limit: 1,
        order: [
            ['id', 'DESC']
        ]
    });
}

const findQuery = (query) => {
    let attr = ['first_name', 'last_name', 'mobile', 'email', 'gender', 'profile_pic', 'created_at']
    return Customer.findAll({
        where: query.where,
        attributes: attr,
        include: [{
            model: Address,
            as: 'address'
        }],
        offset: query.offset,
        limit: query.limit,
        order: query.order
    });
}


const create = (data) => {
    if (data.password) {
        data.password = md5(data.password);
    }
    return Customer.create(data);
    // console.log(Customer.create(data))
    // return new Customer(data);
}

const update = (query, data) => {
    if (data.password)
        data.password = md5(data.password);

    data.updated_at = new Date();

    return Customer.update(data, query);
}

const updateMany = (query, data) => {
    return Customer.updateMany(query, data);
}

const remove = (query) => {
    return Customer.remove(query);
}

const count = (query) => {
    return Customer.count(query);
}

const countAll = () => {
    return Customer.count().then(c);
}

export default {
    countAll,
    findOne,
    findOnetoPush,
    findCustomer,
    findOneCustomer,
    findCustomerProfile,
    create,
    find,
    findQuery,
    lastInsertedID,
    update,
    updateMany,
    remove,
    count
};