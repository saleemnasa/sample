'use strict';

import EnquiresService from '../services/enquires.services';

import {
    sendEnqueryFormToAdmin
} from '../../../../common/mails';

const add = (req, res) => {
    let data = req.body;
    let source = req.headers["x-request-from"] || 'web';
    data.source = source;

    EnquiresService.create(data)
        .then(response => {
            let email_data = {
                // to: 'vikram.siddamsetty@sparity.com',
                // to: 'hil.instafix@gmail.com',
                enquiry: response,
                bcc: '',
                subject: `New Entry - Instafix Contact Us`
            }

            sendEnqueryFormToAdmin(email_data);
            res.status(200).json({
                error: "0",
                message: "Enquery added",
                data: response
            });
        })
        .catch(error => {
            console.log(error);
            res.status(500).json({
                error: "1",
                message: "Error: " + error.errors[0].message
            });
        })
}

const getEnquires = (req, res) => {

    let query = {};
    query.where = {};
    let {
        limit,
        offset,
        q
    } = req.query;

    if (q) {
        query.where = {
            [Op.or]: [{
                    feedback_title: {
                        $like: '%' + q + '%'
                    }
                },
                {
                    feedback_text: {
                        $like: '%' + q + '%'
                    }
                }
            ],
        }

    }

    if (limit)
        query.limit = +limit || undefined;
    if (offset)
        query.offset = +offset || undefined;

    EnquiresService.findAll(query)
        .then(response => {
            if (response) {
                res.status(200).json({
                    error: '0',
                    message: "Enquires data",
                    data: response
                });
            } else {
                res.status(400).json({
                    error: '1',
                    message: "No Enquires exists in the database"
                });
            }
        })
        .catch(error => {
            console.log(error)
            res.status(500).json({
                error: '1',
                message: "Internal sever error"
            });
        });
}

const getFeedbackDetails = (req, res) => {

    let query = {};
    let {
        feedback_id
    } = req.params;

    query = { id: +feedback_id };
    EnquiresService.findFeedback(query)
        .then(response => {
            if (response) {
                res.status(200).json({
                    error: '0',
                    message: "Feedback data",
                    data: response
                });
            } else {
                res.status(400).json({
                    error: '1',
                    message: "No feedback exists in the database"
                });
            }
        })
        .catch(error => {
            console.log(error)
            res.status(500).json({
                error: '1',
                message: "Internal sever error"
            });
        });
}

const replyFeedback = (req, res) => {
    let data = req.body,
        query = {};

    if (!data.id)
        return res.status(500).json({
            error: '2',
            message: "feedback id needed"
        });

    query.where = { id: data.id }
    if (data.reply_message)
        data.is_replied = true;

    EnquiresService.update(data, query)
        .then(response => {
            if (response[0])
                res.status(200).json({
                    error: '0',
                    message: "Feedback updated."
                });
            else
                res.status(400).json({
                    error: '2',
                    message: "Feedback not found."
                });

        })
        .catch(error => {
            console.log(error)
            res.status(500).json({
                error: '1',
                message: "Error: " + error.errors[0].message
            });
        });
}

export default {
    add,
    getEnquires,
    getFeedbackDetails,
    replyFeedback
}