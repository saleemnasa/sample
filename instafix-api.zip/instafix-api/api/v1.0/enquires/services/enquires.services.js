'use strict';
const Sequelize = require('sequelize');
const Enquires = require('../../models').enquires;
const Op = Sequelize.Op;

const findOneEnquires = (query, selectable) => {
    return Enquires.findOne({
        where: query,
        attributes: selectable
    });
}

const findEnquires = (query) => {
    return Enquires.findOne({
        where: query,
        include: {
            model: Customer,
            where: {
                id: Sequelize.col('feedbacks.customer_id')
            },
            attributes: ['first_name', 'last_name', 'mobile', 'email'],
            as: 'customer'
        }
    });
}

const find = (query) => {
    return Enquires.find(query);
}

const findAll = (query) => {
    return Enquires.findAll({
        where: query.where,
        offset: query.offset,
        limit: query.limit,
    });
}

const create = (data) => {
    return Enquires.create(data);
}

const update = (data, query) => {
    return Enquires.update(data, query);
}

const updateMany = (query, data) => {
    return Enquires.updateMany(query, data);
}

const remove = (query) => {
    return Enquires.remove(query);
}

const count = (query) => {
    return Enquires.count(query);
}

export default {
    findEnquires,
    findOneEnquires,
    create,
    find,
    findAll,
    update,
    updateMany,
    remove,
    count
};