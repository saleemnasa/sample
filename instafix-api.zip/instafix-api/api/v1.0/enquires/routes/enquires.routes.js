'use strict';

import express from 'express';
import EnquiresController from '../controllers/enquires.controller';
import {
    isCustomer,
    requires
} from '../../auth/auth.service';

let router = express.Router();

/**
 * @api {get} /enquiries?limit=10&offset=0 Enquiries list
 * @apiName Enquiries list
 * @apiGroup Enquiries
 *
 * @apiPermission Admin
 *
 * @apiHeader {String} x-access-code User Token
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 200 OK
 *     {
            "error": "0",
            "message": "enquiries data",
            "data": [
                        {
                            "id": 1,
                            "name": "saleeem",
                            "email": "email@email.com",
                            "number": "1212121212",
                            "message": "good work. add a feature to repair bikes also at home",
                            "source": "web",
                            "updated_at": "2018-11-02T07:27:12.807Z",
                            "created_at": "2018-11-02T07:27:12.807Z"
                        },
                        {
                            "id": 2,
                            "name": "Sameer",
                            "email": "email@something.com",
                            "number": "8745898568",
                            "message": "lets meet on tuesday",
                            "source": "web",
                            "updated_at": "2018-11-02T07:27:12.807Z",
                            "created_at": "2018-11-02T07:27:12.807Z"
                        }
                    ]
                }
            ]
        }
 *
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 404 Not Found
 *     {
 *       "error": "1",
 *       "message": "No enquiry exists in the database."
 *     }
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Server Error
 *     {
 *       "error": "2",
 *       "message": "Internal sever error"
 *     }
 *
 */

router.get('/v1.0/enquiries', isCustomer.hasAdminRole, EnquiresController.getEnquires);

/**
 * @api {post} /enquiries/add Add an Enquiry
 * @apiName Add an Enquiry
 * @apiGroup Enquiries
 *
 * 
 * @apiHeader {String} x-request-from value: mobile/web
 * @apiHeader {String} x-access-code value: token
 *
 * @apiParamExample {json} Request-Example:
 *     {
            name: String,         // required,
            email: String,     // required
            number: Number,     // required,
            message: Number,      // required,
 *     }
 *
 * @apiSuccessExample Success-Response:
 *     HTTP/1.1 201 OK
 *     {
            "error": "0",
            "message": "Enquiry added",
            "data": {
                "status": true,
                "id": 1,
                "name": "Saleem",
                "email": "saleem@sparity.com",
                "number": "9823456784",
                "message": "I want to contact you.",
                "updated_at": "2018-10-03T11:53:45.224Z",
                "created_at": "2018-10-03T11:53:45.224Z"
            }
        }
 *
 *
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 400 Bad Request
 *     {
 *       "error": "1",
 *       "message": "Error: {message}"
 *     }
 * 
 * @apiErrorExample {json} Error-Response:
 *     HTTP/1.1 500 Bad Request
 *     {
 *       "error": "2",
 *       "message": "Internal server error"
 *     }
 *
 */

router.post('/v1.0/enquiries/add', requires.body, EnquiresController.add);

export default router;