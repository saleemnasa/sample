define({ "api": [
  {
    "type": "post",
    "url": "/customers/admin/login",
    "title": "Admin login",
    "name": "Admin_login",
    "group": "Customers",
    "permission": [
      {
        "name": "Web"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-request-from",
            "description": "<p>value: web</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\n     \"email\": \"admin@instafix.com\",\n     \"password\": \"welcome@123\",\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n        \"error\": \"0\",\n        \"message\": \"Admin Exists\",\n        \"data\": {\n            \"userData\": {\n                \"_id\": 1,\n                \"first_name\": \"Admin\",\n                \"last_name\": \"Admin\",\n                \"email\": \"admin@instafix.com\",\n                \"role\": \"admin\"\n            },\n            \"token\": \"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7InVzZXJJRCI6IkNVU1QxMDAwMDQiLCJmbmFtZSI6IlN1cmVzaCIsImxuYW1lIjoiS29kdXJpIiwibW9iaWxlIjo5ODg1MjI0MTE0LCJyb2xlIjoiY3VzdG9tZXIifSwiaWF0IjoxNTM4MTQwMzkxLCJleHAiOjE1Njk2NzYzOTF9._PjaY9W080qjym_gn29zwIt-k41gSJS1r3OhLIiDO5I\"\n        }\n    }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 Bad Request\n{\n     \"error\": \"1\",\n     \"message\": \"Invalid Credentials\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Internal Server\n{\n     \"error\": \"2\",\n     \"message\": \"Internal server error.\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/customers/routes/customers.routes.js",
    "groupTitle": "Customers"
  },
  {
    "type": "post",
    "url": "/customers/password/reset",
    "title": "Change password",
    "name": "Change_password",
    "group": "Customers",
    "permission": [
      {
        "name": "Mobile App, Website"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-access-code",
            "description": "<p>User Token</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\n      \"mobile\": 9885224116,\n      \"oldPassword\": \"welcome\",\n      \"newPassword\": \"welcome123\"\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n     \"error\": \"0\",\n     \"message\": \"Your password reset successful\"\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 Bad Request\n{\n     \"error\": \"1\",\n     \"message\": \"Old and new passwords shouldn't be same.\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 Bad Request\n{\n     \"error\": \"4\",\n     \"message\": \"Details not found with the given mobile\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Internal Server\n{\n     \"error\": \"3\",\n     \"message\": \"Error: ${ message }\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/customers/routes/customers.routes.js",
    "groupTitle": "Customers"
  },
  {
    "type": "post",
    "url": "/customers/register",
    "title": "Customer registration",
    "name": "Customer_registration",
    "group": "Customers",
    "permission": [
      {
        "name": "Mobile"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-request-from",
            "description": "<p>value: mobile</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\n        first_name:String,  // required,\n        last_name: String,  // required\n        password: String,   // required,\n        mobile: Number,     // required,\n        email: String       // required\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 201 OK\n{\n        \"error\": \"0\",\n        \"message\": \"Customer register is successful\",\n        \"data\": {\n                \"is_verified\": false,\n                \"is_mobile_verified\": false,\n                \"is_email_verified\": false,\n                \"block\": true,\n                \"status\": true,\n                \"id\": 10,\n                \"mobile\": \"9885224114\",\n                \"email\": \"sureshkoduri34@gmail.com\",\n                \"first_name\": \"Suresh\",\n                \"last_name\": \"Koduri\",\n                \"customer_id\": \"CUST100004\",\n                \"signup_from\": \"web\",\n                \"updated_at\": \"2018-09-28T13:06:24.601Z\",\n                \"created_at\": \"2018-09-28T13:06:24.601Z\"\n        }\n    }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 Bad Request\n{\n  \"error\": \"1\",\n  \"message\": \"Error: {message}\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 Bad Request\n{\n  \"error\": \"2\",\n  \"message\": \"Internal server error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/customers/routes/customers.routes.js",
    "groupTitle": "Customers"
  },
  {
    "type": "get",
    "url": "/customers/profile",
    "title": "Get profile",
    "name": "Customers_Get_profile",
    "group": "Customers",
    "permission": [
      {
        "name": "logged in User"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-access-code",
            "description": "<p>User Token</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n        \"error\": \"0\",\n        \"message\": \"Customer data found\",\n        \"data\":\n            {\n                \"first_name\": \"Manikyam\",\n                \"last_name\": \"Kavs\",\n                \"mobile\": 9885224116,\n                \"email\": \"kavsmanikyam@gmail.com\",\n                \"gender\": null,\n                \"profile_pic\": null,\n                \"address\":\n                    {\n                        \"id\": 1,\n                        \"address1\": \"address 1 is here\",\n                        \"address2\": \"\",\n                        \"city\": \"city\",\n                        \"state\": \"state\",\n                        \"country\": \"india\",\n                        \"pin\": 495227,\n                        \"latitude\": \"17.438907\",\n                        \"longitude\": \"78.364215\",\n                        \"location\": {\n                            \"type\": \"Point\",\n                            \"coordinates\": [\n                                17.438907,\n                                78.364215\n                            ]\n                        },\n                        \"status\": false,\n                        \"createdBy\": null,\n                        \"updatedBy\": null,\n                        \"created_at\": \"2018-10-03T07:29:43.000Z\",\n                        \"updated_at\": \"2018-10-03T07:29:43.000Z\",\n                        \"customer_id\": null,\n                        \"technician_id\": null\n                    }\n                \n            }\n    }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 Not Found\n{\n  \"error\": \"1\",\n  \"message\": \"Mobile number not registered.\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Server Error\n{\n  \"error\": \"2\",\n  \"message\": \"Error in getting profile data\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/customers/routes/customers.routes.js",
    "groupTitle": "Customers"
  },
  {
    "type": "get",
    "url": "/customers?limit=10&offset=0",
    "title": "Customers list",
    "name": "Customers_list",
    "group": "Customers",
    "permission": [
      {
        "name": "Admin"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-access-code",
            "description": "<p>User Token</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n        \"error\": \"0\",\n        \"message\": \"Customers data\",\n        \"data\": [\n            {\n                \"first_name\": \"Manikyam\",\n                \"last_name\": \"Kavs\",\n                \"mobile\": 9885224116,\n                \"email\": \"kavsmanikyam@gmail.com\",\n                \"gender\": null,\n                \"is_verified\": false,\n                \"profile_pic\": null,\n                \"created_at\": \"2018-10-02T10:57:41.000Z\",\n                \"address\": [\n                    {\n                        \"id\": 1,\n                        \"address1\": \"address 1 is here\",\n                        \"address2\": \"\",\n                        \"city\": \"city\",\n                        \"state\": \"state\",\n                        \"country\": \"india\",\n                        \"pin\": 495227,\n                        \"latitude\": \"17.438907\",\n                        \"longitude\": \"78.364215\",\n                        \"location\": {\n                            \"type\": \"Point\",\n                            \"coordinates\": [\n                                17.438907,\n                                78.364215\n                            ]\n                        },\n                        \"status\": false,\n                        \"createdBy\": null,\n                        \"updatedBy\": null,\n                        \"created_at\": \"2018-10-03T07:29:43.000Z\",\n                        \"updated_at\": \"2018-10-03T07:29:43.000Z\",\n                        \"customer_id\": null,\n                        \"technician_id\": null\n                    }\n                ]\n            }\n        ]\n    }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 Not Found\n{\n  \"error\": \"1\",\n  \"message\": \"No customers exists in the database.\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Server Error\n{\n  \"error\": \"2\",\n  \"message\": \"Internal sever error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/customers/routes/customers.routes.js",
    "groupTitle": "Customers"
  },
  {
    "type": "get",
    "url": "/customers/list_by_day?limit=10&offset=0",
    "title": "Customers list by Day",
    "name": "Customers_list_by_day",
    "group": "Customers",
    "permission": [
      {
        "name": "Admin"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-access-code",
            "description": "<p>User Token</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n        \"error\": \"0\",\n        \"message\": \"Customers data\",\n        \"data\": [\n            {\n                \"first_name\": \"Manikyam\",\n                \"last_name\": \"Kavs\",\n                \"mobile\": 9885224116,\n                \"email\": \"kavsmanikyam@gmail.com\",\n                \"gender\": null,\n                \"is_verified\": false,\n                \"profile_pic\": null,\n                \"created_at\": \"2018-10-02T10:57:41.000Z\",\n                \"address\":\n                    {\n                        \"id\": 1,\n                        \"address1\": \"address 1 is here\",\n                        \"address2\": \"\",\n                        \"city\": \"city\",\n                        \"state\": \"state\",\n                        \"country\": \"india\",\n                        \"pin\": 495227,\n                        \"latitude\": \"17.438907\",\n                        \"longitude\": \"78.364215\",\n                        \"location\": {\n                            \"type\": \"Point\",\n                            \"coordinates\": [\n                                17.438907,\n                                78.364215\n                            ]\n                        },\n                        \"status\": false,\n                        \"createdBy\": null,\n                        \"updatedBy\": null,\n                        \"created_at\": \"2018-10-03T07:29:43.000Z\",\n                        \"updated_at\": \"2018-10-03T07:29:43.000Z\",\n                        \"customer_id\": null,\n                        \"technician_id\": null\n                    }\n                \n            }\n        ]\n    }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 Not Found\n{\n  \"error\": \"1\",\n  \"message\": \"No customers exists in the database.\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Server Error\n{\n  \"error\": \"2\",\n  \"message\": \"Internal sever error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/customers/routes/customers.routes.js",
    "groupTitle": "Customers"
  },
  {
    "type": "get",
    "url": "/customers/list_by_month?limit=10&offset=0",
    "title": "Customers list by Month",
    "name": "Customers_list_by_month",
    "group": "Customers",
    "permission": [
      {
        "name": "Admin"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-access-code",
            "description": "<p>User Token</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n        \"error\": \"0\",\n        \"message\": \"Customers data\",\n        \"data\": [\n            {\n                \"first_name\": \"Manikyam\",\n                \"last_name\": \"Kavs\",\n                \"mobile\": 9885224116,\n                \"email\": \"kavsmanikyam@gmail.com\",\n                \"gender\": null,\n                \"is_verified\": false,\n                \"profile_pic\": null,\n                \"created_at\": \"2018-10-02T10:57:41.000Z\",\n                \"address\":\n                    {\n                        \"id\": 1,\n                        \"address1\": \"address 1 is here\",\n                        \"address2\": \"\",\n                        \"city\": \"city\",\n                        \"state\": \"state\",\n                        \"country\": \"india\",\n                        \"pin\": 495227,\n                        \"latitude\": \"17.438907\",\n                        \"longitude\": \"78.364215\",\n                        \"location\": {\n                            \"type\": \"Point\",\n                            \"coordinates\": [\n                                17.438907,\n                                78.364215\n                            ]\n                        },\n                        \"status\": false,\n                        \"createdBy\": null,\n                        \"updatedBy\": null,\n                        \"created_at\": \"2018-10-03T07:29:43.000Z\",\n                        \"updated_at\": \"2018-10-03T07:29:43.000Z\",\n                        \"customer_id\": null,\n                        \"technician_id\": null\n                    }\n                \n            }\n        ]\n    }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 Not Found\n{\n  \"error\": \"1\",\n  \"message\": \"No customers exists in the database.\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Server Error\n{\n  \"error\": \"2\",\n  \"message\": \"Internal sever error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/customers/routes/customers.routes.js",
    "groupTitle": "Customers"
  },
  {
    "type": "get",
    "url": "/customers/list_by_week?limit=10&offset=0",
    "title": "Customers list by Week",
    "name": "Customers_list_by_week",
    "group": "Customers",
    "permission": [
      {
        "name": "Admin"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-access-code",
            "description": "<p>User Token</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n        \"error\": \"0\",\n        \"message\": \"Customers data\",\n        \"data\": [\n            {\n                \"first_name\": \"Manikyam\",\n                \"last_name\": \"Kavs\",\n                \"mobile\": 9885224116,\n                \"email\": \"kavsmanikyam@gmail.com\",\n                \"gender\": null,\n                \"is_verified\": false,\n                \"profile_pic\": null,\n                \"created_at\": \"2018-10-02T10:57:41.000Z\",\n                \"address\":\n                    {\n                        \"id\": 1,\n                        \"address1\": \"address 1 is here\",\n                        \"address2\": \"\",\n                        \"city\": \"city\",\n                        \"state\": \"state\",\n                        \"country\": \"india\",\n                        \"pin\": 495227,\n                        \"latitude\": \"17.438907\",\n                        \"longitude\": \"78.364215\",\n                        \"location\": {\n                            \"type\": \"Point\",\n                            \"coordinates\": [\n                                17.438907,\n                                78.364215\n                            ]\n                        },\n                        \"status\": false,\n                        \"createdBy\": null,\n                        \"updatedBy\": null,\n                        \"created_at\": \"2018-10-03T07:29:43.000Z\",\n                        \"updated_at\": \"2018-10-03T07:29:43.000Z\",\n                        \"customer_id\": null,\n                        \"technician_id\": null\n                    }\n                \n            }\n        ]\n    }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 Not Found\n{\n  \"error\": \"1\",\n  \"message\": \"No customers exists in the database.\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Server Error\n{\n  \"error\": \"2\",\n  \"message\": \"Internal sever error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/customers/routes/customers.routes.js",
    "groupTitle": "Customers"
  },
  {
    "type": "get",
    "url": "/customers/list_by_year?limit=10&offset=0",
    "title": "Customers list by Year",
    "name": "Customers_list_by_year",
    "group": "Customers",
    "permission": [
      {
        "name": "Admin"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-access-code",
            "description": "<p>User Token</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n        \"error\": \"0\",\n        \"message\": \"Customers data\",\n        \"data\": [\n            {\n                \"first_name\": \"Manikyam\",\n                \"last_name\": \"Kavs\",\n                \"mobile\": 9885224116,\n                \"email\": \"kavsmanikyam@gmail.com\",\n                \"gender\": null,\n                \"is_verified\": false,\n                \"profile_pic\": null,\n                \"created_at\": \"2018-10-02T10:57:41.000Z\",\n                \"address\":\n                    {\n                        \"id\": 1,\n                        \"address1\": \"address 1 is here\",\n                        \"address2\": \"\",\n                        \"city\": \"city\",\n                        \"state\": \"state\",\n                        \"country\": \"india\",\n                        \"pin\": 495227,\n                        \"latitude\": \"17.438907\",\n                        \"longitude\": \"78.364215\",\n                        \"location\": {\n                            \"type\": \"Point\",\n                            \"coordinates\": [\n                                17.438907,\n                                78.364215\n                            ]\n                        },\n                        \"status\": false,\n                        \"createdBy\": null,\n                        \"updatedBy\": null,\n                        \"created_at\": \"2018-10-03T07:29:43.000Z\",\n                        \"updated_at\": \"2018-10-03T07:29:43.000Z\",\n                        \"customer_id\": null,\n                        \"technician_id\": null\n                    }\n                \n            }\n        ]\n    }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 Not Found\n{\n  \"error\": \"1\",\n  \"message\": \"No customers exists in the database.\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Server Error\n{\n  \"error\": \"2\",\n  \"message\": \"Internal sever error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/customers/routes/customers.routes.js",
    "groupTitle": "Customers"
  },
  {
    "type": "delete",
    "url": "/customers/remove/profile_image/:id",
    "title": "Delete Profile Image",
    "name": "Delete_Profile_Image",
    "group": "Customers",
    "permission": [
      {
        "name": "Mobile App, Website"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-access-code",
            "description": "<p>User Token</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n{\n         \"error\": \"0\",\n         \"message\": \"Profile image deleted successfully\"\n }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 Bad Request\n{\n     \"error\": \"2\",\n     \"message\": \"Customer data not found\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Internal Server\n{\n     \"error\": \"1\",\n     \"message\": \"Internal server error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/customers/routes/customers.routes.js",
    "groupTitle": "Customers"
  },
  {
    "type": "post",
    "url": "/customers/password/forgot",
    "title": "Forgot password",
    "name": "Forgot_password",
    "group": "Customers",
    "permission": [
      {
        "name": "Mobile App, Website"
      }
    ],
    "parameter": {
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\n      \"mobile\": 9885224116\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n {\n   \"error\": \"0\",\n   \"message\": \"OTP sent successfully\"\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 Bad Request\n{\n  \"error\": \"1\",\n  \"message\": \"Customer data not found\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Internal Server\n{\n  \"error\": \"2\",\n  \"message\": \"Internal Sever Error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/customers/routes/customers.routes.js",
    "groupTitle": "Customers"
  },
  {
    "type": "post",
    "url": "/customers/login",
    "title": "Login",
    "name": "Manual_Login",
    "group": "Customers",
    "permission": [
      {
        "name": "Mobile"
      }
    ],
    "parameter": {
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\n     \"mobile\": 9885224114,\n     \"password\": \"welcome\",\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n        \"error\": \"0\",\n        \"message\": \"Customer Exists\",\n        \"data\": {\n            \"userData\": {\n                \"_id\": \"CUST100004\",\n                \"first_name\": \"Suresh\",\n                \"last_name\": \"Koduri\",\n                \"mobile\": 9885224114,\n                \"role\": \"customer\"\n            },\n            \"token\": \"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7InVzZXJJRCI6IkNVU1QxMDAwMDQiLCJmbmFtZSI6IlN1cmVzaCIsImxuYW1lIjoiS29kdXJpIiwibW9iaWxlIjo5ODg1MjI0MTE0LCJyb2xlIjoiY3VzdG9tZXIifSwiaWF0IjoxNTM4MTQwMzkxLCJleHAiOjE1Njk2NzYzOTF9._PjaY9W080qjym_gn29zwIt-k41gSJS1r3OhLIiDO5I\"\n        }\n    }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 Bad Request\n{\n     \"error\": \"1\",\n     \"message\": \"Invalid Credentials\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Internal Server\n{\n     \"error\": \"2\",\n     \"message\": \"Internal server error.\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Internal Server\n {\n        error: '3',\n        message: \"Your account not activated. Please enter OTP to activate\"\n    }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/customers/routes/customers.routes.js",
    "groupTitle": "Customers"
  },
  {
    "type": "post",
    "url": "/customers/update/mobile",
    "title": "Mobile number update",
    "name": "Mobile_number_update",
    "group": "Customers",
    "permission": [
      {
        "name": "Mobile App, Website"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-access-code",
            "description": "<p>User Token</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\n      \"mobile\": 9885224116,\n      \"otp\": 122111,\n      \"mobileNew\": \"7799139459\"\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n     \"error\": \"0\",\n     \"message\": \"Your mobile number updated successfully\"\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 Bad Request\n{\n     \"error\": \"1\",\n     \"message\": \"OTP didn't match.\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 Bad Request\n{\n     \"error\": \"2\",\n     \"message\": \"Details not found with the given mobile\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Internal Server\n{\n     \"error\": \"3\",\n     \"message\": \"Error: ${ message }\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/customers/routes/customers.routes.js",
    "groupTitle": "Customers"
  },
  {
    "type": "post",
    "url": "/customers/password/new",
    "title": "New password",
    "name": "New_password",
    "group": "Customers",
    "permission": [
      {
        "name": "Mobile App, Website"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-access-code",
            "description": "<p>User Token</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\n      \"mobile\": 9885224116,\n      \"otp\": 234422,\n      \"password\": \"welcome123\"\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n     \"error\": \"0\",\n     \"message\": \"Your password reset successful\"\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 Bad Request\n{\n     \"error\": \"1\",\n     \"message\": \"OTP didn't match.\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 Bad Request\n{\n     \"error\": \"2\",\n     \"message\": \"Details not found with the given mobile\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Internal Server\n{\n     \"error\": \"3\",\n     \"message\": \"Error: ${ message }\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/customers/routes/customers.routes.js",
    "groupTitle": "Customers"
  },
  {
    "type": "post",
    "url": "/customers/upload/profile_image/:id",
    "title": "Profile Image update",
    "name": "Profile_Image_update",
    "group": "Customers",
    "permission": [
      {
        "name": "Mobile App, Website"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-access-code",
            "description": "<p>User Token</p>"
          }
        ]
      }
    },
    "parameter": {
      "fields": {
        "Request body": [
          {
            "group": "Request body",
            "type": "File",
            "optional": false,
            "field": "avatar",
            "description": "<p>multipart/form-data file object</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n \n{\n         \"error\": \"0\",\n         \"message\": \"Profile image uploaded successfully\",\n         \"data\": {\n             profile_pic : \"https://instafix-dev.s3.ap-south-1.amazonaws.com/CUST100001_1539002346235?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIAJ2427THK3UAFEWGQ%2F20181008%2Fap-south-1%2Fs3%2Faws4_request&X-Amz-Date=20181008T123907Z&X-Amz-Expires=900&X-Amz-Signature=ee43f8c2192354b5ab6b7b3a1101d2cafbd14b0c29b5bef60926b921a5a68e92&X-Amz-SignedHeaders=host\"\n         }\n }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 Bad Request\n{\n     \"error\": \"2\",\n     \"message\": \"Customer data not found\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Internal Server\n{\n     \"error\": \"1\",\n     \"message\": \"Internal server error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/customers/routes/customers.routes.js",
    "groupTitle": "Customers"
  },
  {
    "type": "post",
    "url": "/customers/otp/resend",
    "title": "Resend OTP",
    "name": "Resend_OTP",
    "group": "Customers",
    "permission": [
      {
        "name": "Mobile App, Website"
      }
    ],
    "parameter": {
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\n      \"mobile\": 9885224116\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n {\n   \"error\": \"0\",\n   \"message\": \"OTP has been sent to 9885224116\"\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 Bad Request\n{\n  \"error\": \"1\",\n  \"message\": \"Please check your mobile number.\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Internal Server\n{\n  \"error\": \"2\",\n  \"message\": \"Internal Sever Error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/customers/routes/customers.routes.js",
    "groupTitle": "Customers"
  },
  {
    "type": "post",
    "url": "/customers/update/:id",
    "title": "Update a Customer",
    "name": "Update_a_Customer",
    "group": "Customers",
    "permission": [
      {
        "name": "Customer"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-access-code",
            "description": "<p>User Token</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\n      \"email\": \"myemail@something.com\"\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n        \"error\": \"0\",\n        \"message\": \"Customer updated\",\n        \"data\": \n            {\n                \"email\": \"myemail@something.com\",\n               \n            }\n        \n    }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 Not Found\n{\n  \"error\": \"1\",\n  \"message\": \"No customers exists with given id\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Server Error\n{\n  \"error\": \"2\",\n  \"message\": \"Internal sever error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/customers/routes/customers.routes.js",
    "groupTitle": "Customers"
  },
  {
    "type": "post",
    "url": "/customers/verify",
    "title": "Verify OTP",
    "name": "Verify_OTP",
    "group": "Customers",
    "permission": [
      {
        "name": "Mobile App, Website"
      }
    ],
    "parameter": {
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\n      \"mobile\": 9885224116,\n      \"otp\": 249021\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n {\n   \"error\": \"0\",\n   \"message\": \"Your OTP Verfication is successful\"\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 Bad Request\n{\n  \"error\": \"1\",\n  \"message\": \"Your OTP doesn't match\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 Bad Request\n{\n  \"error\": \"2\",\n  \"message\": \"Details not found with the given mobile\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Internal Server\n{\n  \"error\": \"3\",\n  \"message\": \"Internal Sever Error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/customers/routes/customers.routes.js",
    "groupTitle": "Customers"
  },
  {
    "type": "post",
    "url": "/enquiries/add",
    "title": "Add an Enquiry",
    "name": "Add_an_Enquiry",
    "group": "Enquiries",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-request-from",
            "description": "<p>value: mobile/web</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-access-code",
            "description": "<p>value: token</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\n        name: String,         // required,\n        email: String,     // required\n        number: Number,     // required,\n        message: Number,      // required,\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 201 OK\n{\n        \"error\": \"0\",\n        \"message\": \"Enquiry added\",\n        \"data\": {\n            \"status\": true,\n            \"id\": 1,\n            \"name\": \"Saleem\",\n            \"email\": \"saleem@sparity.com\",\n            \"number\": \"9823456784\",\n            \"message\": \"I want to contact you.\",\n            \"updated_at\": \"2018-10-03T11:53:45.224Z\",\n            \"created_at\": \"2018-10-03T11:53:45.224Z\"\n        }\n    }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 Bad Request\n{\n  \"error\": \"1\",\n  \"message\": \"Error: {message}\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Bad Request\n{\n  \"error\": \"2\",\n  \"message\": \"Internal server error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/enquires/routes/enquires.routes.js",
    "groupTitle": "Enquiries"
  },
  {
    "type": "get",
    "url": "/enquiries?limit=10&offset=0",
    "title": "Enquiries list",
    "name": "Enquiries_list",
    "group": "Enquiries",
    "permission": [
      {
        "name": "Admin"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-access-code",
            "description": "<p>User Token</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n        \"error\": \"0\",\n        \"message\": \"enquiries data\",\n        \"data\": [\n                    {\n                        \"id\": 1,\n                        \"name\": \"saleeem\",\n                        \"email\": \"email@email.com\",\n                        \"number\": \"1212121212\",\n                        \"message\": \"good work. add a feature to repair bikes also at home\",\n                        \"source\": \"web\",\n                        \"updated_at\": \"2018-11-02T07:27:12.807Z\",\n                        \"created_at\": \"2018-11-02T07:27:12.807Z\"\n                    },\n                    {\n                        \"id\": 2,\n                        \"name\": \"Sameer\",\n                        \"email\": \"email@something.com\",\n                        \"number\": \"8745898568\",\n                        \"message\": \"lets meet on tuesday\",\n                        \"source\": \"web\",\n                        \"updated_at\": \"2018-11-02T07:27:12.807Z\",\n                        \"created_at\": \"2018-11-02T07:27:12.807Z\"\n                    }\n                ]\n            }\n        ]\n    }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 Not Found\n{\n  \"error\": \"1\",\n  \"message\": \"No enquiry exists in the database.\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Server Error\n{\n  \"error\": \"2\",\n  \"message\": \"Internal sever error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/enquires/routes/enquires.routes.js",
    "groupTitle": "Enquiries"
  },
  {
    "type": "post",
    "url": "/categories/add",
    "title": "Add Category",
    "name": "Add_Category",
    "group": "Feedback_Categories",
    "permission": [
      {
        "name": "Mobile"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-request-from",
            "description": "<p>value: mobile</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-access-code",
            "description": "<p>value: token</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\n        name: \"Category 1\",         // required,\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 201 OK\n{\n        \"error\": \"0\",\n        \"message\": \"Feedback added\",\n        \"data\": {\n            \"is_replied\": false,\n            \"status\": true,\n            \"id\": 1,\n            \"customer_id\": \"1\",\n            \"feedback_title\": \"testtitle1112\",\n            \"feedback_text\": \"this is text\",\n            \"feedback_type\": \"query12\",\n            \"updated_at\": \"2018-10-03T11:53:45.224Z\",\n            \"created_at\": \"2018-10-03T11:53:45.224Z\"\n        }\n    }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 Bad Request\n{\n  \"error\": \"1\",\n  \"message\": \"Error: {message}\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Bad Request\n{\n  \"error\": \"2\",\n  \"message\": \"Internal server error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/feedback_categories/routes/feedback_categories.routes.js",
    "groupTitle": "Feedback_Categories"
  },
  {
    "type": "delete",
    "url": "/categories/:id",
    "title": "Delete Category",
    "name": "Delete_Category",
    "group": "Feedback_Categories",
    "permission": [
      {
        "name": "Admin"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-access-code",
            "description": "<p>User Token</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n       error: '0',\n       message: \"Category deleted successfully.\"\n   }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 Not Found\n{\n       \"error\": \"1\",\n       \"message\": \"No category exists in the database\"\n   }",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Server Error\n{\n     \"error\": \"2\",\n     \"message\": \"Internal sever error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/feedback_categories/routes/feedback_categories.routes.js",
    "groupTitle": "Feedback_Categories"
  },
  {
    "type": "get",
    "url": "/categories",
    "title": "Feedback Categories list",
    "name": "Feedback_Categories_list",
    "group": "Feedback_Categories",
    "permission": [
      {
        "name": "Admin"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-access-code",
            "description": "<p>User Token</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n    \"error\": \"0\",\n    \"message\": \"Feedback category data\",\n    \"data\":     [\n            {\n                \"id\": 1,\n                \"name\": \"Category 1\",\n                \"created_by\": null,\n                \"updated_by\": null,\n                \"status\": true,\n                \"created_at\": \"2018-10-09T07:42:33.000Z\",\n                \"updated_at\": \"2018-10-09T07:56:33.000Z\"\n            },\n            {\n                \"id\": 2,\n                \"name\": \"Category 2\",\n                \"created_by\": null,\n                \"updated_by\": null,\n                \"status\": true,\n                \"created_at\": \"2018-10-09T07:42:37.000Z\",\n                \"updated_at\": \"2018-10-09T07:56:26.000Z\"\n            }\n        ],\n    }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 Not Found\n{\n  \"error\": \"1\",\n  \"message\": \"No feedbacks exists in the database.\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Server Error\n{\n  \"error\": \"2\",\n  \"message\": \"Internal sever error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/feedback_categories/routes/feedback_categories.routes.js",
    "groupTitle": "Feedback_Categories"
  },
  {
    "type": "get",
    "url": "/categories/:id",
    "title": "Get Category",
    "name": "Get_Category",
    "group": "Feedback_Categories",
    "permission": [
      {
        "name": "Admin"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-access-code",
            "description": "<p>User Token</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n       \"error\": \"0\",\n       \"message\": \"Feedback category data\",\n       \"data\": {\n           \"id\": 2,\n           \"name\": \"Category 1\",\n           \"created_by\": null,\n           \"updated_by\": null,\n           \"status\": true,\n           \"created_at\": \"2018-10-09T07:42:37.000Z\",\n           \"updated_at\": \"2018-10-09T07:42:37.000Z\"\n       }\n   }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 Not Found\n{\n       \"error\": \"1\",\n       \"message\": \"No category exists in the database\"\n   }",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Server Error\n{\n     \"error\": \"2\",\n     \"message\": \"Internal sever error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/feedback_categories/routes/feedback_categories.routes.js",
    "groupTitle": "Feedback_Categories"
  },
  {
    "type": "put",
    "url": "/categories/:id",
    "title": "Update Category",
    "name": "Update_Category",
    "group": "Feedback_Categories",
    "permission": [
      {
        "name": "Admin"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-access-code",
            "description": "<p>User Token</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n       error: '0',\n       message: \"Category updated successfully.\"\n   }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 Not Found\n{\n       \"error\": \"1\",\n       \"message\": \"No category exists in the database\"\n   }",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Server Error\n{\n     \"error\": \"2\",\n     \"message\": \"Internal sever error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/feedback_categories/routes/feedback_categories.routes.js",
    "groupTitle": "Feedback_Categories"
  },
  {
    "type": "post",
    "url": "/feedbacks/add",
    "title": "Add Feedback",
    "name": "Add_Feedback",
    "group": "Feedbacks",
    "permission": [
      {
        "name": "Mobile"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-request-from",
            "description": "<p>value: mobile</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-access-code",
            "description": "<p>value: token</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\n        customer_id: Number,         // required,\n        feedback_title: String,     // required\n        feedback_text: Text,     // required,\n        feedback_type: Number,      // required,\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 201 OK\n{\n        \"error\": \"0\",\n        \"message\": \"Feedback added\",\n        \"data\": {\n            \"is_replied\": false,\n            \"status\": true,\n            \"id\": 1,\n            \"customer_id\": \"1\",\n            \"feedback_title\": \"testtitle1112\",\n            \"feedback_text\": \"this is text\",\n            \"feedback_type\": \"query12\",\n            \"updated_at\": \"2018-10-03T11:53:45.224Z\",\n            \"created_at\": \"2018-10-03T11:53:45.224Z\"\n        }\n    }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 Bad Request\n{\n  \"error\": \"1\",\n  \"message\": \"Error: {message}\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Bad Request\n{\n  \"error\": \"2\",\n  \"message\": \"Internal server error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/feedbacks/routes/feedbacks.routes.js",
    "groupTitle": "Feedbacks"
  },
  {
    "type": "get",
    "url": "/feedbacks?limit=10&offset=0",
    "title": "Feedbacks list",
    "name": "Feedbacks_list",
    "group": "Feedbacks",
    "permission": [
      {
        "name": "Admin"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-access-code",
            "description": "<p>User Token</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n        \"error\": \"0\",\n        \"message\": \"Feedbacks data\",\n        \"data\": [\n                    {\n                        \"id\": 1,\n                        \"customer_id\": 2,\n                        \"feedback_title\": \"feed back 2\",\n                        \"feedback_text\": \"feed back 2\",\n                        \"feedback_type\": 0,\n                        \"reply_message\": null,\n                        \"is_replied\": false,\n                        \"created_by\": null,\n                        \"replied_by\": null,\n                        \"status\": true,\n                        \"created_at\": \"2018-10-04T06:12:35.000Z\",\n                        \"updated_at\": \"2018-10-04T06:12:35.000Z\",\n                        \"customer\": {\n                            \"id\": 2,\n                            \"first_name\": \"Suresh\",\n                            \"last_name\": \"Koduri\",\n                            \"email\": \"sureshkoduri36@gmail.com\",\n                            \"gender\": null,\n                            \"mobile\": 9885224116,\n                            \"customer_id\": \"CUST100002\",\n                            \"address_id\": null,\n                            \"profile_pic\": null,\n                            \"signup_from\": \"mobile\",\n                            \"status\": true\n                        }\n                    },\n                    {\n                        \"id\": 2,\n                        \"customer_id\": 1,\n                        \"feedback_title\": \"feed back 1\",\n                        \"feedback_text\": \"feed back 1\",\n                        \"feedback_type\": 0,\n                        \"reply_message\": null,\n                        \"is_replied\": false,\n                        \"created_by\": null,\n                        \"replied_by\": null,\n                        \"status\": true,\n                        \"created_at\": \"2018-10-04T06:12:46.000Z\",\n                        \"updated_at\": \"2018-10-04T06:12:46.000Z\",\n                        \"customer\": {\n                            \"id\": 1,\n                            \"first_name\": \"Admin\",\n                            \"last_name\": \"Admin\",\n                            \"email\": \"admin@sparity.com\",\n                            \"gender\": null,\n                            \"mobile\": 9999999999,\n                            \"customer_id\": \"CUST100001\",\n                            \"address_id\": null,\n                            \"profile_pic\": null,\n                            \"signup_from\": \"mobile\",\n                            \"status\": true\n                        }\n                    }\n                ]\n            }\n        ]\n    }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 Not Found\n{\n  \"error\": \"1\",\n  \"message\": \"No feedbacks exists in the database.\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Server Error\n{\n  \"error\": \"2\",\n  \"message\": \"Internal sever error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/feedbacks/routes/feedbacks.routes.js",
    "groupTitle": "Feedbacks"
  },
  {
    "type": "get",
    "url": "/feedbacks/:feedback_id",
    "title": "Get Feedback by ID",
    "name": "Get_Feedback_by_ID",
    "group": "Feedbacks",
    "permission": [
      {
        "name": "Admin"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-access-code",
            "description": "<p>User Token</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n        \"error\": \"0\",\n        \"message\": \"Feedback data\",\n        \"data\": \n                {\n                    \"id\": 1,\n                    \"customer_id\": 2,\n                    \"feedback_title\": \"feed back 2\",\n                    \"feedback_text\": \"feed back 2\",\n                    \"feedback_type\": 0,\n                    \"reply_message\": null,\n                    \"is_replied\": false,\n                    \"created_by\": null,\n                    \"replied_by\": null,\n                    \"status\": true,\n                    \"created_at\": \"2018-10-04T06:12:35.000Z\",\n                    \"updated_at\": \"2018-10-04T06:12:35.000Z\",\n                    \"customer\": {\n                        \"id\": 2,\n                        \"first_name\": \"Suresh\",\n                        \"last_name\": \"Koduri\",\n                        \"email\": \"sureshkoduri36@gmail.com\",\n                        \"gender\": null,\n                        \"mobile\": 9885224116,\n                        \"customer_id\": \"CUST100002\",\n                        \"address_id\": null,\n                        \"profile_pic\": null,\n                        \"signup_from\": \"mobile\",\n                        \"status\": true\n                    }\n                \n                }\n        \n    }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 Not Found\n{\n  \"error\": \"1\",\n  \"message\": \"No feedback exists in the database.\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Server Error\n{\n  \"error\": \"2\",\n  \"message\": \"Internal sever error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/feedbacks/routes/feedbacks.routes.js",
    "groupTitle": "Feedbacks"
  },
  {
    "type": "post",
    "url": "/feedbacks/reply",
    "title": "Reply Feedback",
    "name": "Reply_Feedback",
    "group": "Feedbacks",
    "permission": [
      {
        "name": "Admin"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-access-code",
            "description": "<p>value: token</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\n        id: Number,         // required,\n        reply_message: Text,      // required,\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 201 OK\n{\n        \"error\": \"0\",\n        \"message\": \"Feedback updated.\"\n    }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Server error\n{\n  \"error\": \"1\",\n  \"message\": \"Error: {message}\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 Bad Request\n{\n  \"error\": \"2\",\n  \"message\": \"Feedback not found\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/feedbacks/routes/feedbacks.routes.js",
    "groupTitle": "Feedbacks"
  },
  {
    "type": "post",
    "url": "/pages/add",
    "title": "Add a page",
    "name": "Add_a_page",
    "group": "Pages",
    "permission": [
      {
        "name": "Admin"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-access-code",
            "description": "<p>User Token</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\n            \"page_name\": \"about_us\",\n            \"title\": \"About Us\",\n            \"content\": \"this is sample content\"\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n                \"error\": \"0\",\n                \"message\": \"Page added successfully.\",\n                \"data\": {\n                    \"status\": true,\n                    \"id\": 6,\n                    \"page_name\": \"about_us1\",\n                    \"title\": \"About Us\",\n                    \"content\": \"this is sample content\",\n                    \"created_by\": 0,\n                    \"updated_by\": 0,\n                    \"created_at\": \"2018-10-09T12:22:57.303Z\",\n                    \"updated_at\": \"2018-10-09T12:22:57.303Z\"\n                }\n         }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Server Error\n{\n  \"error\": \"1\",\n  \"message\": \"Internal sever error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/pages/routes/pages.routes.js",
    "groupTitle": "Pages"
  },
  {
    "type": "get",
    "url": "/pages?limit=10&offset=0",
    "title": "Pages list",
    "name": "Pages_list",
    "group": "Pages",
    "permission": [
      {
        "name": "Admin"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-access-code",
            "description": "<p>User Token</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n        \"error\": \"0\",\n        \"message\": \"Pages data\",\n        \"data\": [\n                    {\n                        \"id\": 1,\n                        \"title\": \"\",\n                        \"content\": \"\",\n                        \"page_name\": \"\"\n                    },\n                    {\n                        \"id\": 2,\n                        \"title\": \"\",\n                        \"content\": \"\",\n                        \"page_name\": \"\"\n                    }\n                ]\n            }\n        ]\n    }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 Not Found\n{\n  \"error\": \"1\",\n  \"message\": \"No Pages exists in the database.\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Server Error\n{\n  \"error\": \"2\",\n  \"message\": \"Internal sever error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/pages/routes/pages.routes.js",
    "groupTitle": "Pages"
  },
  {
    "type": "post",
    "url": "/pages/update/:page_id",
    "title": "Update a page",
    "name": "Update_a_page",
    "group": "Pages",
    "permission": [
      {
        "name": "Admin"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-access-code",
            "description": "<p>User Token</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\n            \"page_name\": \"about_us\",\n            \"title\": \"About Us\",\n            \"content\": \"this is sample content\",\n            \"status\": false // add this key for soft delete of a page \n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n        \"error\": \"0\",\n        \"message\": \"Feedbacks data\",\n        \"data\":{\n                \"error\": \"0\",\n                \"message\": \"Page added successfully.\",\n                \"data\": {\n                    \"id\": 6,\n                    \"page_name\": \"about_us1\",\n                    \"title\": \"About Us\",\n                    \"content\": \"this is sample content\",\n                }\n            }\n            }\n        ]\n    }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Server Error\n{\n  \"error\": \"1\",\n  \"message\": \"Internal sever error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/pages/routes/pages.routes.js",
    "groupTitle": "Pages"
  },
  {
    "type": "post",
    "url": "/settings/add",
    "title": "Add a setting",
    "name": "Add_a_setting",
    "group": "Settings",
    "permission": [
      {
        "name": "Admin"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-access-code",
            "description": "<p>User Token</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\n            \"name\": \"radius\",\n            \"value\": \"2\",\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n                \"error\": \"0\",\n                \"message\": \"Setting added successfully.\",\n                \"data\": {\n                    \"status\": true,\n                    \"id\": 6,\n                    \"name\": \"radius\",\n                    \"value\": \"2\",\n                    \"created_by\": 0,\n                    \"updated_by\": 0,\n                    \"created_at\": \"2018-10-09T12:22:57.303Z\",\n                    \"updated_at\": \"2018-10-09T12:22:57.303Z\"\n                }\n         }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Server Error\n{\n  \"error\": \"1\",\n  \"message\": \"Internal sever error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/settings/routes/settings.routes.js",
    "groupTitle": "Settings"
  },
  {
    "type": "get",
    "url": "/get_cities/:state_code",
    "title": "Get Cities list by state code",
    "name": "Get_Cities_list",
    "group": "Settings",
    "permission": [
      {
        "name": "Admin"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-access-code",
            "description": "<p>User Token</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "    HTTP/1.1 200 OK\n    {\n    \"error\": \"0\",\n    \"message\": \"Cities found.\",\n    \"data\": [\n        {\n            \"name\": \"Zahirabad\",\n            \"state_code\": \"40\"\n        },\n        {\n            \"name\": \"Yellandu\",\n            \"state_code\": \"40\"\n        },\n        {\n            \"name\": \"Warangal\",\n            \"state_code\": \"40\"\n        },\n        {\n            \"name\": \"Wanparti\",\n            \"state_code\": \"40\"\n        }\n    ]\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Server Error\n{\n  \"error\": \"1\",\n  \"message\": \"Internal sever error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/settings/routes/settings.routes.js",
    "groupTitle": "Settings"
  },
  {
    "type": "get",
    "url": "/get_states",
    "title": "Get States list",
    "name": "Get_States_list",
    "group": "Settings",
    "permission": [
      {
        "name": "Admin"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-access-code",
            "description": "<p>User Token</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "    HTTP/1.1 200 OK\n    {\n    \"error\": \"0\",\n    \"message\": \"States found.\",\n    \"data\": [\n        {\n            \"name\": \"Andhra Pradesh\",\n            \"code\": \"02\"\n        },\n        {\n            \"name\": \"Manipur\",\n            \"code\": \"17\"\n        },\n        {\n            \"name\": \"Himachal Pradesh\",\n            \"code\": \"11\"\n        },\n        {\n            \"name\": \"Jharkhand\",\n            \"code\": \"38\"\n        },\n        {\n            \"name\": \"Punjab\",\n            \"code\": \"23\"\n        },\n        {\n            \"name\": \"Tamil Nadu\",\n            \"code\": \"25\"\n        }\n    ]\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Server Error\n{\n  \"error\": \"1\",\n  \"message\": \"Internal sever error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/settings/routes/settings.routes.js",
    "groupTitle": "Settings"
  },
  {
    "type": "get",
    "url": "/times",
    "title": "Get Times data",
    "name": "Get_Times_data",
    "group": "Settings",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "    HTTP/1.1 200 OK\n    {\n    \"error\": \"0\",\n    \"message\": \"Times data.\",\n    \"data\": [\n        '00:00', ...etc\n    ]\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/settings/routes/settings.routes.js",
    "groupTitle": "Settings"
  },
  {
    "type": "get",
    "url": "/settings?limit=10&offset=0",
    "title": "Settings list",
    "name": "Settings_list",
    "group": "Settings",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n        \"error\": \"0\",\n        \"message\": \"Settings data\",\n        \"android\": {\n            \"radius\": \"3\",\n            \"app_name\": \"Insta Fix\",\n            \"plumber_default_img\": \"https://s3.ap-south-1.amazonaws.com/instafix-dev/images/plumber.jpg\",\n            \"customer_default_img\": \"https://s3.ap-south-1.amazonaws.com/instafix-dev/images/customer.jpg\",\n            \"radius_min_range\": \"1\",\n            \"radius_max_range\": \"10\",\n            \"radius_units\": \"km\"\n        }\n    }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 Not Found\n{\n  \"error\": \"1\",\n  \"message\": \"No Settings exists in the database.\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Server Error\n{\n  \"error\": \"2\",\n  \"message\": \"Internal sever error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/settings/routes/settings.routes.js",
    "groupTitle": "Settings"
  },
  {
    "type": "get",
    "url": "/settings/admin?limit=10&offset=0",
    "title": "Settings list",
    "name": "Settings_list_for_Admin_operations",
    "group": "Settings",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n        \"error\": \"0\",\n        \"message\": \"Settings data\",\n        \"android\": {\n        \"radius\": \"3\",\n        \"app_name\": \"Insta Fix\",\n        \"plumber_default_img\": \"https://s3.ap-south-1.amazonaws.com/instafix-dev/images/plumber.jpg\",\n        \"customer_default_img\": \"https://s3.ap-south-1.amazonaws.com/instafix-dev/images/customer.jpg\",\n        \"radius_min_range\": \"1\",\n        \"radius_max_range\": \"10\",\n        \"radius_units\": \"km\"\n    },\n        \"data\": [\n                    {\n                        \"id\": 1,\n                        \"name\": \"radius\",\n                        \"value\": \"2\"\n                    },\n                    {\n                        \"id\": 2,\n                        \"name\": \"app_name\",\n                        \"value\": \"Insta Fix\"\n                    }\n                ]\n            }\n        ]\n    }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 404 Not Found\n{\n  \"error\": \"1\",\n  \"message\": \"No Settings exists in the database.\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Server Error\n{\n  \"error\": \"2\",\n  \"message\": \"Internal sever error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/settings/routes/settings.routes.js",
    "groupTitle": "Settings"
  },
  {
    "type": "post",
    "url": "/settings/update/:setting_id",
    "title": "Update a setting",
    "name": "Update_a_setting",
    "group": "Settings",
    "permission": [
      {
        "name": "Admin"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-access-code",
            "description": "<p>User Token</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\n            \"name\": \"radius\",\n            \"value\": \"2\", // meeters\n            \"status\": false // add this key for soft delete of a setting \n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n        \"error\": \"0\",\n        \"message\": \"Feedbacks data\",\n        \"data\":{\n                \"error\": \"0\",\n                \"message\": \"Setting added successfully.\",\n                \"data\": {\n                    \"id\": 6,\n                    \"name\": \"radius\",\n                    \"value\": \"2\",\n                }\n            }\n            }\n        ]\n    }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Server Error\n{\n  \"error\": \"1\",\n  \"message\": \"Internal sever error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/settings/routes/settings.routes.js",
    "groupTitle": "Settings"
  },
  {
    "type": "put",
    "url": "/settings/update/group",
    "title": "Update multiple settings",
    "name": "Update_multiple_setting",
    "group": "Settings",
    "permission": [
      {
        "name": "Admin"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-access-code",
            "description": "<p>User Token</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Example:",
          "content": "[\n\t{\n\t\t\"id\": 6,\n\t\t\"value\": \"1\"\n\t},{\n\t\t\"id\": 7,\n\t\t\"value\": \"10\"\n\t}\n]",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "    HTTP/1.1 200 OK\n    {\n    \"error\": \"0\",\n    \"message\": \"Updated Successfully.\",\n    \"data\": [\n        {\n            \"id\": 6,\n            \"value\": \"1\",\n            \"is_updated\": true\n        },\n        {\n            \"id\": 7,\n            \"value\": \"10\",\n            \"is_updated\": true\n        }\n    ]\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Server Error\n{\n  \"error\": \"1\",\n  \"message\": \"Internal sever error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/settings/routes/settings.routes.js",
    "groupTitle": "Settings"
  },
  {
    "type": "post",
    "url": "/technicians/register/:mobile",
    "title": "Add Technician",
    "name": "Add_Technician",
    "group": "Technicians",
    "permission": [
      {
        "name": "Admin Technician"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-request-from",
            "description": "<p>value: web/mobile , profile : file, aadhar_front: file, aadhar_back: file</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Example:",
          "content": " { // note: send data in form-data format // keys for file uploads profile pic - profile, aadhar front - aadhar_front, aadhar back - aadhar_back\n\t\"first_name\": \"Hans\",\n\t\"last_name\": \"Jimmar\",\n\t\"mobile\": 1234567043,\n\t\"password\": \"password\",\n\t\"service\": {\n\t\t\"service_id\": 1,\n\t\t\"preferred_location\": \"ameerpet\",\n\t\t\"start_time\": \"1:00\",\n\t\t\"end_time\": \"13:00\"\n\t},\n\t\"address\": {\n\t\t\"address1\": \"hidden hills\",\n\t\t\"city\": \"LA\",\n\t\t\"state\": \"state\",\n\t\t\"pin\": 495227,\n\t\t\"country\": \"india\",\n\t\t\"latitude\": \"17.438907\",\n\t\t\"longitude\": \"78.364215\"\n\t}\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 201 OK\n {\n   \"error\": \"0\",\n   \"message\": \"Technician Register is Successful\"\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 Bad Request\n{\n  \"error\": \"1\",\n  \"message\": \"Technician Registration Failed.\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 Bad Request\n{\n  \"error\": \"2\",\n  \"message\": \"Some Fields are missing.\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 Bad Request\n{\n  \"error\": \"3\",\n  \"message\": \"Technician Already Exists with same details\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Bad Request\n{\n  \"error\": \"4\",\n  \"message\": \"Internal Sever Error\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 Bad Request\n{\n  \"error\": \"2\",\n  \"message\": \"Please enter a valid email or mobile number\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/otps/routes/otps.routes.js",
    "groupTitle": "Technicians"
  },
  {
    "type": "post",
    "url": "/technicians/register/:mobile",
    "title": "Add Technician",
    "name": "Add_Technician",
    "group": "Technicians",
    "permission": [
      {
        "name": "Admin Technician"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-request-from",
            "description": "<p>value: web/mobile , profile : file, aadhar_front: file, aadhar_back: file</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Example:",
          "content": " { // note: send data in form-data format // keys for file uploads profile pic - profile, aadhar front - aadhar_front, aadhar back - aadhar_back\n\t\"first_name\": \"Hans\",\n\t\"last_name\": \"Jimmar\",\n\t\"mobile\": 1234567043,\n\t\"password\": \"password\",\n\t\"service\": {\n\t\t\"service_id\": 1,\n\t\t\"preferred_location\": \"ameerpet\",\n\t\t\"start_time\": \"1:00\",\n\t\t\"end_time\": \"13:00\"\n\t},\n\t\"address\": {\n\t\t\"address1\": \"hidden hills\",\n\t\t\"city\": \"LA\",\n\t\t\"state\": \"state\",\n\t\t\"pin\": 495227,\n\t\t\"country\": \"india\",\n\t\t\"latitude\": \"17.438907\",\n\t\t\"longitude\": \"78.364215\"\n\t}\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 201 OK\n {\n   \"error\": \"0\",\n   \"message\": \"Technician Register is Successful\"\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 Bad Request\n{\n  \"error\": \"1\",\n  \"message\": \"Technician Registration Failed.\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 Bad Request\n{\n  \"error\": \"2\",\n  \"message\": \"Some Fields are missing.\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 Bad Request\n{\n  \"error\": \"3\",\n  \"message\": \"Technician Already Exists with same details\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Bad Request\n{\n  \"error\": \"4\",\n  \"message\": \"Internal Sever Error\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 Bad Request\n{\n  \"error\": \"2\",\n  \"message\": \"Please enter a valid email or mobile number\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/technicians/routes/technicians.routes.js",
    "groupTitle": "Technicians"
  },
  {
    "type": "post",
    "url": "/technicians/delete",
    "title": "Delete a Technician",
    "name": "Delete_Technicians",
    "group": "Technicians",
    "permission": [
      {
        "name": "Admin Technician"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-access-code",
            "description": "<p>value: User Token profile : file, aadhar_front: file, aadhar_back: file</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\n \"id\": 1, // required must be technician id\n   }",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": " HTTP/1.1 200 OK\n {\n   \"error\": \"0\",\n   \"message\": \"Technician deleted successfully.\"\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 Bad Request\n{\n  \"error\": \"1\",\n  \"message\": \"Technician not found.\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Bad Request\n{\n  \"error\": \"2\",\n  \"message\": \"Internal Sever Error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/technicians/routes/technicians.routes.js",
    "groupTitle": "Technicians"
  },
  {
    "type": "get",
    "url": "/technicians?limit=10&offset=0",
    "title": "Get Technicians",
    "name": "Get_Technicians",
    "group": "Technicians",
    "permission": [
      {
        "name": "Admin Technician"
      }
    ],
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "    HTTP/1.1 201 OK\n{\n    \"error\": \"0\",\n    \"message\": \"Technicians data\",\n    \"data\": [\n        {\n            \"id\": 8,\n            \"first_name\": \"Martin\",\n            \"last_name\": \"Km\",\n            \"email\": null,\n            \"gender\": null,\n            \"mobile\": 1234567049,\n            \"technician_id\": \"TECH100005\",\n            \"address_id\": 7,\n            \"pan\": null,\n            \"aadhar\": null,\n            \"profile_pic\": null,\n            \"status\": true,\n            \"services\": {\n                \"id\": 1,\n                \"name\": \"Plumber\",\n                \"technician_services\": {\n                    \"technician_id\": 8,\n                    \"service_id\": 1,\n                    \"preferred_location\": \"Chennai\",\n                    \"start_time\": \"01:00:00\",\n                    \"end_time\": \"13:00:00\"\n                }\n            },\n            \"address\": {\n                \"id\": 7,\n                \"address1\": \"T nagar\",\n                \"address2\": null,\n                \"city\": \"Chennai\",\n                \"state\": \"Tamil Nadu\",\n                \"country\": \"india\",\n                \"pin\": 495227,\n                \"latitude\": \"12.902424563866342\",\n                \"longitude\": \"80.20500580068112\",\n                \"location\": {\n                    \"type\": \"Point\",\n                    \"coordinates\": [\n                        12.902424563866342,\n                        80.20500580068112\n                    ]\n                }\n            }\n        },\n        {\n            \"id\": 9,\n            \"first_name\": \"Cristina\",\n            \"last_name\": \"Mate\",\n            \"email\": null,\n            \"gender\": null,\n            \"mobile\": 1234567042,\n            \"technician_id\": \"TECH100006\",\n            \"address_id\": 8,\n            \"pan\": null,\n            \"aadhar\": null,\n            \"profile_pic\": null,\n            \"status\": true,\n            \"services\": {\n                \"id\": 1,\n                \"name\": \"Plumber\",\n                \"technician_services\": {\n                    \"technician_id\": 9,\n                    \"service_id\": 1,\n                    \"preferred_location\": \"Chennai\",\n                    \"start_time\": \"01:00:00\",\n                    \"end_time\": \"13:00:00\"\n                }\n            },\n            \"address\": {\n                \"id\": 8,\n                \"address1\": \"T nagar\",\n                \"address2\": null,\n                \"city\": \"Chennai\",\n                \"state\": \"Tamil Nadu\",\n                \"country\": \"india\",\n                \"pin\": 495227,\n                \"latitude\": \"12.902424563866342\",\n                \"longitude\": \"80.20500580068112\",\n                \"location\": {\n                    \"type\": \"Point\",\n                    \"coordinates\": [\n                        12.902424563866342,\n                        80.20500580068112\n                    ]\n                }\n            }\n        },\n        {\n            \"id\": 11,\n            \"first_name\": \"Julia\",\n            \"last_name\": \"Home\",\n            \"email\": null,\n            \"gender\": null,\n            \"mobile\": 1234567040,\n            \"technician_id\": \"TECH100007\",\n            \"address_id\": 9,\n            \"pan\": null,\n            \"aadhar\": null,\n            \"profile_pic\": null,\n            \"status\": true,\n            \"services\": {\n                \"id\": 1,\n                \"name\": \"Plumber\",\n                \"technician_services\": {\n                    \"technician_id\": 11,\n                    \"service_id\": 1,\n                    \"preferred_location\": \"Chennai\",\n                    \"start_time\": \"01:00:00\",\n                    \"end_time\": \"13:00:00\"\n                }\n            },\n            \"address\": {\n                \"id\": 9,\n                \"address1\": \"T nagar\",\n                \"address2\": null,\n                \"city\": \"Chennai\",\n                \"state\": \"Tamil Nadu\",\n                \"country\": \"india\",\n                \"pin\": 495227,\n                \"latitude\": \"12.902424563866342\",\n                \"longitude\": \"80.20500580068112\",\n                \"location\": {\n                    \"type\": \"Point\",\n                    \"coordinates\": [\n                        12.902424563866342,\n                        80.20500580068112\n                    ]\n                }\n            }\n        }\n    ]\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 Bad Request\n{\n  \"error\": \"1\",\n  \"message\": \"No technicians exists in the database.\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Bad Request\n{\n  \"error\": \"1\",\n  \"message\": \"Internal Sever Error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/technicians/routes/technicians.routes.js",
    "groupTitle": "Technicians"
  },
  {
    "type": "post",
    "url": "/technicians/get_list_by_times?limit3&offset=0",
    "title": "Get Technicians list by Preferred timings",
    "name": "Get_Technicians_by_Preferred_timings",
    "group": "Technicians",
    "parameter": {
      "examples": [
        {
          "title": "Request-Example:",
          "content": " {\n\t\"start_time\": \"1:00:00\", // 24 hour format\n\t\"end_time\": \"23:59:59\" // 24 hour format\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "    HTTP/1.1 200 OK\n{\n    \"error\": \"0\",\n    \"message\": \"Technicians data\",\n    \"data\": [\n        {\n            \"id\": 8,\n            \"first_name\": \"Martin\",\n            \"last_name\": \"Km\",\n            \"email\": null,\n            \"gender\": null,\n            \"mobile\": 1234567049,\n            \"technician_id\": \"TECH100005\",\n            \"address_id\": 7,\n            \"pan\": null,\n            \"aadhar\": null,\n            \"profile_pic\": null,\n            \"status\": true,\n            \"services\": {\n                \"id\": 1,\n                \"name\": \"Plumber\",\n                \"technician_services\": {\n                    \"technician_id\": 8,\n                    \"service_id\": 1,\n                    \"preferred_location\": \"Chennai\",\n                    \"start_time\": \"01:00:00\",\n                    \"end_time\": \"13:00:00\"\n                }\n            },\n            \"address\": {\n                \"id\": 7,\n                \"address1\": \"T nagar\",\n                \"address2\": null,\n                \"city\": \"Chennai\",\n                \"state\": \"Tamil Nadu\",\n                \"country\": \"india\",\n                \"pin\": 495227,\n                \"latitude\": \"12.902424563866342\",\n                \"longitude\": \"80.20500580068112\",\n                \"location\": {\n                    \"type\": \"Point\",\n                    \"coordinates\": [\n                        12.902424563866342,\n                        80.20500580068112\n                    ]\n                }\n            }\n        },\n        {\n            \"id\": 9,\n            \"first_name\": \"Cristina\",\n            \"last_name\": \"Mate\",\n            \"email\": null,\n            \"gender\": null,\n            \"mobile\": 1234567042,\n            \"technician_id\": \"TECH100006\",\n            \"address_id\": 8,\n            \"pan\": null,\n            \"aadhar\": null,\n            \"profile_pic\": null,\n            \"status\": true,\n            \"services\": {\n                \"id\": 1,\n                \"name\": \"Plumber\",\n                \"technician_services\": {\n                    \"technician_id\": 9,\n                    \"service_id\": 1,\n                    \"preferred_location\": \"Chennai\",\n                    \"start_time\": \"01:00:00\",\n                    \"end_time\": \"13:00:00\"\n                }\n            },\n            \"address\": {\n                \"id\": 8,\n                \"address1\": \"T nagar\",\n                \"address2\": null,\n                \"city\": \"Chennai\",\n                \"state\": \"Tamil Nadu\",\n                \"country\": \"india\",\n                \"pin\": 495227,\n                \"latitude\": \"12.902424563866342\",\n                \"longitude\": \"80.20500580068112\",\n                \"location\": {\n                    \"type\": \"Point\",\n                    \"coordinates\": [\n                        12.902424563866342,\n                        80.20500580068112\n                    ]\n                }\n            }\n        },\n        {\n            \"id\": 11,\n            \"first_name\": \"Julia\",\n            \"last_name\": \"Home\",\n            \"email\": null,\n            \"gender\": null,\n            \"mobile\": 1234567040,\n            \"technician_id\": \"TECH100007\",\n            \"address_id\": 9,\n            \"pan\": null,\n            \"aadhar\": null,\n            \"profile_pic\": null,\n            \"status\": true,\n            \"services\": {\n                \"id\": 1,\n                \"name\": \"Plumber\",\n                \"technician_services\": {\n                    \"technician_id\": 11,\n                    \"service_id\": 1,\n                    \"preferred_location\": \"Chennai\",\n                    \"start_time\": \"01:00:00\",\n                    \"end_time\": \"13:00:00\"\n                }\n            },\n            \"address\": {\n                \"id\": 9,\n                \"address1\": \"T nagar\",\n                \"address2\": null,\n                \"city\": \"Chennai\",\n                \"state\": \"Tamil Nadu\",\n                \"country\": \"india\",\n                \"pin\": 495227,\n                \"latitude\": \"12.902424563866342\",\n                \"longitude\": \"80.20500580068112\",\n                \"location\": {\n                    \"type\": \"Point\",\n                    \"coordinates\": [\n                        12.902424563866342,\n                        80.20500580068112\n                    ]\n                }\n            }\n        }\n    ],\n    count: 20,\n    limit: 3,\n    offset: 0\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Bad Request\n{\n  \"error\": \"1\",\n  \"message\": \"Internal Sever Error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/technicians/routes/technicians.routes.js",
    "groupTitle": "Technicians"
  },
  {
    "type": "post",
    "url": "/technicians/get_list_by_location?limit=10&offset=0",
    "title": "Get Technicians list by location",
    "name": "Get_Technicians_by_location",
    "group": "Technicians",
    "permission": [
      {
        "name": "Admin Technician\n\n*"
      }
    ],
    "parameter": {
      "examples": [
        {
          "title": "Request-Example:",
          "content": " {\n\t\"center\": {\n\t\t\"lat\": \"17.442633\",\n\t\t\"lng\": \"78.382679\"\n\t},\n    \"radius\": 600 // in meters from center\n    \"locality\": \"chennai\" // if locality is passed then center and radius are ignored // remove locality if you want to filter by center and radius\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "    HTTP/1.1 200 OK\n{\n    \"error\": \"0\",\n    \"message\": \"Technicians data\",\n    \"data\": [\n        {\n            \"id\": 8,\n            \"first_name\": \"Martin\",\n            \"last_name\": \"Km\",\n            \"email\": null,\n            \"gender\": null,\n            \"mobile\": 1234567049,\n            \"technician_id\": \"TECH100005\",\n            \"address_id\": 7,\n            \"pan\": null,\n            \"aadhar\": null,\n            \"profile_pic\": null,\n            \"status\": true,\n            \"services\": {\n                \"id\": 1,\n                \"name\": \"Plumber\",\n                \"technician_services\": {\n                    \"technician_id\": 8,\n                    \"service_id\": 1,\n                    \"preferred_location\": \"Chennai\",\n                    \"start_time\": \"01:00:00\",\n                    \"end_time\": \"13:00:00\"\n                }\n            },\n            \"address\": {\n                \"id\": 7,\n                \"address1\": \"T nagar\",\n                \"address2\": null,\n                \"city\": \"Chennai\",\n                \"state\": \"Tamil Nadu\",\n                \"country\": \"india\",\n                \"pin\": 495227,\n                \"latitude\": \"12.902424563866342\",\n                \"longitude\": \"80.20500580068112\",\n                \"location\": {\n                    \"type\": \"Point\",\n                    \"coordinates\": [\n                        12.902424563866342,\n                        80.20500580068112\n                    ]\n                }\n            }\n        },\n        {\n            \"id\": 9,\n            \"first_name\": \"Cristina\",\n            \"last_name\": \"Mate\",\n            \"email\": null,\n            \"gender\": null,\n            \"mobile\": 1234567042,\n            \"technician_id\": \"TECH100006\",\n            \"address_id\": 8,\n            \"pan\": null,\n            \"aadhar\": null,\n            \"profile_pic\": null,\n            \"status\": true,\n            \"services\": {\n                \"id\": 1,\n                \"name\": \"Plumber\",\n                \"technician_services\": {\n                    \"technician_id\": 9,\n                    \"service_id\": 1,\n                    \"preferred_location\": \"Chennai\",\n                    \"start_time\": \"01:00:00\",\n                    \"end_time\": \"13:00:00\"\n                }\n            },\n            \"address\": {\n                \"id\": 8,\n                \"address1\": \"T nagar\",\n                \"address2\": null,\n                \"city\": \"Chennai\",\n                \"state\": \"Tamil Nadu\",\n                \"country\": \"india\",\n                \"pin\": 495227,\n                \"latitude\": \"12.902424563866342\",\n                \"longitude\": \"80.20500580068112\",\n                \"location\": {\n                    \"type\": \"Point\",\n                    \"coordinates\": [\n                        12.902424563866342,\n                        80.20500580068112\n                    ]\n                }\n            }\n        },\n        {\n            \"id\": 11,\n            \"first_name\": \"Julia\",\n            \"last_name\": \"Home\",\n            \"email\": null,\n            \"gender\": null,\n            \"mobile\": 1234567040,\n            \"technician_id\": \"TECH100007\",\n            \"address_id\": 9,\n            \"pan\": null,\n            \"aadhar\": null,\n            \"profile_pic\": null,\n            \"status\": true,\n            \"services\": {\n                \"id\": 1,\n                \"name\": \"Plumber\",\n                \"technician_services\": {\n                    \"technician_id\": 11,\n                    \"service_id\": 1,\n                    \"preferred_location\": \"Chennai\",\n                    \"start_time\": \"01:00:00\",\n                    \"end_time\": \"13:00:00\"\n                }\n            },\n            \"address\": {\n                \"id\": 9,\n                \"address1\": \"T nagar\",\n                \"address2\": null,\n                \"city\": \"Chennai\",\n                \"state\": \"Tamil Nadu\",\n                \"country\": \"india\",\n                \"pin\": 495227,\n                \"latitude\": \"12.902424563866342\",\n                \"longitude\": \"80.20500580068112\",\n                \"location\": {\n                    \"type\": \"Point\",\n                    \"coordinates\": [\n                        12.902424563866342,\n                        80.20500580068112\n                    ]\n                }\n            }\n        }\n    ]\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 Bad Request\n{\n  \"error\": \"1\",\n  \"message\": \"Technician not found.\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Bad Request\n{\n  \"error\": \"2\",\n  \"message\": \"Internal Sever Error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/technicians/routes/technicians.routes.js",
    "groupTitle": "Technicians"
  },
  {
    "type": "get",
    "url": "/technicians/:id",
    "title": "Get a technician by Id",
    "name": "Get_a_technician_by_id",
    "group": "Technicians",
    "permission": [
      {
        "name": "Admin Technician"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-access-code",
            "description": "<p>value: User Token</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "    HTTP/1.1 200 OK\n    {\n    \"error\": \"0\",\n    \"message\": \"Technician data.\",\n    \"data\": {\n        \"id\": 5,\n        \"first_name\": \"Ramesh\",\n        \"last_name\": \"something\",\n        \"email\": null,\n        \"gender\": null,\n        \"mobile\": 1234567023,\n        \"technician_id\": \"TECH100003\",\n        \"address_id\": 5,\n        \"pan\": null,\n        \"aadhar\": null,\n        \"profile_pic\": null,\n        \"status\": true,\n        \"address\": {\n            \"id\": 5,\n            \"address1\": \"tcs mind space office\",\n            \"address2\": null,\n            \"city\": \"city\",\n            \"state\": \"state\",\n            \"country\": \"india\",\n            \"pin\": 495227,\n            \"latitude\": \"17.444367\",\n            \"longitude\": \"78.377645\",\n            \"location\": {\n                \"type\": \"Point\",\n                \"coordinates\": [\n                    17.444367,\n                    78.377645\n                ]\n            }\n        },\n        \"services\": {\n            \"id\": 1,\n            \"name\": \"Plumber\",\n            \"technician_services\": {\n                \"technician_id\": 5,\n                \"service_id\": 1,\n                \"preferred_location\": \"ameerpet\",\n                \"start_time\": null,\n                \"end_time\": null\n            }\n        }\n    }\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 Bad Request\n{\n  \"error\": \"1\",\n  \"message\": \"Technician not found.\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Bad Request\n{\n  \"error\": \"2\",\n  \"message\": \"Internal Sever Error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/technicians/routes/technicians.routes.js",
    "groupTitle": "Technicians"
  },
  {
    "type": "post",
    "url": "/technicians/update/:mobile",
    "title": "Update a Technician",
    "name": "Update_Technicians",
    "group": "Technicians",
    "permission": [
      {
        "name": "Admin Technician"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-access-code",
            "description": "<p>value: User Token</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Example:",
          "content": " { // note: send data in form-data format // keys for file uploads profile pic - profile, aadhar front - aadhar_front, aadhar back - aadhar_back\n\t\"id\": 5,\n\t\"last_name\": \"something\",\n\t\"email\": \"email@email.com\",\n\t\"address\" : {\n\t\t\"city\": \"toronto\",\n\t\t\"country\": \"canada\"\n\t},\n\t\"service\": {\n\t\t\"service_id\": 1,\n\t\t\"preferred_location\": \"kadapa\"\n\t}\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "    HTTP/1.1 200 OK\n    {\n    \"error\": \"0\",\n    \"message\": \"Technician updated successfully.\",\n    \"data\": {\n        \"id\": 5,\n        \"last_name\": \"something\",\n        \"email\": \"email@email.com\",\n        \"address\": {\n            \"city\": \"toronto\",\n            \"country\": \"canada\"\n        },\n        \"service\": {\n            \"service_id\": 1,\n            \"preferred_location\": \"kadapa\"\n        }\n    }\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 Bad Request\n{\n  \"error\": \"1\",\n  \"message\": \"Technician not found.\"\n}",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Bad Request\n{\n  \"error\": \"2\",\n  \"message\": \"Internal Sever Error\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/technicians/routes/technicians.routes.js",
    "groupTitle": "Technicians"
  },
  {
    "type": "post",
    "url": "/technicians/upload",
    "title": "Upload technicians from excel",
    "name": "Upload_Technicians_from_excel",
    "group": "Technicians",
    "permission": [
      {
        "name": "Admin Technician"
      }
    ],
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "x-access-code",
            "description": "<p>value: User Token</p>"
          }
        ]
      }
    },
    "parameter": {
      "examples": [
        {
          "title": "Request-Example:",
          "content": "Upload excel with sheet name data // follow sample excel for ref.",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n            error: '0',\n            message: 'Technician data.',\n            data: [{}, {}]\n     }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 Bad Request\n{\n            error: '1',\n            message: \"duplicate mobile numbers found in excel.\",\n            duplicates: [8923982398, 9844439839]\n     }",
          "type": "json"
        },
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500 Bad Request\n{\n            error: '2',\n            message: \"Existed data found in excel.\"\n     }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "api/v1.0/technicians/routes/technicians.routes.js",
    "groupTitle": "Technicians"
  }
] });
