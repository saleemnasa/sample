define({
  "name": "Instafix API",
  "version": "0.0.1",
  "description": "RESTfull API for Instafix",
  "title": "Instafix API",
  "url": "http://13.232.92.123:4000/v1.0",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2018-11-14T13:25:03.108Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
