
// /**
//  * @api {post} /technicians/upload/profile_image/:technician_id Profile Image update
//  * @apiName Profile Image update
//  * @apiGroup Technicians
//  *
//  * @apiPermission Mobile App, Website
//  * 
//  * @apiHeader {String} x-access-code User Token
//  * 
//  * @apiParam (Request body) {File} avatar multipart/form-data file object
//  *
//  * @apiSuccessExample Success-Response:
//  *     HTTP/1.1 200 OK
//  *     
//  *    {
//             "error": "0",
//             "message": "Profile image uploaded successfully",
//             "data": {
//                 profile_pic : "https://instafix-dev.s3.ap-south-1.amazonaws.com/CUST100001_1539002346235?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIAJ2427THK3UAFEWGQ%2F20181008%2Fap-south-1%2Fs3%2Faws4_request&X-Amz-Date=20181008T123907Z&X-Amz-Expires=900&X-Amz-Signature=ee43f8c2192354b5ab6b7b3a1101d2cafbd14b0c29b5bef60926b921a5a68e92&X-Amz-SignedHeaders=host"
//             }
//  *     }
//  *
//  * @apiErrorExample {json} Error-Response:
//  *     HTTP/1.1 400 Bad Request
//  *     {
//  *          "error": "2",
//  *          "message": "Technician data not found"
//  *     }
//  * 
//  * @apiErrorExample {json} Error-Response:
//  *     HTTP/1.1 500 Internal Server
//  *     {
//  *          "error": "1",
//  *          "message": "Internal server error"
//  *     }
//  *
//  */

// router.post('/v1.0/technicians/upload/profile_image/:technician_id', isCustomer.hasAdminRole, upload.single('avatar'), TechnicianController.uploadProfileImage);


// /**
//  * @api {post} /technicians/upload/aadhar_front/:technician_id Aadhar Image update
//  * @apiName Aadhar Image update
//  * @apiGroup Technicians
//  *
//  * @apiPermission Mobile App, Website
//  * 
//  * @apiHeader {String} x-access-code User Token
//  * 
//  * @apiParam (Request body) {File} aadhar_front multipart/form-data file object
//  *
//  * @apiSuccessExample Success-Response:
//  *     HTTP/1.1 200 OK
//  *     
//  *    {
//             "error": "0",
//             "message": "Profile image uploaded successfully",
//             "data": {
//                 aadhar_front : "https://instafix-dev.s3.ap-south-1.amazonaws.com/CUST100001_1539002346235?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIAJ2427THK3UAFEWGQ%2F20181008%2Fap-south-1%2Fs3%2Faws4_request&X-Amz-Date=20181008T123907Z&X-Amz-Expires=900&X-Amz-Signature=ee43f8c2192354b5ab6b7b3a1101d2cafbd14b0c29b5bef60926b921a5a68e92&X-Amz-SignedHeaders=host"
//             }
//  *     }
//  *
//  * @apiErrorExample {json} Error-Response:
//  *     HTTP/1.1 400 Bad Request
//  *     {
//  *          "error": "2",
//  *          "message": "Technician data not found"
//  *     }
//  * 
//  * @apiErrorExample {json} Error-Response:
//  *     HTTP/1.1 500 Internal Server
//  *     {
//  *          "error": "1",
//  *          "message": "Internal server error"
//  *     }
//  *
//  */

// router.post('/v1.0/technicians/upload/aadhar_front/:technician_id', isCustomer.hasAdminRole, upload.single('aadhar_front'), TechnicianController.uploadProfileImage);


// /**
//  * @api {post} /technicians/upload/aadhar_back/:technician_id Aadhar Image update
//  * @apiName Aadhar Image update
//  * @apiGroup Technicians
//  *
//  * @apiPermission Mobile App, Website
//  * 
//  * @apiHeader {String} x-access-code User Token
//  * 
//  * @apiParam (Request body) {File} aadhar_back multipart/form-data file object
//  *
//  * @apiSuccessExample Success-Response:
//  *     HTTP/1.1 200 OK
//  *     
//  *    {
//             "error": "0",
//             "message": "Profile image uploaded successfully",
//             "data": {
//                 aadhar_back : "https://instafix-dev.s3.ap-south-1.amazonaws.com/CUST100001_1539002346235?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIAJ2427THK3UAFEWGQ%2F20181008%2Fap-south-1%2Fs3%2Faws4_request&X-Amz-Date=20181008T123907Z&X-Amz-Expires=900&X-Amz-Signature=ee43f8c2192354b5ab6b7b3a1101d2cafbd14b0c29b5bef60926b921a5a68e92&X-Amz-SignedHeaders=host"
//             }
//  *     }
//  *
//  * @apiErrorExample {json} Error-Response:
//  *     HTTP/1.1 400 Bad Request
//  *     {
//  *          "error": "2",
//  *          "message": "Technician data not found"
//  *     }
//  * 
//  * @apiErrorExample {json} Error-Response:
//  *     HTTP/1.1 500 Internal Server
//  *     {
//  *          "error": "1",
//  *          "message": "Internal server error"
//  *     }
//  *
//  */

// router.post('/v1.0/technicians/upload/aadhar_back/:technician_id', isCustomer.hasAdminRole, upload.single('aadhar_back'), TechnicianController.uploadProfileImage);
// /**
//  * @api {post} /technicians/update_address Update address of a Technician
//  * @apiName Update Address of a Technicians
//  * @apiGroup Technicians
//  *
//  * @apiPermission Admin Technician
//  * 
//  * 
//  * @apiHeader {String} x-access-code value: User Token 
//  * 
//  * @apiParamExample {json} Request-Example:
//  *  {
//  *  "id": 1, // required must be technician id note: use update address service to update address of a technician
// 	"address": {
//         "city": "Hyderabad"
//     }
//     }
//  *
//  *
//  * @apiSuccessExample Success-Response:
//  *     HTTP/1.1 200 OK
//  *     {
//  *       "error": "0",
//  *       "message": "Technician address updated successfully."
//  *    }
//  *
//  * @apiErrorExample {json} Error-Response:
//  *     HTTP/1.1 400 Bad Request
//  *     {
//  *       "error": "1",
//  *       "message": "Technician not found."
//  *     }
//  * 
//  * 
//  * @apiErrorExample {json} Error-Response:
//  *     HTTP/1.1 500 Bad Request
//  *     {
//  *       "error": "2",
//  *       "message": "Internal Sever Error"
//  *     }
//  * 
//  *
//  */
// router.post('/v1.0/technicians/update_address', requires.body, TechnicianController.updateAddress);



// enquires routes from here


// /**
//  * @api {get} /enquires/:enquiery_id Get Enquires by ID
//  * @apiName Get Enquires by ID
//  * @apiGroup Enquires
//  *
//  * @apiPermission Admin
//  *
//  * @apiHeader {String} x-access-code User Token
//  *
//  * @apiSuccessExample Success-Response:
//  *     HTTP/1.1 200 OK
//  *     {
//             "error": "0",
//             "message": "Enquires data",
//             "data": 
//                     {
//                         "id": 1,
//                         "customer_id": 2,
//                         "feedback_title": "feed back 2",
//                         "feedback_text": "feed back 2",
//                         "feedback_type": 0,
//                         "reply_message": null,
//                         "is_replied": false,
//                         "created_by": null,
//                         "replied_by": null,
//                         "status": true,
//                         "created_at": "2018-10-04T06:12:35.000Z",
//                         "updated_at": "2018-10-04T06:12:35.000Z",
//                         "customer": {
//                             "id": 2,
//                             "first_name": "Suresh",
//                             "last_name": "Koduri",
//                             "email": "sureshkoduri36@gmail.com",
//                             "gender": null,
//                             "mobile": 9885224116,
//                             "customer_id": "CUST100002",
//                             "address_id": null,
//                             "profile_pic": null,
//                             "signup_from": "mobile",
//                             "status": true
//                         }

//                     }

//         }
//  *
//  *
//  * @apiErrorExample {json} Error-Response:
//  *     HTTP/1.1 404 Not Found
//  *     {
//  *       "error": "1",
//  *       "message": "No feedback exists in the database."
//  *     }
//  *
//  * @apiErrorExample {json} Error-Response:
//  *     HTTP/1.1 500 Server Error
//  *     {
//  *       "error": "2",
//  *       "message": "Internal sever error"
//  *     }
//  *
//  */

// router.get('/v1.0/enquires/:feedback_id', isCustomer.hasAdminRole, EnquiresController.getFeedbackDetails);


// /**
//  * @api {post} /enquires/reply Reply Feedback
//  * @apiName Reply Feedback
//  * @apiGroup Enquires
//  *
//  * @apiPermission Admin
//  * 
//  * @apiHeader {String} x-access-code value: token
//  *
//  * @apiParamExample {json} Request-Example:
//  *     {
//             id: Number,         // required,
//             reply_message: Text,      // required,
//  *     }
//  *
//  * @apiSuccessExample Success-Response:
//  *     HTTP/1.1 201 OK
//  *     {
//             "error": "0",
//             "message": "Feedback updated."
//         }
//  *
//  *
//  * @apiErrorExample {json} Error-Response:
//  *     HTTP/1.1 500 Server error
//  *     {
//  *       "error": "1",
//  *       "message": "Error: {message}"
//  *     }
//  * 
//  * @apiErrorExample {json} Error-Response:
//  *     HTTP/1.1 400 Bad Request
//  *     {
//  *       "error": "2",
//  *       "message": "Feedback not found"
//  *     }
//  *
//  */

// router.post('/v1.0/enquires/reply', isCustomer.hasAdminRole, requires.body, EnquiresController.replyFeedback);
